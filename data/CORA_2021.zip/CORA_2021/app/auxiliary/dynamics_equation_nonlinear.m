function f = dynamics(x, u)
    
end