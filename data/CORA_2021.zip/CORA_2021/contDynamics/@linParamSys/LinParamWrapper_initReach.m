function varargout = LinParamWrapper_initReach(varargin)
%wrapper for initReach function from LinParamSys

%------------- BEGIN CODE --------------
[varargout{1:nargout}] = initReach(varargin{:});
%------------- END OF CODE --------------