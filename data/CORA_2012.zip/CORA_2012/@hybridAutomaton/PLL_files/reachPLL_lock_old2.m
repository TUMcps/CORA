function [Rfinal] = reachPLL_lock(obj, options)
% reachPLL_lock - computes the reachable set of the PLL when close to
% locking
%
% Syntax:  
%    [R] = reachPLL_lock(obj, options)
%
% Inputs:
%    options - options for reachability analysis of the system
%
% Outputs:
%    R - reachable set
%
% Example: 
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: none

% Author:       Matthias Althoff
% Written:      03-December-2010
% Last update:  ---
% Last revision:---

%------------- BEGIN CODE --------------


%obtain variables
A = options.sys.A;
c= options.sys.c;
dim = length(A);
Ucertain = options.Ucertain;
Ucertain_i = options.Ucertain_i;
Ucertain_p = options.Ucertain_p;
Uuncertain = options.Uuncertain;
guard = options.guard;
R{1} = options.R0; 


%instantiate linear system
linSys = linearSys('linearDynamics',A,eye(dim)); 

%compute phase and voltage velocity boundaries
%set viInt and vpInt
viInt = infsup(-1,1);
vpInt = infsup(-1,1);
vSat = 0.7; %<-- change vSat here!
[vMinPhase,vMaxPhase]=phaseVelBound(A, c, viInt, vpInt);
[vMinVoltage,vMaxVoltage] = voltageVelBound(A,vpInt,Ucertain);

%compute cycle time
t_cycle = 1/options.sys.c(5);

%compute interval hull
IH = intervalhull(R{1});

iCycle=1;

while ~(IH<=options.Rgoal)

    %PHASE 1---------------------------------------------------------------
    %compute T
    Phi_IH = abs(intervalhull([0 0 0 1 0]*R{iCycle}));
    Tmax = Phi_IH(:,2)/min(vMinPhase,vMaxPhase);
    T = infsup(0,Tmax);
    
    %get center and delta of T
    t_center = mid(T);
    t_delta = rad(T);
    
    %compute matrix zonotope
    Acenter = A*t_center;
    Adelta{1} = A*t_delta;
    
    matZ = matZonotope(Acenter, Adelta);
    
    %compute matrix exponential
    % r:1, intermediate order:3, taylorterms: 10
    [eZ,eI,zPow,iPow,E] = expmMixed(matZ,1,2,10);
    %----------------------------------------------------------------------
    
    %INPUT-----------------------------------------------------------------
    u = center(Ucertain) - options.sys.c;
    
    vInt = infsup(vMinPhase,vMaxPhase);
    Ainput_tmp = zeros(dim);
    Ainput_center = Ainput_tmp;
    Ainput_gen = Ainput_tmp;
    Ainput_center(:,4) = mid(1/vInt) * u;
    Ainput_gen(:,4) = rad(1/vInt) * u;
    
    Agen{1} = Ainput_gen;
    
    %instantiate matrix zonotope
    matZinput = matZonotope(Ainput_center,Agen);
    
    %compute remainder--------------
    
    %simplify 
    deltaMat{1} = rad(T);
    T_intervalMatrix = intervalMatrix(mid(T), rad(T));
    T_matrixZono = matZonotope(mid(T), deltaMat);
    E_input_zono = T_matrixZono*eZ*u;
    E_input_interval = T_intervalMatrix*eI*u;
    
    %convert to zonotope
    E_input = zonotope(E_input_zono) + zonotope(intervalhull(E_input_interval));
    %----------------------------------------------------------------------
    
    
    %PHASE 1 combined------------------------------------------------------
    Rtmp = (eZ+matZinput)*R{iCycle} + eI*R{iCycle} + E_input;
    %----------------------------------------------------------------------
    
    %PHASE 2---------------------------------------------------------------
    T2 = t_cycle - Tmax;
    T3 = t_cycle;
    
    %compute reachable set in a classical way for a time interval
    %new initial set
    Rinit_new = expm(A*T2)*Rtmp;
    
    %compute for time interval
    %set options
    options.timeStep = T3 - T2;
    options.uTrans = 0*options.sys.c;
    options.U = zonotope(0*options.uTrans);

    %compute initial set
    [obj,Rfirst,options] = initReach(linSys,Rinit_new,options);
    %----------------------------------------------------------------------
    
    %store result
    R{iCycle+1} = reduce(Rfirst.ti,'girard',options.zonotopeOrder);

    phaseDiff=intervalhull([0 0 0 1 -1]*R{iCycle})
    iCycle = iCycle+1;
end
%store final set
Rfinal = R{iCycle};



%compute phase velocity boundaries
function [vMin,vMax]=phaseVelBound(A,c,vpInt,viInt)

vInt = A(4,:)*[viInt; 0; vpInt; 0; 0] + c(4);

vMin = inf(vInt);
vMax = sup(vInt);


%compute phase velocity boundaries
function [vMin,vMax]=voltageVelBound(A,vpInt,Ucertain)

%projection matric
P = [1 0 0 0 0; 0 1 0 0 0];

absVal = max(abs(inf(vpInt)),abs(sup(vpInt)));

%velocity for v_p1 not considering inputs
vInt_tmp = A(2,:)*[0; -absVal; +absVal; 0; 0];

%velocity for v_i and v_p1 
vIH = intervalhull(P*Ucertain) + intervalhull([0,0; -vInt_tmp, vInt_tmp]);

vMin = vIH(:,1);
vMax = vIH(:,2);


%compute time intervals for charge pump on and off
function [t_on,t_total]=timeBound_phase(R,vMin,vMax,phaseMargin)

%obtain range of Phi_v
Phi_IH = intervalhull([0 0 0 1 0]*R);
PhiMin = min(Phi_IH(:,1),phaseMargin);
PhiMax = min(Phi_IH(:,2),phaseMargin);

%t_on
t_on_min = -PhiMax/vMax;
t_on_max = -PhiMin/vMin;
t_on = infsup(t_on_min,t_on_max);


%t_total
t_total_min = (1-PhiMax)/vMax;
t_total_max = (1-PhiMin)/vMin;
t_total = infsup(t_total_min,t_total_max);


%compute time intervals for charge pump on and off
function [t_on]=timeBound_voltage(R,vMax,vSat)

%obtain range of v_i and v_p1
v_i_IH = intervalhull([1 0 0 0 0]*R);
v_p1_IH = intervalhull([0 1 0 0 0]*R);

v_i_min = v_i_IH(:,1);
v_p1_min = v_p1_IH(:,1);

%t_on
t_i_max = (vSat-v_i_min)/vMax(1);
t_p1_max = (vSat-v_p1_min)/vMax(2);
t_on = [t_i_max, t_p1_max];



function eAtInt = inputExponential(A,r,options)

%compute Apowers
Apower = powers(A,options);
E = remainder(A,r,options);

dim = length(Apower{1});
Asum = r*eye(dim);
%compute higher order terms
for i=1:options.taylorTerms
    %compute factor
    factor = r^(i+1)/factorial(i+1);    
    %compute sums
    Asum = Asum + Apower{i}*factor;
end

%compute exponential due to constant input
eAtInt = Asum + E*r;


function Apower = powers(A,options)

%initialize 
Apower = cell(1,options.taylorTerms+1);
Apower{1} = A;  
    
%compute powers for each term and sum of these
for i=1:options.taylorTerms
    %compute powers
    Apower{i+1}=Apower{i}*A;
end   


function E = remainder(A,r,options)

%compute absolute value bound
M = abs(A*r);
dim = length(M);

%compute exponential matrix
eM = expm(M);

%compute first Taylor terms
Mpow = eye(dim);
eMpartial = eye(dim);
for i=1:options.taylorTerms
    Mpow = M*Mpow;
    eMpartial = eMpartial + Mpow/factorial(i);
end

W = eM-eMpartial;

%instantiate remainder
E = intervalMatrix(zeros(dim),W);


%------------- END OF CODE --------------