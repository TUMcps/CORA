function [R] = reachPLL_general(obj, A_input, pllSys, options)
% reachPLL_general - computes the reachable set of the PLL 
%
% Syntax:  
%    [R] = reachPLL_lock(obj, options)
%
% Inputs:
%    options - options for reachability analysis of the system
%
% Outputs:
%    R - reachable set
%
% Example: 
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: none

% Author:       Matthias Althoff
% Written:      14-December-2010
% Last update:  ---
% Last revision:---

%------------- BEGIN CODE --------------

%define A and A_input!!

%obtain variables
A = options.sys.A{1};
c = options.sys.c;
dim = length(A);

R{1} = options.R0; 


%compute phase and voltage velocity boundaries
%set viInt and vpInt
viInt = infsup(-0.5,0.5);
vpInt = infsup(-0.5,0.5);
[vMin,vMax]=phaseVelBound(A, c, viInt, vpInt);

%compute cycle time
t_cycle = 1/27;

%compute interval hull
IH = intervalhull(R{1});
IH_intersect = IH;

% %init
% Vall = cell(1,length(options.Pguard));
% for iGuard = 1:length(options.Pguard);
%     Vall{iGuard} = [];
% end

iCycle=1;

while ~isempty(IH) && ~(IH<=options.Rgoal{1}) && ~(IH<=options.Rgoal{2})

    %PHASE 1---------------------------------------------------------------
    %compute time limits when charge pump is on
    [t_min,t_max]=timeBound(R{iCycle},vMin,vMax);
    deltaT = t_max - t_min;
    
    %compute phase velocity interval
    vInt = infsup(vMin,vMax);
    
    %extract ranges of x_1 and x_2, x_3
    int_i = IH_intersect(1,:);
    int_p = IH_intersect(2:3,:);
    
    IH_i = intervalhull(int_i);
    IH_p = intervalhull(int_p);
    
    %input range
    factor_i = inputRange(pllSys, t_max, IH_i, 1, 1, options); %index: 1, index of saturation: 1
    factor_p = inputRange(pllSys, t_max, IH_p, [2 3], 2, options); %index: [2 3], index of saturation: 2
    
    M_left = diag([factor_i(1), factor_p(1), 1, 1]); 
%     M_right = diag([factor_i(2), factor_p(2), 1, 1]); 
%     M = infsup(M_left, M_right);
%     U_interval = M*interval(intervalhull(options.U));
%     U_IH = intervalhull([inf(U_interval),sup(U_interval)]);
%     U = zonotope(U_IH);
    U = M_left*options.U;
    
    %compute input solution for t=[0,t_min] 
    eAtInt = inputExponential(A_input,t_min,options);
    Rinput = expm(A*(t_cycle-t_min)) * eAtInt * U;
    
    %compute input matrix for t=[t_min, t_max] 
    matZinput = inputMatrix(A, A_input, deltaT, t_cycle-t_min, U, vInt, options);
    
    %complete solution
    R_new = (expm(A*t_cycle)+matZinput)*R{iCycle} + Rinput;
    
%     %obtain linear map
%     t = iCycle*t_cycle;
%     linMap = expm(A*t) + 0.01*eye(dim);
%     
%     %check for guard intersection
%     %do set shrinking
%     R_test = simplifySet(R_new, linMap, A, 1);
%     P_test = newPolytope(R_test);
%     
%     %intersect
%     for iGuard = 1:length(options.Pguard);
%         %check if guard is empty
%         if ~isempty(options.Pguard{iGuard})
%             %intersect
%             P_int = P_test & options.Pguard{iGuard};
%             %check for emptiness
%             if ~isempty(P_int) 
%                 %new vertices
%                 Vadd = get(vertices(P_int),'V');
%                 Vall{iGuard}(:,end+1:end+length(Vadd(1,:))) = Vadd;
%             end
%         end
%     end
    
    %intersect with invariant
    R_intersect = R_new & zonotope(options.Rinv);
    IH_intersect = intervalhull(R_intersect);
    
    if ~isempty(R_new)
        IH=intervalhull(R_new);
        R{iCycle+1} = reduce(R_new,'girard',60);
    else
        %initialize empty intervalhull
        IH = intervalhull();
    end
    
%     if mod(iCycle,400)==0
%     %if mod(iCycle,100)==0
%         
%         %simplify
%         R{iCycle+1} = simplifySet(R{iCycle+1}, linMap, A, 1);
%     end
    
    
%     if mod(iCycle,200)==0
%         dims=[1 2; 2 3; 1 4];
%         for iPlot=1:3
%             figure;
%             plot(R{iCycle+1},dims(iPlot,:));
%         end
%     end
    
    
    if mod(iCycle,100)==0
        disp('next 100 cycles')
        IH
    end
    
    IH(1,:)

    iCycle = iCycle+1;
end



%compute phase velocity boundaries
function [vMin,vMax]=phaseVelBound(A,c,vpInt,viInt)

vInt = A(4,:)*[viInt; 0; vpInt; 0] + c(4);

vMin = inf(vInt);
vMax = sup(vInt);




%compute time intervals for charge pump on and off
function [t_min,t_max]=timeBound(R,vMin,vMax)

%obtain range of Phi_v
Phi_IH = intervalhull([0 0 0 1]*R);
PhiMin = min(abs(Phi_IH(:,1)),abs(Phi_IH(:,2)));
PhiMax = max(abs(Phi_IH(:,1)),abs(Phi_IH(:,2)));

%t_on
if Phi_IH(:,1)*Phi_IH(:,2)>0
    t_min = PhiMin/vMax;
else
    t_min = 0;
end
t_max = PhiMax/vMin;

function factor = inputRange(pllSys, tMax, IH, ind, relInd, options)

%generate corner cases for integral part
V = get(vertices(IH),'V');

for i=1:length(V(1,:))
    %generate initial set
    x0 = zeros(5,1);
    x0(4:5) = [-1 0];
    x0(ind) = V(:,i);
    
    %simulate system
    options.u = options.uLoc{2};
    [obj,t,x] = simulate(pllSys,options,0,tMax,x0,[]);
    
    %find input ranges
    x_min(i) = min(x(:,relInd));
    x_max(i) = max(x(:,relInd));
    
end

xMin = min(x_min);
xMax = max(x_max);

if xMax>0.35
    factor(1) = (1-(xMax-0.35)/(0.51-0.35));
else
    factor(1) = 1;
end

if xMin>0.35
    factor(2) = (1-(xMin-0.35)/(0.51-0.35));
else
    factor(2) = 1;
end




function eAtInt = inputExponential(A,r,options)

%compute Apowers
Apower = powers(A,options);
E = remainder(A,r,options);

dim = length(Apower{1});
Asum = r*eye(dim);
%compute higher order terms
for i=1:options.taylorTerms
    %compute factor
    factor = r^(i+1)/factorial(i+1);    
    %compute sums
    Asum = Asum + Apower{i}*factor;
end

%compute exponential due to constant input
eAtInt = Asum + E*r;


function Apower = powers(A,options)

%initialize 
Apower = cell(1,options.taylorTerms+1);
Apower{1} = A;  
    
%compute powers for each term and sum of these
for i=1:options.taylorTerms
    %compute powers
    Apower{i+1}=Apower{i}*A;
end   


function E = remainder(A,r,options)

%compute absolute value bound
M = abs(A*r);
dim = length(M);

%compute exponential matrix
eM = expm(M);

%compute first Taylor terms
Mpow = eye(dim);
eMpartial = eye(dim);
for i=1:options.taylorTerms
    Mpow = M*Mpow;
    eMpartial = eMpartial + Mpow/factorial(i);
end

W = eM-eMpartial;

%instantiate remainder
E = intervalMatrix(zeros(dim),W);


function R = simplifySet(R, linMap, A, exactnessFlag)

%do classical reduction
R = reduce(R,'girard',2);

%update options.W
W{1} = eye(length(A));
W{2} = linMap;
% Aenh(2:4,1:4) = A(2:4,1:4);
% Aenh(1,1) = 1;
% Aenh(4,4) = 0.01;
%W{3} = Aenh;
%W{4} = [1 0 0 -1; 0 1 -1 0; 0 1 0 -1; 1 -1 0 0];

%shrink
R = shrink3(R,W,exactnessFlag);

function [E] = expMatRemainder(A, t, options)

%compute auxiliary matrix
tmpMat = 0.5*(t^2)*A^2;

%compute E_1 center, generators
E_center = 1/factorial(2)*tmpMat;
E_gen{1} = 1/factorial(2)*tmpMat;

for i=3:options.taylorTerms
    tmpMat = 0.5*(t^i)*A^i;
    
    %compute E center, generators
    E_center = E_center + 1/factorial(i)*tmpMat;
    E_gen{end+1} = 1/factorial(i)*tmpMat;
end

%instantiate matrix zonotopes
E_zono = matZonotope(E_center, E_gen);

%compute remainders
Erem = exponentialRemainder(intervalMatrix(0.5*A*t,0.5*A*t),options.taylorTerms);

%final result
E = intervalMatrix(E_zono) + Erem;


function matZinput = inputMatrix(A, A_input, Tmax, tFinal, U, vInt, options)

%initialize
dim = length(A_input);

T_1 = infsup(0,Tmax); %other time delay: 50e-3
T_2 = infsup(0.5*Tmax,Tmax); %other time delay: 50e-3

%get center and delta of [0,T]
t_center_1 = mid(T_1);
t_delta_1 = rad(T_1);
t_intMat_1 = intervalMatrix(t_center_1,t_delta_1);

%get center and delta of [0.5T, T]
t_center_2 = mid(T_2);
t_delta_2{1} = rad(T_2);
t_zonMat_2 = matZonotope(t_center_2,t_delta_2);

%compute matrix zonotopes
E = expMatRemainder(A_input, Tmax, options);

%compute factor
factor = (1/vInt);
matFactor_int = intervalMatrix(mid(factor),rad(factor));
matFactor_zono = matZonotope(matFactor_int);

%zonotope part of input matrix
inputMat_zono = matFactor_zono*(eye(dim) + t_zonMat_2*A_input);
inputMat_int = matFactor_int*(E + E*0.5*A_input*t_intMat_1 + E*E);
%----------------------------------------------------------------------

%INPUT-----------------------------------------------------------------


u_IH = get(intervalhull(U),'intervals');
u_IH = -u_IH; %negative feedback
u_center = 0.5*(u_IH(:,1)+u_IH(:,2));
u_delta{1} =  0.5*(u_IH(:,2)-u_IH(:,1));
u_int = intervalMatrix(u_center, u_delta{1});
u_zono = matZonotope(u_center, u_delta);

%compute fourth column
fourthCol = intervalMatrix(inputMat_zono*u_zono) + inputMat_int*u_int;
fourthCol = expm(A*(tFinal-Tmax))*fourthCol; %correction
fourthCol_center = mid(fourthCol.int);
fourthCol_gen = rad(fourthCol.int);

Acenter = zeros(dim);
Adelta = zeros(dim);
Acenter(:,4) = fourthCol_center;
Adelta(:,4) = fourthCol_gen;
matZinput = intervalMatrix(Acenter,Adelta);


%------------- END OF CODE --------------