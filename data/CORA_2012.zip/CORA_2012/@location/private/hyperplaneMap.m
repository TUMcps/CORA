function [TP,R,activeGuards,Rguard,Rcont] = hyperplaneMap(obj,tStart,R0,options)
% hyperplaneMap - computes the reachable set of the system within a 
% location, detects the guard set that is hit and computes the new set on
% the hyperplane and the subsequent mapping.
%
% Syntax:  
%    [TP,R,activeGuards,Rjump,Rcont] =
%    hyperplaneMap(obj,tStart,R0,options)
%
% Inputs:
%    obj - location object
%    tStart - start time
%    R0 - initial reachable set
%    options - options struct
%
% Outputs:
%    TP - time point struct; e.g. contains time vector of minimum times for reaching guard sets
%    R - cell array of reachable sets
%    activeGuards - active guards
%    Rjump - reachable set after jump according to the reset map
%    Rcont - reachable set due to continuous evolution without guard or
%    invariant inmtersection
%
% Example: 
%
% Other m-files required: initReach, reach, potOut, potInt, guardIntersect,
% reset
% Subfunctions: none
% MAT-files required: none
%
% See also: none

% Author:       Matthias Althoff
% Written:      08-August-2011
% Last update:  ---
% Last revision:---

%------------- BEGIN CODE --------------

%load data from options
tFinal=options.tFinal;

%initialize set counter and time
iSet=1;
t=tStart;


%initialize reachable set
[obj.contDynamics,Rnext,options]=initReach(obj.contDynamics,R0,options);
Rcont.OT{iSet}=Rnext.ti; 
Rcont.T{iSet}=Rnext.tp; 
%increment time and set counter
t = t+options.timeStep;
iSet = iSet+1; 

%check if still in invariant
inInv = in(obj.invariant,Rnext.ti);

%while reachable set still COMPLETELY in invariant
while inInv && (t<tFinal)
    
    %compute next reachable set
    [Rnext, options]=reach(obj.contDynamics, Rnext, options);

    Rcont.OT{iSet}=reduce(Rnext.ti,'girard',0.2*options.zonotopeOrder);
    Rcont.T{iSet}=reduce(Rnext.tp,'girard',0.2*options.zonotopeOrder);
    Rfull.T{iSet}=Rnext.tp;
    %increment time and set counter
    t = t+options.timeStep;
    iSet = iSet+1;
    
    if mod(iSet,5000)==0
        iSet
        length(get(Rnext.ti,'Z'))
    end
    
    if options.isHybrid
        %check if still in invariant
        inInv = in(obj.invariant,Rnext.ti);
    end
end

%check if system is hybrid
if options.isHybrid

    %detect intersections of overapproximated reachable sets
    [activeGuards,minIndex,maxIndex] = hyperplaneGuardIntersect(obj,Rcont.OT); 
    
    %remove reachable parts outside the invariant
    [R] = potOut(obj,Rcont.OT,options);
    %R=Rcont.OT;       
    
    %workaround for HSCC 2012
    if minIndex>1
    
        %compute Rguard
        for iGuard = 1:length(activeGuards)
            
            disp('GUARD INTERSECT TIME');
            tic
            
            tmin = 0;
            tmax = (maxIndex(iGuard)+1 - minIndex(iGuard))*options.timeStep;
            A = get(get(obj,'contDynamics'),'A');
            B = get(get(obj,'contDynamics'),'B');
            guard = get(obj.transition{activeGuards(iGuard)},'guard');
            lastInd = minIndex(iGuard)-1;
            Rlast = Rfull.T{lastInd};

            %compute t_hit
            eventOptions = odeset('Events',eventFcn(obj));
            opt = odeset(eventOptions);
            %simulate continuous dynamics
            [obj.contDynamics,t] = simulate(obj.contDynamics,options,tmin,tmax,center(Rlast),opt);
            t_hit = t(end);

            %reduce zonotope
            Rlast=reduce(Rlast,'girard',options.zonotopeOrder);

            Rguard_tmp = guardProjection(guard,A,B,t_hit,tmin,tmax,Rlast,options);
            
            %add uncertain input
            optionsTmp = options;
            optionsTmp.timeStep = tmax;
            Rinput = errorSolution(obj.contDynamics,B*options.U,optionsTmp);
            Rguard_tmp = Rguard_tmp + Rinput;

            %reduce zonotope
            Rguard{iGuard}=reduce(Rguard_tmp,'girard',options.zonotopeOrder);
            toc

            %plot(Rguard{iGuard}, [1 2], 'r');
        end
    else
        minIndex=[];
    end
else
    minIndex=[];
    R=Rcont;
end

%if guard set has been hit
if ~isempty(minIndex)  
    %obtain time point struct TP
    deltaMin=minIndex*options.timeStep;
    deltaMax=maxIndex*options.timeStep;
    
    TP.tStart=tStart;
    TP.tMin=tStart+deltaMin;
    TP.tMax=tStart+deltaMax;

%if no guard set has been hit    
else
    TP.tStart=tStart;
    TP.tMin=t;
    TP.tMax=t;

    Rguard{1}=[];
    activeGuards=[];
end
%------------- END OF CODE --------------