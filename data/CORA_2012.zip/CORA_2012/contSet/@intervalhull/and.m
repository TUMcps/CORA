function [obj]=and(obj,IH)
% vertices - Computes intersection of interval hulls 
%
% Syntax:  
%    [obj]=and(obj,IH)
%
% Inputs:
%    obj - interval hull object
%    IH - interval hull
%
% Outputs:
%   obj - interval hull object
%
% Example: 
%    IH=intervalhull([1 2; -1 1]);
%    IH2=intervalhull([1.5 2.5; -2 0]);
%    IH=IH&IH2
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: ---

% Author:       Matthias Althoff
% Written:      16-October-2007 
% Last update:  02-December-2010
% Last revision:---

%------------- BEGIN CODE --------------

if ~isempty(obj.intervals)
    %determine intervals that intersect 'left'
    lIndices=(inf(obj)<=sup(IH))&(sup(IH)<=sup(obj));

    %determine intervals that intersect 'right'
    rIndices=(inf(IH)<=sup(obj))&(sup(obj)<=sup(IH));

    %there must be a left or right intersection for each dimension
    if all(lIndices|rIndices)
        %if IH completely inside of obj
        ihInd=find((inf(obj)<=inf(IH))&(sup(IH)<=sup(obj)));
        obj.intervals(ihInd,:)=[IH.intervals(ihInd,1),IH.intervals(ihInd,2)];

        %if obj completely inside of IH
        objInd=find((inf(IH)<=inf(obj))&(sup(obj)<=sup(IH)));
        obj.intervals(objInd,:)=[obj.intervals(objInd,1),obj.intervals(objInd,2)]; 

        lInd=find((inf(IH)<=inf(obj))&(sup(IH)<=sup(obj)));
        obj.intervals(lInd,:)=[obj.intervals(lInd,1),IH.intervals(lInd,2)];

        rInd=find((inf(obj)<=inf(IH))&(sup(obj)<=sup(IH)));
        obj.intervals(rInd,:)=[IH.intervals(rInd,1),obj.intervals(rInd,2)];  
    else
        obj.intervals=[];
    end
else
    obj.intervals=[];
end



%------------- END OF CODE --------------