function [coordinateMat]=gridPoints(obj,intervals)
% gridPoints - Computes grid points of an interval hull; the points are
% generated in a way, such that a continuous space partitioned in equal
% interval hulls has a uniform distribution of grid points when
% concatenating the interval hulls.
%
% Syntax:  
%    [coordinates]=grisPoints(obj,intervals)
%
% Inputs:
%    obj - interval hull object
%    intervals - number of intervals for each dimension
%
% Outputs:
%    coordinateMat - matrix where columns are the grid points
%
% Example: 
%    IH=intervalhull([1 2; -1 1]);
%    [coordinates]=gridPoints(IH,10);
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: ---

% Author: Matthias Althoff
% Written: 16-June-2009 
% Last update: ---
% Last revision: ---

%------------- BEGIN CODE --------------

%obtain interval vector
intervalVec=(obj.intervals(:,2)-obj.intervals(:,1))/intervals;

%obtain first grid point
startingPoint=obj.intervals(:,1)+0.5*intervalVec;
coordinateMat=startingPoint;

%obtain segment combinations
dim=length(obj.intervals(:,1));
comb=fullfact(ones(dim,1)*intervals);

for i=2:length(comb(:,1))
    coordinateMat(:,i)=startingPoint+(comb(i,:)'-1).*intervalVec;
end

%------------- END OF CODE --------------