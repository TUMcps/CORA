function [result]=le(obj1,obj2)
% le - Overloads the <= operator; here: Is one interval hull equal or the subset of
% another interval hull?
%
% Syntax:  
%    [result]=le(obj1,obj2)
%
% Inputs:
%    obj1 - interval hull object
%    obj2 - another interval hull object
%
% Outputs:
%    result - boolean variable: 1 if obj1 is subset or equal to obj2
%
% Example: 
%    IH1=intervalhull([1 2; -1 1]);
%    IH2=intervalhull([1 2; -2 2]);
%    IH1<=IH2
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: ---

% Author: Matthias Althoff
% Written: 14-September-2006 
% Last update: 26-March-2007
% Last revision: ---

%------------- BEGIN CODE --------------

%obtain intervals
I1=obj1.intervals;
I2=obj2.intervals;

%all left borders of obj1 bigger than obj2?
leftResult=all(I1(:,1)>=I2(:,1));

%all right borders of obj1 smaller than obj2?
rightResult=all(I1(:,2)<=I2(:,2));

%left and right interval test must be true
result=leftResult&rightResult;

%------------- END OF CODE --------------