function [V]=vertices(obj)
% vertices - Computes vertices of an interval hull 
%
% Syntax:  
%    [V]=vertices(obj)
%
% Inputs:
%    obj - interval hull object
%
% Outputs:
%    V - matrix, columns of which are vertices
%
% Example: 
%    IH=intervalhull([1 2; -1 1]);
%    V=vertices(IH);
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: ---

% Author: Matthias Althoff
% Written: 14-September-2006 
% Last update: 26-March-2007
% Last revision: ---

%------------- BEGIN CODE --------------

%convert to zonotope 
Z=zonotope(obj);

%obtain vertices
V=vertices(Z);

%------------- END OF CODE --------------