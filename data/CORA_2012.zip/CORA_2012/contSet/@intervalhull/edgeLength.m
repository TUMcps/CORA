function [edgeLen]=edgeLength(obj)
% edgeLength - Determines edge length of an interval hull
%
% Syntax:  
%    [edgeLen]=edgeLength(obj)
%
% Inputs:
%    obj - interval hull object
%
% Outputs:
%    edgeLen - edgeLength
%
% Example: 
%    IH=intervalhull([1 2; -1 1]);
%    edgeLen=edgeLength(IH);
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: center

% Author: Matthias Althoff
% Written: 14-September-2006 
% Last update: 26-March-2007
% Last revision: ---

%------------- BEGIN CODE --------------

edgeLen=obj.intervals(:,2)-obj.intervals(:,1);

%------------- END OF CODE --------------