function [result]=sup(obj)
% sup - returns the supremum of an intervalhull
%
% Syntax:  
%    [result]=sup(obj)
%
% Inputs:
%    obj - interval hull object
%
% Outputs:
%    result - supremum
%
% Example: 
%    IH=intervalhull([1 2; -1 1]);
%    sup(IH)
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: ---

% Author: Matthias Althoff
% Written: 11-May-2007
% Last update: ---
% Last revision: ---

%------------- BEGIN CODE --------------

result=obj.intervals(:,2);

%------------- END OF CODE --------------