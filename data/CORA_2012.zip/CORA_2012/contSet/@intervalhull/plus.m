function [IH]=plus(summand1,summand2)
% plus - Overloads the + operator; here: Compute Minkowski sum of two
% interval hulls
%
% Syntax:  
%    [obj]=plus(summand1,summand2)
%
% Inputs:
%    summand1 - interval hull object or numerical vector
%    summand2 - interval hull object or numerical vector
%
% Outputs:
%    IH - interval hull after Minkowsi addition
%
% Example: 
%    IH=intervalhull(rand(6,2));
%    summand1=intervalhull(rand(6,2));
%    summand2=rand(6,1);
%    IH1=IH+summand1;
%    IH2=IH+summand2;
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: ---

% Author: Matthias Althoff
% Written: 14-September-2006 
% Last update: 26-March-2007
% Last revision: ---

%------------- BEGIN CODE --------------

%Find an interval hull object
%Is summand1 an interval hull?
if strcmp('intervalhull',class(summand1))
    %initialize resulting interval hull
    IH=summand1;
    %initialize other summand
    summand=summand2;
%Is summand2 an interval hull?    
elseif strcmp('intervalhull',class(summand2))
    %initialize resulting interval hull
    IH=summand2;
    %initialize other summand
    summand=summand1;  
end

%Is summand an interval hull?
if strcmp('intervalhull',class(summand))
    %Calculate minkowski sum
    IH.intervals=IH.intervals+summand.intervals;
    
%is summand a vector?
elseif isnumeric(summand)
    %Calculate minkowski sum
    IH.intervals=[IH.intervals(:,1)+summand,IH.intervals(:,2)+summand];
end

%------------- END OF CODE --------------