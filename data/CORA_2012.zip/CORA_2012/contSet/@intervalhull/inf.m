function [result]=inf(obj)
% inf - returns the infimum of an intervalhull
%
% Syntax:  
%    [result]=inf(obj)
%
% Inputs:
%    obj - interval hull object
%
% Outputs:
%    result - infimum
%
% Example: 
%    IH=intervalhull([1 2; -1 1]);
%    inf(IH)
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: ---

% Author: Matthias Althoff
% Written: 11-May-2007
% Last update: ---
% Last revision: ---

%------------- BEGIN CODE --------------

result=obj.intervals(:,1);

%------------- END OF CODE --------------