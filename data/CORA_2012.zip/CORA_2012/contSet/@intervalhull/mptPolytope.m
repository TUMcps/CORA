function [P]=mptPolytope(obj)
% mptPolytope - Converts an interval hull object to a mptPolytope object
%
% Syntax:  
%    [P]=mptPolytope(obj)
%
% Inputs:
%    obj - interval hull object
%
% Outputs:
%    P - mpt polytope object
%
% Example: 
%    IH=intervalhull([1 2; -1 1]);
%    P=mptPolytope(IH);
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: ---

% Author:       Matthias Althoff
% Written:      01-February-2010
% Last update:  ---
% Last revision:---

%------------- BEGIN CODE --------------

%obtain pplPolytope
pplPolytope = polytope(obj);

%convert to MPT polytope
P = mptPolytope(pplPolytope.C, pplPolytope.d);


%------------- END OF CODE --------------