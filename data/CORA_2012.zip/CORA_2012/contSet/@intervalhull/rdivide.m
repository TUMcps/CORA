function [obj]=rdivide(obj,vector)
% rdivide - Overloads the ./ operator; allows elementwise division of
% intervals by a vector
%
% Syntax:  
%    [obj]=rdivide(obj)
%
% Inputs:
%    obj - interval hull object 
%
% Outputs:
%    obj - interval hull object after elementwise division
%
% Example: 
%    IH=intervalhull(rand(6,2));
%    divisor=rand(6,1);
%    IH=IH./divisor
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: plus

% Author: Matthias Althoff
% Written: 14-September-2006 
% Last update: 26-March-2007
% Last revision: ---

%------------- BEGIN CODE --------------

obj.intervals=[obj.intervals(:,1)./vector,obj.intervals(:,2)./vector];

%------------- END OF CODE --------------