function [obj] = halfspace(obj)
% halfspace - Generates halfspace representation of the intervalhull
%
% Syntax:  
%    [obj] = halfspace(obj)
%
% Inputs:
%    obj - intervalhull object
%
% Outputs:
%    obj - intervalhull object
%
% Example: 
%    ---
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: ---

% Author:       Matthias Althoff
% Written:      07-May-2007 
% Last update:  19-October-2010
% Last revision:---

%------------- BEGIN CODE --------------

%convert intervalhull to polytope and retrieve halfspace representation
P=polytope(obj);
%write to object structure
obj.halfspace.H=P.C;
obj.halfspace.K=P.d;
obj.halfspace.equations=length(P.d);

%------------- END OF CODE --------------