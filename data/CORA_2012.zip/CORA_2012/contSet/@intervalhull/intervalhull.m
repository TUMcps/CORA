function Obj = intervalhull(varargin)
% intervalhull - Object and Copy Constructor 
%
% Syntax:  
%    object constructor: Obj = class_name(varargin)
%    copy constructor: Obj = otherObj
%
% Inputs:
%    input1 - interval matrix with two column vectors. The left vector
%    determines the left and the right vector the right limit of the
%    interval hull
%
% Outputs:
%    Obj - Generated Object
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: zonotope,  polytope

% Author: Matthias Althoff
% Written: 14-September-2006 
% Last update: 26-March-2007
% Last revision: ---

%------------- BEGIN CODE --------------

% If no argument is passed (default constructor)
if nargin == 0
    Obj.intervals=[];
    Obj.halfspace=[];
    % Register the variable as an object
    Obj = class(Obj, 'intervalhull');    
    
% If one argument is passed
elseif nargin == 1
    %if argument is an intervalhull
    if isa(varargin{1}, 'intervalhull')
        Obj = varargin{1};
    else
        %List elements of the class
        %left limit smaller or equal than right limit?
        intervals=varargin{1};
        if all(intervals(:,1)<=intervals(:,2))
            Obj.intervals=varargin{1}; 
        else
            error('Left limit must be smaller or equal than right limit');
        end
        Obj.halfspace=[];

        % Register the variable as an object
        Obj = class(Obj, 'intervalhull');
    end
    
% Else if the parameter is an identical object, copy object    
elseif isa(varargin{1}, 'intervalhull')
    Obj = varargin{1};
    
% Else if not enough or too many inputs are passed    
else
    disp('This class needs more/less input values');
    Obj=[];
end

%------------- END OF CODE --------------