function obj = enclose(obj,P)
% enclose - computes the convex hull of two mptPolytopes
%
% Syntax:  
%    obj = enclose(obj,P)
%
% Inputs:
%    obj - mptPolytope object
%    P - mptPolytope object
%
% Outputs:
%   obj - mptPolytope object
%
% Example: 
%    ---
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: ---

% Author:       Matthias Althoff
% Written:      02-February-2011
% Last update:  ---
% Last revision:---

%------------- BEGIN CODE --------------

%compute convex hull
obj.P = hull([obj.P P.P]);


%------------- END OF CODE --------------