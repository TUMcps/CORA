function V = vertices(obj)
% vertices - computes the vertices of a mptPolytope
%
% Syntax:  
%    V = vertices(obj)
%
% Inputs:
%    obj - mptPolytope object
%
% Outputs:
%   V - vertices object
%
% Example: 
%    ---
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: ---

% Author:       Matthias Althoff
% Written:      01-February-2011
% Last update:  ---
% Last revision:---

%------------- BEGIN CODE --------------

%compute vertices
V = extreme(obj.P);

%convert to vertices object
V = vertices(V');

%------------- END OF CODE --------------