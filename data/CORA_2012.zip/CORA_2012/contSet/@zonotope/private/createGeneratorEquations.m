function createGeneratorEquations(dim)
% newPolytope - Converts a zonotope from a G- to a H-representation
%
% Syntax:  
%    [P] = newPolytope(Z)
%
% Inputs:
%    Z - zonotope object
%
% Outputs:
%    P - polytope object
%
% Example: 
%    Z=zonotope(rand(2,5));
%    P=polytope(Z);
%    plot(P);
%    hold on
%    plot(Z);
%
% Other m-files required: vertices, polytope
% Subfunctions: none
% MAT-files required: none
%
% See also: intervalhull,  vertices

% Author: Matthias Althoff
% Written: 01-April-2010
% Last update: ---
% Last revision: ---

%------------- BEGIN CODE --------------


%create symbolic variables
[G] = symVariables(dim);






%------------- END OF CODE --------------