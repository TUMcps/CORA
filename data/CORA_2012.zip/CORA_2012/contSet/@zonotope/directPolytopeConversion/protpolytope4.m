function [P] = protpolytope3(Z)
% polytope - Converts a zonotope to a polytope representation
%
% Syntax:  
%    [P] = polytope(Z)
%
% Inputs:
%    Z - zonotope object
%
% Outputs:
%    P - polytope object
%
% Example: 
%    Z=zonotope(rand(2,5));
%    P=polytope(Z);
%    plot(P);
%    hold on
%    plot(Z);
%
% Other m-files required: vertices, polytope
% Subfunctions: none
% MAT-files required: none
%
% See also: intervalhull,  vertices

% Author: Matthias Althoff
% Written: 14-September-2006 
% Last update: 22-March-2007
% Last revision: ---

%------------- BEGIN CODE --------------

tic

%retrieve dimension
dim=length(Z.Z(:,1));
%retrieve center of the zonotope
c=Z.Z(:,1);
%retrieve generator matrix G
G=Z.Z(:,2:end);
%get number of generators
nrOfGen=length(G(1,:));


%build C matrix
for i=1:dim
    Q=G(:,1:dim);
    Q(:,i)=[];
    v=ndimCross(Q);
    C(i,:)=v'/norm(v);
end

%build d vector
for i=1:dim
    %determine direction
    s=sign(C(i,:)*G(:,i));
    if s==0
        s=1;
    end
    posVector=c+s*G(:,i);
    negVector=c-s*G(:,i);
    
    dPos(i,:)=C(i,:)*posVector;
    dNeg(i,:)=-C(i,:)*negVector;
end

%generate generator table
fullRow=1:dim;
for i=1:dim
    row=fullRow;
    row(i)=[];
    genTable(i,:)=row;
end


for iGen=(dim+1):length(G(1,:))
    actG=G(:,iGen);
    
    set=[-length(genTable(:,1)):-1,1:length(genTable(:,1))];
    comb = combnk(set,2);
    for i=1:length(comb)
        rowA=comb(i,1);
        rowB=comb(i,2);
        rem=intersect(genTable(rowA,:),genTable(rowB,:));
        if length(rem)==(dim-2) 
            mirSignA=sign(comb(i,1));
            mirSignB=sign(comb(i,2));
            faceA=abs(comb(i,1));
            faceB=abs(comb(i,2));

            sA=mirSignA*sign(C(faceA,:)*actG);
            sB=mirSignB*sign(C(faceB,:)*actG);  
            %if change in sign
            if sA~=sB                  
                genTable=[genTable;[rem,iGen]];
                %compute new C row vector    
                Q=G(:,[rem,iGen]);
                v=ndimCross(Q);
                newC=v'/norm(v);  
                
                %compute new d value
                posVector=c; negVector=c;
                for j=1:(iGen-1)
                    s=sign(newC*G(:,j));
                    if s==0
                        s=1;
                    end
                    posVector=posVector+s*G(:,j);
                    negVector=negVector-s*G(:,j);
                end                
                dNewPos=newC*posVector;
                dNewNeg=-newC*negVector;
                
                %add result of C, dPos, dNeg
                C=[C;newC];
                dPos=[dPos;dNewPos];          
                dNeg=[dNeg;dNewNeg];    
                
                %expand old generators 
                for j=1:(iGen-1)
                    exp=abs(C(j,:)*G(:,iGen));
                    dPos(j)=dPos(j)+exp;
                    dNeg(j)=dNeg(j)+exp;
                end                
            end
        end
    end
end

toc

P=polytope([C;-C],[dPos;dNeg]);


%------------- END OF CODE --------------