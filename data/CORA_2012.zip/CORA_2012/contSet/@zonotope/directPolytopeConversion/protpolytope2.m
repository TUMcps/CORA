function [P] = protpolytope2(Z)
% polytope - Converts a zonotope to a polytope representation
%
% Syntax:  
%    [P] = polytope(Z)
%
% Inputs:
%    Z - zonotope object
%
% Outputs:
%    P - polytope object
%
% Example: 
%    Z=zonotope(rand(2,5));
%    P=polytope(Z);
%    plot(P);
%    hold on
%    plot(Z);
%
% Other m-files required: vertices, polytope
% Subfunctions: none
% MAT-files required: none
%
% See also: intervalhull,  vertices

% Author: Matthias Althoff
% Written: 14-September-2006 
% Last update: 22-March-2007
% Last revision: ---

%------------- BEGIN CODE --------------

tic

%retrieve dimension
dim=length(Z.Z(:,1));
%retrieve center of the zonotope
c=Z.Z(:,1);
%retrieve generator matrix G
G=Z.Z(:,2:end);
%get number of generators
nrOfGen=length(G(1,:));


%build C matrix
for i=1:dim
    Q=G(:,1:dim);
    Q(:,i)=[];
    v=ndimCross(Q);
    C(i,:)=v'/norm(v);
end
mirC=-C;

%build d vector
for i=1:dim
    %determine direction
    s=sign(C(i,:)*G(:,i));
    if s==0
        s=1;
    end
    posVector=c+s*G(:,i);
    negVector=c-s*G(:,i);
    
    d(i,:)=C(i,:)*posVector;
    mird(i,:)=mirC(i,:)*negVector;
end

%note: C is automatically a matrix of connected Crows
connFaces=1:dim;


%generate generator table
fullRow=1:dim;
for i=1:dim
    row=fullRow;
    row(i)=[];
    genTable{i,:}=row;
end

%initialize neighborhood
faces{1}=1:dim;
for i=1:dim
    repFaces=replace(faces,1,i,[]);
    neighbor{i}=repFaces{1};
end
nrOfFaces=dim;

for iGen=(dim+1):length(G(1,:))
    %determine change in sign 
    actG=G(:,iGen);
    s=sign(C*actG);
    sDiff=diff(s);
    pos=find(sDiff,1,'first');
    %if no sign change is detected: sign change must be at the beginning 
    if isempty(pos)
        pos=1;
    end
    
    faces1=connFaces(pos);
    faces2=connFaces(pos+1);
    
    %initialize change, checked and previously unchecked faces
    change=[];
    unchecked=unique([faces1,faces2]);
    checked=[];
    
    while ~isempty(unchecked)
        actFace=unchecked(1);
        faceNeighbors=neighbor{actFace};
        newUnchecked=setdiff(faceNeighbors,checked);
        
        %get sign of investigated face
        s=sign(C(actFace,:)*actG);
        
        %check if new unchecked faces have a different sign
        sOther=sign(C(newUnchecked,:)*actG);
        indices=find(s==sOther);
        newUnchecked(indices)=[];
        
        %store face combinations with a change in sign
        entries=length(newUnchecked);
        change=[change;ones(entries,1)*unchecked(1),newUnchecked'];
        
        %remove checked face from unchecked faces
        unchecked(1)=[];
        unchecked=union(unchecked,newUnchecked);
        
        %save faces that have been checked
        checked=union(checked,actFace);        
    end

    nrOfFaces=nrOfFaces+1;
    %make changes
    for i=1:length(change(:,1))
        %update neighborhood-----------------------------------------------
        %new neighbors of new face
        commonNeighbors=intersection(neighbor{change(i,1)},neighbor{change(i,2)});  
        neighbor{nrOfFaces}=[change(i,1),change(i,2),commonNeighbors];      
        %remove old neighbors
        neighbor{change(i,1)}=setdiff(neighbor{change(i,1)},change(i,2));
        neighbor{change(i,2)}=setdiff(neighbor{change(i,2)},change(i,1));
        %add new neighbor
        neighbor{change(i,1)}=[neighbor{change(i,1)},nrOfFaces];
        neighbor{change(i,2)}=[neighbor{change(i,2)},nrOfFaces];
        %------------------------------------------------------------------
        
        %update generators-------------------------------------------------
        
        %------------------------------------------------------------------
    end
     

            %find common generator and replace it by new one
            repGen=setdiff(genTable{2*iFace-1},genTable{actNeighbor});
            %add new face to table
            genTable{end+1}=genTable{2*iFace-1};
            pos=length(genTable);
            genTable=replace(genTable,pos,repGen,iGen);
            %dublicate genTable entry
            genTable{end+1}=genTable{end};
            
            %compute new C row vector    
            Q=G(:,genTable{pos});
            v=ndimCross(Q);
            newC=v'/norm(v);
            newCpos=newC;
            newCneg=-newC;
            C=[C;newCpos;newCneg];
            %compute new d value
            posVector=c; negVector=c;
            for j=1:(iGen-1)
                s=sign(newC*G(:,j));
                if s==0
                    s=1;
                end
                posVector=posVector+s*G(:,j);
                negVector=negVector-s*G(:,j);
            end                
            dNewPos=newC*posVector;
            dNewNeg=-newC*negVector;
            d=[d;dNewPos;dNewNeg];
                

    %expand old generators 
    for j=1:(iGen-1)
        exp=C(2*j-1,:)*G(:,iGen);
        d(2*j-1)=d(2*j-1)+abs(exp);
        d(2*j)=d(2*j)+abs(exp);
    end
end

toc

P=[]
%P=polytope(C,d);



%---------------------------------------------------------------------
function cell=replace(cell,row,oldValue,newValue)

%find old entry
indices=find(cell{row}==oldValue);
%replace entry
cell{row}(indices)=newValue;

function orthVector=orth(startVector,vector)
orthVector=startVector-startVector'*vector/norm(vector)*vector/norm(vector);
orthVector=orthVector/norm(orthVector);

%------------- END OF CODE --------------