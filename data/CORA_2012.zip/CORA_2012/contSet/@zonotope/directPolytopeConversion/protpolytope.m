function [P] = protpolytope(Z)
% polytope - Converts a zonotope to a polytope representation
%
% Syntax:  
%    [P] = polytope(Z)
%
% Inputs:
%    Z - zonotope object
%
% Outputs:
%    P - polytope object
%
% Example: 
%    Z=zonotope(rand(2,5));
%    P=polytope(Z);
%    plot(P);
%    hold on
%    plot(Z);
%
% Other m-files required: vertices, polytope
% Subfunctions: none
% MAT-files required: none
%
% See also: intervalhull,  vertices

% Author: Matthias Althoff
% Written: 14-September-2006 
% Last update: 22-March-2007
% Last revision: ---

%------------- BEGIN CODE --------------

%retrieve dimension
dim=length(Z.Z(:,1));
%retrieve center of the zonotope
c=Z.Z(:,1);
%retrieve generator matrix G
G=Z.Z(:,2:end);
%get number of generators
nrOfGen=length(G(1,:));


%build C matrix
for i=1:dim
    Q=G(:,1:dim);
    Q(:,i)=[];
    v=ndimCross(Q);
    C(2*i-1,:)=v'/norm(v);
    C(2*i,:)=-C(2*i-1,:);
end

%build d vector
for i=1:dim
    %determine direction
    s=sign(C(2*i-1,:)*G(:,i));
    if s==0
        s=1;
    end
    posVector=c+s*G(:,i);
    negVector=c-s*G(:,i);
    
    d(2*i-1,:)=C(2*i-1,:)*posVector;
    d(2*i,:)=C(2*i,:)*negVector;
end

%generate generator table
fullRow=1:dim;
for i=1:dim
    row=fullRow;
    row(i)=[];
    genTable{2*i-1,:}=row;
    genTable{2*i,:}=row;
end

%initialize neighborhood
faces{1}=1:2*dim;
for i=1:dim
    repFaces=replace(faces,1,2*i-1,[]);
    repFaces=replace(repFaces,1,2*i,[]);
    neighbor{2*i-1}=repFaces{1};
    neighbor{2*i}=repFaces{1}; 
end

for iGen=(dim+1):length(G(1,:))
    faces=length(neighbor)/2;
    %save old neighbors
    oldNeighbor=neighbor;
    for iFace=1:faces
        %compute if generator goes in or out of the face
        s=sign(C(2*iFace-1,:)*G(:,iGen));
        candidates=oldNeighbor{2*iFace-1};
        sNeigh=sign(C(candidates,:)*G(:,iGen));
        %check if the sign differs 
        indices=find(s~=sNeigh);
        for i=1:length(indices)
            actNeighbor=candidates(indices(i));
            %delete actNeighbor from oldNeighbor list to ensure that no
            %faces are added double times
            oldNeighbor=replace(oldNeighbor,actNeighbor,2*iFace-1,[]); 
            %oldNeighbor=replace(oldNeighbor,actNeighbor+1,2*iFace,[]);  

            %find common generator and replace it by new one
            repGen=setdiff(genTable{2*iFace-1},genTable{actNeighbor});
            %add new face to table
            genTable{end+1}=genTable{2*iFace-1};
            pos=length(genTable);
            genTable=replace(genTable,pos,repGen,iGen);
            %dublicate genTable entry
            genTable{end+1}=genTable{end};
            
            %compute new C row vector    
            Q=G(:,genTable{pos});
            v=ndimCross(Q);
            newC=v'/norm(v);
            newCpos=newC;
            newCneg=-newC;
            C=[C;newCpos;newCneg];
            %compute new d value
            posVector=c; negVector=c;
            for j=1:(iGen-1)
                s=sign(newC*G(:,j));
                if s==0
                    s=1;
                end
                posVector=posVector+s*G(:,j);
                negVector=negVector-s*G(:,j);
            end                
            dNewPos=newC*posVector;
            dNewNeg=-newC*negVector;
            d=[d;dNewPos;dNewNeg];
            %construct new neighbor matrix
            %add neigborhood of new face
            neighbor{end+1}=[2*iFace-1,actNeighbor];
            newFace=length(neighbor);
            neighbor{end+1}=[2*iFace,actNeighbor+1];
            
            %replace actNeigbor in iFace by newInd
            neighbor=replace(neighbor,2*iFace-1,actNeighbor,newFace);
            %replace iFace in actNeigbor by newInd
            neighbor=replace(neighbor,actNeighbor,2*iFace,newFace+1);            
        end
    end
    %expand old generators 
    for j=1:(iGen-1)
        exp=C(2*j-1,:)*G(:,iGen);
        d(2*j-1)=d(2*j-1)+abs(exp);
        d(2*j)=d(2*j)+abs(exp);
    end
end

P=polytope(C,d);


%---------------------------------------------------------------------
function cell=replace(cell,row,oldValue,newValue)

%find old entry
indices=find(cell{row}==oldValue);
%replace entry
cell{row}(indices)=newValue;

function orthVector=orth(startVector,vector)
orthVector=startVector-startVector'*vector/norm(vector)*vector/norm(vector);
orthVector=orthVector/norm(orthVector);

%------------- END OF CODE --------------