function res = zonoIntersect(obj, Z)
% zonoIntersect - Checks if a zonotope intersects with the halfspace
%
% Syntax:  
%    zonoIntersect(obj)
%
% Inputs:
%    obj - halfspace object
%
% Outputs:
%    ---
%
% Example: 
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: none

% Author:       Matthias Althoff
% Written:      08-August-2011
% Last update:  ---
% Last revision:---

%------------- BEGIN CODE --------------

%compute map on normal vector of the halfspace
IH = intervalhull(obj.c' * Z) + (-obj.d);

%check if interval contains 0
if IH(1,1)<0 && IH(1,2)>=0
    res = 1;
else
    res = 0;
end


%------------- END OF CODE --------------