function [eP] = enclosingProbability(pZ,m)
% enclosingProbability - Computes the enclosing probability of a 
% probabilistic zonotope
%
% Syntax:  
%    [eP] = enclosingProbability(pZ,m)
%
% Inputs:
%    pZ - probabilistic zonotope object
%    m  - m of the mSigma operator
%
% Outputs:
%    eP - enclosing probability
%
% Example: 
%
% Other m-files required: vertices, polytope
% Subfunctions: none

% MAT-files required: none
%
% See also: intervalhull,  vertices

% Author: Matthias Althoff
% Written: 08-August-2007
% Last update: 24-August-2007
% Last update: 27-August-2007
% Last revision: ---

%------------- BEGIN CODE --------------

%determine mesh size by n-sigma hyperbox
Z=mSigma(pZ,m);
IH=intervalhull(Z);
infimum=inf(IH);
supremum=sup(IH);
x=linspace(infimum(1),supremum(1),30);
y=linspace(infimum(2),supremum(2),30);

%get Sigma 
Sigma=sigma(pZ);

%initialize x-,y- and prob-vector for the mesh
ind=fullfact([length(x),length(y)]);
xVector=x(ind(:,1));
yVector=y(ind(:,2)); 
prob=0*xVector;

%check if center of probabilistic zonotope is uncertain
c=pZ.Z(:,1);
G=pZ.Z(:,2:end);
if isempty(G)
    prob=gaussian([xVector-c(1);yVector-c(2)],Sigma); 
else

    %get polytope of Z
    P=polytope(zonotope(pZ.Z));
    
    %go through the mesh
    for i=1:length(x)
        for j=1:length(y)
            %is a mesh point inside the uncertain mean?
            if isinside(P,[x(i);y(j)])
                %get gaussian distribution from the current mean
                c=[x(i);y(j)];
                tempP=gaussian([xVector-c(1);yVector-c(2)],Sigma);
                %save maximum values
                prob=max(prob,tempP);
            end
        end
    end

end

%Build probability matrix from probability vector and save x and y values
eP.P=reshape(prob,length(y),length(x));
eP.X=reshape(xVector,length(y),length(x));
eP.Y=reshape(yVector,length(y),length(x));

%------------- END OF CODE --------------