function [Rnext,options] = reach(obj,R,options)
% reach - computes the reachable continuous set for one time step
%
% Syntax:  
%    [Rnext,options] = reach(obj,R,options)
%
% Inputs:
%    obj - linearSys object
%    R - reachable set of the previous time step
%    options - options for the computation of the reachable set
%
% Outputs:
%    Rnext - reachable set of the next time step
%    options - options for the computation of the reachable set
%
% Example: 
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: none

% Author:       Matthias Althoff
% Written:      07-May-2007 
% Last update:  27-April-2009
%               29-June-2009
%               08-August-2011
% Last revision: ---

%------------- BEGIN CODE --------------

%load homogeneous solution from options struct
Rhom=options.Rhom;
Rhom_tp=options.Rhom_tp;
Rpar=options.Rpar;
Raux=options.Raux;

%update 
eAt=obj.taylor.eAt;
if iscell(options.Rtrans)
    Rtrans = options.Rtrans{options.iSet};
else
    Rtrans = options.Rtrans;
end

%option 1
Rhom=eAt*Rhom + center(Rtrans);
Rhom_tp=eAt*Rhom_tp + center(Rtrans);
Raux=eAt*Raux;
Rpar=Rpar + intervalhull(Raux) + intervalhull(Rtrans) + (-center(Rtrans));

% option 2
% Rhom=eAt*Rhom + Rtrans;
% Rhom_tp=eAt*Rhom_tp + Rtrans;
% Raux=eAt*Raux;
% Rpar=Rpar + intervalhull(Raux);
% Rhom=reduce(Rhom,'girard',options.zonotopeOrder);
% Rhom_tp=reduce(Rhom_tp,'girard',options.zonotopeOrder);

%save homogeneous and particulate solution to options struct
options.Rhom=Rhom;
options.Rhom_tp=Rhom_tp;
options.Rpar=Rpar;
options.Raux=Raux;

%write results to reachable set struct Rnext
if isa(Rhom,'mptPolytope')
    Rnext.ti=Rhom+mptPolytope(Rpar);
    Rnext.tp=Rhom_tp+mptPolytope(Rpar);
else
    Rnext.ti=Rhom+zonotope(Rpar);
    Rnext.tp=Rhom_tp+zonotope(Rpar);
end

%------------- END OF CODE --------------