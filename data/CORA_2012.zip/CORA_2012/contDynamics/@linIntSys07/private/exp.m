function [obj] = exp(varargin)
% expm - computes the exponential of an interval matrix defined by a linear
% interval system object; type specifies if over- or underapproximation
% should be computed
%
% Syntax:  
%    [obj] = expm(obj)
%
% Inputs:
%    obj - linear interval system object
%    type - 'under' or 'over' for over- or underapproximation; default:
%    type='over'
%
% Outputs:
%    obj - linear interval system object
%
% Example: 
%    Text for example...
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: OTHER_FUNCTION_NAME1,  OTHER_FUNCTION_NAME2

% Author: Matthias Althoff
% Written: 12-February-2007 
% Last update: 15-May-2007
% Last revision: ---

%------------- BEGIN CODE --------------

%read arguments
obj=varargin{1};  
options=varargin{2};
%two arguments
if nargin==2
    type='over';
%three arguments    
elseif nargin==3
    type=varargin{3};  
end
    
%load data from object/options structure
A=obj.A;
taylorTerms=options.taylorTerms;
r=options.timeStep;
dim=dimension(obj);
H=obj.taylor.H;

%compute underapproximation
if strcmp(type,'under')
    %initialize underapproximation
    [Ainf,Asup]=infsup(A); 
    Aleft{1}=Ainf;
    Aright{1}=Asup;
    [AsumLeft,AsumRight]=infsup(H+eye(dim));
    
    %init left and right term
    leftTerm=inf;
    rightTerm=inf;
    
    %init i
    i=1;
    
    %compute powers for each term and sum of these
    while (norm(leftTerm)>1e-10 | norm(rightTerm)>1e-10)
        %compute powers
        Aleft{i+1}=Aleft{i}*Ainf;
        Aright{i+1}=Aright{i}*Asup;

        if i>=3
            %obtain taylor terms
            leftTerm=Aleft{i}*r^i/factorial(i);
            rightTerm=Aright{i}*r^i/factorial(i);
            %compute sums
            AsumLeft=AsumLeft+leftTerm;
            AsumRight=AsumRight+rightTerm;
        end
        %update i
        i=i+1;
    end
    Amin=min(AsumLeft,AsumRight);
    Amax=max(AsumLeft,AsumRight);
    %write to object structure
    obj.taylor.Aunder=interval(Amin,Amax);
    
%compute overapproximation    
else
    %initialize overapproximation
    Apower{1}=A;
    Asquare=obj.taylor.sq;
    Asum=H+eye(dim);    
    
    %compute powers for each term and sum of these
    for i=1:taylorTerms
        %compute powers
        if i==1
            Apower{2}=Asquare;
        else
            Apower{i+1}=Apower{i}*A;
        end

        if i>=3
            %compute sums
            Asum=Asum+Apower{i}*r^i/factorial(i);
        end
    end   
    %determine error due to finite Taylor series
    alpha=infNorm(A);
    epsilon=alpha*r/(taylorTerms+2);
    phi=(alpha*r)^(taylorTerms+1)/factorial(taylorTerms+1)/(1-epsilon);
    E=interval(-ones(dim),ones(dim))*phi;
    
    %write to object structure
    obj.taylor.eAt=Asum+E;
    obj.taylor.powers=Apower;
    obj.taylor.error=E;    
    
    
    %alternative computation (new)
    Amid=mid(A);
    deltaA=A-Amid;
    deltaAsup=sup(deltaA);
    deltaAabs=abs(deltaAsup);
    
    %compute exponential matrices of Amid and deltaAabs separately
    I=eye(dim);
    
    expmMid=expm(Amid*r);
    expmAbs=expm(deltaAabs*r);
    expmDif=expmAbs-I;
    
    %combine both results
    symInt=interval(I-expmDif,I+expmDif);
    eAt=expmMid*symInt;
end

%------------- END OF CODE --------------