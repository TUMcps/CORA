function [obj]=inputTie(obj,options)
% inputTie - tie: time interval error; computes the error done by 
% the linear assumption of the constant input solution
%
% Syntax:  
%    [obj]=inputTie(obj,options)
%
% Inputs:
%    obj - linear interval system object
%    options - options struct
%
% Outputs:
%    obj - linear interval system object
%
% Example: 
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: expm, inputSol

% Author: Matthias Althoff
% Written:      11-May-2009
% Last update:  ---
% Last revision:---

%------------- BEGIN CODE --------------

%load data from object structure
Apower=obj.taylor.powers;
Asquare=obj.taylor.sq;
E=obj.taylor.error;
taylorTerms=options.taylorTerms;
r=options.timeStep;
dim=dimension(obj);

%initialize Asum; 
Asum=zeros(dim);

for i=2:(taylorTerms+1)
    %compute factor
    exp1=-i/(i-1); exp2=-1/(i-1);
    timeInterval=interval((i^exp1-i^exp2)*r^i,0);    
    %compute powers
    if i~=3
        Aadd=timeInterval*Apower{i-1};
    else
    %compute with more exact Asquare
        Aadd=timeInterval*Asquare;
    end
    %compute sum
    Asum=Asum+Aadd/factorial(i);
end

%write to object structure
obj.taylor.inputF=Asum+E*r; %rewrite this equation! E has to be divided by norm(A,inf)

%------------- END OF CODE --------------