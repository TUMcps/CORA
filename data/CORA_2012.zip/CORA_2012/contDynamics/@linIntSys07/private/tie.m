function [obj]=tie(obj,options)
% tie - tie: time interval error; computes the error done by 
% building the convex hull of time point solutions
%
% Syntax:  
%    [obj]=tie(obj)
%
% Inputs:
%    obj - linear interval system object
%    options - options struct
%
% Outputs:
%    obj - linear interval system object
%
% Example: 
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: expm, inputSol

% Author:       Matthias Althoff
% Written:      12-February-2007 
% Last update:  15-May-2007
%               22-June-2009
% Last revision: ---

%------------- BEGIN CODE --------------

%load data from object structure
Apower=obj.taylor.powers;
Asquare=obj.taylor.sq;
E=obj.taylor.error;
taylorTerms=options.taylorTerms;
r=options.timeStep;
dim=dimension(obj);

%initialize Asum; 
%compute Asquare saparate as it can be computed exactly
timeInterval=interval(-0.25*r^2,0);
Asum=timeInterval*Asquare/factorial(2);

for i=3:taylorTerms
    %compute factor
    exp1=-i/(i-1); exp2=-1/(i-1);
    timeInterval=interval((i^exp1-i^exp2)*r^i,0);    
    %compute powers
    Aadd=timeInterval*Apower{i};
    %compute sum
    Asum=Asum+Aadd/factorial(i);
end

%write to object structure
obj.taylor.F=Asum+E;

%------------- END OF CODE --------------