function [obj] = inputSolution(obj,options)
% inputSolution - computes the bloating due to the input 
%
% Syntax:  
%    [obj] = inputSolution(obj,options)
%
% Inputs:
%    obj - linear interval system object
%    options - options struct
%
% Outputs:
%    obj - linear interval system object
%
% Example: 
%    Text for example...
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: expm, tie

% Author: Matthias Althoff
% Written:      13-February-2007 
% Last update:  18-January-2008
%               04-May-2009
%               11-May-2009
%               22-June-2009
%               22-July-2009
% Last revision: ---

%------------- BEGIN CODE --------------

%set of possible inputs
V=obj.B*options.U;

%compute vTrans if possible
try
    vTrans=obj.B*options.uTrans;
catch
    vTrans=[];
end

%load data from object/options structure
Apower=obj.taylor.powers;
E=obj.taylor.error;
taylorTerms=options.taylorTerms;
r=options.timeStep;
dim=dimension(obj);
Hu=obj.taylor.Hu;

%initialize Vsum,Asum
Vsum=r*V;
Asum=Hu+eye(dim)*r;

for i=1:taylorTerms
    %compute factor
    factor=1/factorial(i+1);   
    
    %compute Vsum
    Vsum=Vsum+Apower{i}*factor*r^(i+1)*V;
    
    %compute Asum
    if i>=3
        Asum=Asum+Apower{i}*factor*r^(i+1);
    end
end

%compute overall solution
inputSolV=Vsum+E*r*V;

%compute integral of exponential matrix
eAtInt=Asum+E*r;

%compute solution due to constant input
if strcmp('interval',class(vTrans))
    vTrans=intervalhull([inf(vTrans),sup(vTrans)]);
    vTrans=zonotope(vTrans);
else
    vTrans=zonotope(vTrans);
end
inputSolVtrans=eAtInt*vTrans;

%compute additional uncertainty if origin is not contained in input set
if options.originContained
    inputCorr=zeros(dim,1);
else
    %compute inputF
    [obj]=inputTie(obj,options);
    inputF=obj.taylor.inputF;
    inputCorr=inputF*vTrans;
end

%write to object structure
obj.taylor.V=V;
obj.taylor.eAtInt=eAtInt;
obj.taylor.Rinput=inputSolV+inputSolVtrans;
obj.taylor.Rtrans=inputSolVtrans;
obj.taylor.inputCorr=inputCorr;

%------------- END OF CODE --------------