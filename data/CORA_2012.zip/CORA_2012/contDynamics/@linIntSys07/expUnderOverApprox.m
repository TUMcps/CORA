function [obj]=expUnderOverApprox(obj,options)
% expUnderOverApprox - computes the over and underapproximation of the
% interval matrix exponential to see the quality of the over-approximation
%
% Syntax:  
%    expUnderOverApprox(obj,options)
%
% Inputs:
%    obj - linIntSys07 object
%    options - options struct
%
% Outputs:
%    obj - linIntSys07 object
%
% Example: 
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: none

% Author: Matthias Althoff
% Written: 04-May-2009
% Last update: ---
% Last revision: ---

%------------- BEGIN CODE --------------

%compute exact square
[obj] = exactTerms(obj,options);

%compute under-approximation
obj = expm(obj,options,'under');

%compute over-approximation
obj = expm(obj,options,'over');


%------------- END OF CODE --------------