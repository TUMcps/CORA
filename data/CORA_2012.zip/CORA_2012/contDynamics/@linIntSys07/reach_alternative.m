function [Rnext,options] = reach_alternative(obj,R,options)
% reach_alternative - computes the reachable continuous set for one time step of a
% linear interval system in an alternative way
%
% Syntax:  
%    [Rnext,options] = reach_alternative(obj,R,options)
%
% Inputs:
%    obj - linIntSys object
%    R - reachable set of the previous time step
%    options - options for the computation of the reachable set
%
% Outputs:
%    Rnext - reachable set of the next time step
%    options - options for the computation of the reachable set
%
% Example: 
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: none

% Author:       Matthias Althoff
% Written:      12-May-2009 
% Last update: 	---
% Last revision:---

%------------- BEGIN CODE --------------

%OPTION1:

%homogeneous solution
Rhom=options.expAkr*options.Rfirst; 


% compute reachable set due to input

%set of possible inputs
Vges=obj.taylor.Vges;
%Compute input solution
Rpar=options.expAkrInt*Vges;

%overall solution
Rnext=Rhom+Rpar; 

%compute exponential and its integral of system matrix A
options.expAkr=obj.taylor.eAt*options.expAkr;
options.expAkrInt=obj.taylor.eAt*options.expAkrInt+obj.taylor.eAtInt;


% %OPTION2:
% 
% M=mid(obj.taylor.eAt);
% Mint=mid(obj.taylor.eAtInt);
% 
% try getfield(options, 'M')
% catch
%     options.M=M;
%     options.Mint=Mint;
% end
% 
% %homogeneous solution
% Rhom=options.M*options.Rfirst+(options.expAkr-options.M)*box(options.Rfirst); 
% 
% 
% % compute reachable set due to input
% 
% %set of possible inputs
% Vges=obj.taylor.Vges;
% %Compute input solution
% Rpar=options.Mint*Vges+(options.expAkrInt-options.Mint)*box(Vges);
% 
% %overall solution
% Rnext=Rhom+Rpar; 
% 
% %compute exponential and its integral of system matrix A
% options.M=M*options.M;
% options.Mint=M*options.Mint+Mint;
% options.expAkr=obj.taylor.eAt*options.expAkr;
% options.expAkrInt=obj.taylor.eAt*options.expAkrInt+obj.taylor.eAtInt;



%------------- END OF CODE --------------