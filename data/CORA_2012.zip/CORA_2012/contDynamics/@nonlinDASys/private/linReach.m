function [Rti,Rtp,Rti_y,perfInd,nr,options] = linReach(obj,options,Rinit,Rinit_y,iter)
% linReach - computes the reachable set after linearazation and returns if
% the initial set has to be split in order to control the linearization
% error
%
% Syntax:  
%    [Rti,Rtp,perfInd,nr,options] = linReach(obj,options,Rinit,iter)
%
% Inputs:
%    obj - nonlinear DAE system object
%    options - options struct
%    Rinit - initial reachable set
%    iter - flag for activating iteration
%
% Outputs:
%    Rti - reachable set for time interval
%    Rti - reachable set for time point
%    perfInd - performance index
%    nr - number of generator that should be split
%    options - options struct to return f0
%
% Example: 
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: 

% Author:       Matthias Althoff
% Written:      21-November-2011
% Last update:  ---
% Last revision:---

%------------- BEGIN CODE --------------

% linearize nonlinear system
[obj,linSys,options,linOptions] = linearize(obj,options,Rinit,Rinit_y); 

%translate Rinit by linearization point
Rdelta = Rinit + (-obj.linError.p.x);

% compute reachable set of linearized system
%ti: time interval, tp: time point
linOptions.p = obj.linError.p.x;
[linSys,R] = initReach(linSys,Rdelta,linOptions);
Rtp=R.tp;
Rti=R.ti;

%new technique: compute reachable set due to assumed linearization error
%Verror = zonotope([0*obj.expFactor,diag(obj.expFactor)]);
appliedError = 1.5*options.oldError;
appliedError_y = 1.5*options.oldError_y;
%appliedError = options.maxError;
Verror = zonotope([0*appliedError,diag(appliedError)]);
Verror_y = zonotope([0*appliedError_y,diag(appliedError_y)]);

[RallError] = errorSolution(linSys,Verror,options); 

%compute maximum reachable set due to maximal allowed linearization error
Rmax = Rti + RallError;

% obtain linearization error
if options.advancedLinErrorComp == 1
    [Verror, error, error_y, Rti_y] = linError_quadratic(obj, options, Rmax, Verror_y);
elseif options.advancedLinErrorComp == 2
    [Verror, error, error_y, Rti_y] = linError_mixed(obj, options, Rmax, Verror_y);   
else
    [Verror, error, error_y, Rti_y] = linError(obj, options, Rmax, Verror_y);
end

%store old error
options.oldError = error;
options.oldError_y = error_y;

% compute reachable set due to the linearization error
[Rerror] = errorSolution(linSys,Verror,options);

%translate reachable sets by linearization point
Rti=Rti+obj.linError.p.x;
Rtp=Rtp+obj.linError.p.x;

%compute performance index of linearization error
perfIndCurr = max(error./appliedError)
perfInd = max(error./options.maxError)

if (perfIndCurr>1) && (iter==1)
    %find best split
    nr=select(obj,options,Rinit,obj.expFactor);
else
    nr=[];
end

%add intervalhull of actual error
Rti=Rti+Rerror;
Rtp=Rtp+Rerror;


%------------- END OF CODE --------------