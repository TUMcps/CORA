function createJacobianFile(obj)
% createJacobianFile - generates an mFile that allows to compute the
% jacobian at a certain state and input
%
% Syntax:  
%    createJacobianFile(obj)
%
% Inputs:
%    obj - nonlinear system object
%
% Outputs:
%
% Example: 
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: ---

% Author:       Matthias Althoff
% Written:      30-June-2009
% Last update:  ---
% Last revision: ---

%------------- BEGIN CODE --------------

    
%load first order jacobian
J=obj.J;

[x,u,y] = symVariables(obj,'LRbrackets');

%store in stateSpaceModels folder
cd('/media/New Volume/software/2011/CORA/contDynamics/stateSpaceModels') %<-- change directory here

fid = fopen('jacobian_vehicle.m','w');
fprintf(fid, '%s\n\n', 'function [A,B]=jacobian_vehicle(x,u,y)');

% SYSTEM MATRIX
% write "A=["
fprintf(fid, '%s', 'A=[');

%write each row
for iRow=1:(length(J.x(:,1)))
    for iCol=1:(length(J.x(1,:))-1)
        str=[char(J.x(iRow,iCol)),','];
        str=bracketSubs(str);
        %write in file
        fprintf(fid, '%s', str);
    end
    if iRow<length(J.x(:,1))
        %write last element
        str=[char(J.x(iRow,iCol+1)),';...'];
        str=bracketSubs(str);
        %write in file
        fprintf(fid, '%s\n', str);
    else
        %write last element
        str=[char(J.x(iRow,iCol+1)),'];']; 
        str=bracketSubs(str);
        %write in file
        fprintf(fid, '%s\n\n', str);   
    end
end

% INPUT MATRIX
% write "B=["
fprintf(fid, '%s', 'B=[');

%write each row
for iRow=1:(length(J.y(:,1)))
    if length(J.y(1,:))>1
        for iCol=1:(length(J.y(1,:))-1)
            str=[char(J.y(iRow,iCol)),','];
            str=bracketSubs(str);
            %write in file
            fprintf(fid, '%s', str);
        end
    else iCol=0;
    end
    
    if iRow<length(J.y(:,1))
        %write last element
        str=[char(J.y(iRow,iCol+1)),';...'];
        str=bracketSubs(str);
        %write in file
        fprintf(fid, '%s\n', str);    
    else
        %write last element
        str=[char(J.y(iRow,iCol+1)),'];']; 
        str=bracketSubs(str);
        %write in file
        fprintf(fid, '%s', str);
    end
end


%close file
status = fclose(fid);

function [str]=bracketSubs(str)

%generate left and right brackets
str=strrep(str,'L','(');
str=strrep(str,'R',')');


%------------- END OF CODE --------------