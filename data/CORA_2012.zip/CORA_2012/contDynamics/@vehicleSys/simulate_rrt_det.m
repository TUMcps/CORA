function [X_red,xTraj] = simulate_rrt_det(obj,carDyn_full,options,R0,opt)
% simulate_rrt - simulates the vehicle using rapidly exploring random trees
% (partially deterministic sampling)
%
% Syntax:  
%    [obj,t,x,index] = simulate_rrt(obj,opt,tstart,tfinal,x0,options)
%
% Inputs:
%    obj - linearSys object
%    tstart - start time
%    tfinal - final time
%    x0 - initial state 
%    options - contains, e.g. the events when a guard is hit
%
% Outputs:
%    obj - linearSys object
%    t - time vector
%    x - state vector
%    index - returns the event which has been detected
%
% Example: 
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: none

% Author:       Matthias Althoff
% Written:      06-September-2011
% Last update:  ---
% Last revision:---

%------------- BEGIN CODE --------------

%nrOfSamples
nrOfSamples = 100;

%initialize
X_sample_size = edgeLength(intervalhull(options.X_sample));
normMatrix = diag(1./X_sample_size);
cMat = options.xStep;
param_mid = 0.5*(options.paramInt(:,2) + options.paramInt(:,1));
param_delta = 0.5*(options.paramInt(:,2) - options.paramInt(:,1));
xTraj = [];

%obtain set of uncertain inputs including parameters
Ymat = [get(options.Y, 'Z'),zeros(5,1)];
Ymat(6,:) = [param_mid, 0, 0, 0, 0, 0, param_delta];
Y = zonotope(Ymat);

%possible extreme inputs
V_input = vertices(Y);
V_input_mat = get(V_input,'V');
nrOfExtrInputs = length(V_input_mat(1,:));

%possible extreme points of sampling space
V_sample = vertices(options.X_sample);
V_sample_mat = get(V_sample,'V');

% %obtain B matrix from full matrix including parameter
% jacobian_input(obj,options);

%obtain vertices 
V = vertices(R0);
Vmat = get(V,'V');
X_red = Vmat;

for iVertex=1:length(Vmat)
    X_full(:,iVertex) = initDOTVehicle(X_red(:,iVertex));
end

%timeSteps
timeSteps = ceil(options.tFinal/options.timeStep);

%init
xTraj = cell(nrOfSamples,timeSteps);


for iStep = 1:timeSteps
    
    iStep
    tic
    
    for iSample = 1:nrOfSamples
        
        
        
        %iSample
        
        %init
        x_full = cell(1,nrOfExtrInputs);
        x_end_bicycle = [];
        par_options = [];
        par_options.p = options.p;
%         X_red_next = [];
%         X_full_next = [];
        

        %sample
        if iSample <= length(V_sample_mat(1,:))
            x_sample = V_sample_mat(:,iSample) + cMat(:,iStep);
        else
            x_sample = randPoint(options.X_sample) + cMat(:,iStep);
        end

        %nearest neighbor and selected state
        ind = nearestNeighbor(x_sample,X_red,cMat(:,iStep),normMatrix);
        x0 = X_full(:,ind);

        %update graph
        %G(iStep,ind) = iSample;

        %simulate model to find out best input
        for iInput = 1:nrOfExtrInputs
            %set input
            par_options.u = options.uTransVec(:,iStep);
            par_options.y = V_input_mat(:,iInput);
            %transfer uncertain parameter
            par_options.param = par_options.y(6);
            %simulate
            x_full{iInput} = par_simulate_tracking(carDyn_full,par_options,options.timeStep,x0,opt);
            %[dummy_a,dummy_b,x_full{iInput}] = simulate_tracking(carDyn_full,par_options,0,options.timeStep,x0,opt); 
            %[carDyn,t,aa] = simulate_tracking(carDyn_full,par_options,0,options.timeStep,x0,opt); 

            %convert to bicycle states
            x_end_bicycle(:,iInput) = convertToBicycleStates(x_full{iInput}(end,:));           
        end

        %nearest neighbor and selected state
        ind_input = nearestNeighbor(x_sample,x_end_bicycle,cMat(:,iStep),normMatrix);

        %add selected state 
        X_red_next(:,iSample) = x_end_bicycle(:,ind_input);
        X_full_next(:,iSample) = x_full{ind_input}(end,:);

        %add trajectory
        xTraj{iSample,iStep} = convertToBicycleStates(x_full{ind_input})';
    end
    toc
    %update variables
    X_red = X_red_next;
    X_full = X_full_next;
end


% %obtain input matrix
% xStar = cMat(:,iStep);
% uStar = options.uTransVec(:,iStep);
% yStar = [center(options.Y); param_mid];
% B=jacobian_vehicleFull_input(xStar,uStar,yStar);
% 
% %obtain flow vector
% f=obj.mFile(0,xStar,uStar,yStar(1:5),options.p,yStar(6));
% 
% %obtain desired flow vector
% f_d = x_sample - (x_sel - cMat(:,iStep));

% %find optimal u by linear programming
% projDims = [3,4]; %yaw and position coordinates are not directly influenced
% U_LP = project(B*zonotope(Ymat) + f,projDims); 

% %convert to a polytope
% P_LP = newPolytope(U_LP);
% uOpt = linprog(f_d(projDims),P_LP.C,P_LP.d);



function ind = nearestNeighbor(x_sample,X,c,normMatrix)

%normalize set of points
X_delta = X - c*ones(1,length(X(1,:)));
X_norm = normMatrix*X_delta;

%normalize sample point
x_delta = x_sample - c;
x_norm = normMatrix*x_delta;

%norm of distance
X_rel = X_norm - x_norm*ones(1,length(X_norm(1,:)));
norm_val = vnorm(X_rel,1,2); %compute 2-norm

%find index with smallest norm
[val,ind] = min(norm_val);


function x_bicycle = convertToBicycleStates(x_full)

x_bicycle(1,:) = -atan(x_full(:,8)./x_full(:,7)); % slip angle
x_bicycle(2,:) = -x_full(:,1); % yaw angle
x_bicycle(3,:) = -x_full(:,2); % yaw rate
x_bicycle(4,:) = sqrt(x_full(:,7).^2 + x_full(:,8).^2); % velocity in x-direction
x_bicycle(5,:) = x_full(:,27); % x-position
x_bicycle(6,:) = -x_full(:,28); % y-position


%simulate
function x_full = par_simulate_tracking(carDyn_full,par_options,timeStep,x0,opt)

[dummy_a,dummy_b,x_full] = simulate_tracking(carDyn_full,par_options,0,timeStep,x0,opt);

%------------- END OF CODE --------------