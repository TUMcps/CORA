function [obj] = jacobian_vehicle_param(obj,options)
% jacobian_vehicle - computes the jacobian of the vehicle system in a symbolic
% way; the result is stored in a m-file and passed by a handle
%
% Syntax:  
%    [obj] = jacobian_vehicle(obj)
%
% Inputs:
%    obj - vehicle system object
%
% Outputs:
%    obj - vehicle system object
%
% Example: 
%    Text for example...
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: 

% Author:       Matthias Althoff
% Written:      26-August-2011 
% Last update:  30-August-2011
% Last revision:---

%------------- BEGIN CODE --------------

%create symbolic variables
[x,u,y,p]=symVariables_param(obj,'LRbrackets');

%insert symbolic variables into the system equations
t=0;
fLR=obj.mFile(t,x,u,y,options.p,p);

%compute jacobian with respect to the state
Jx=jacobian(fLR,x);
%compute jacobian with respect to the input
Jy=jacobian(fLR,y);

%store jacobians with respect to parameters (assumption: expressions are linear in parameters)
%init
Jpx=cell(1,obj.nrOfParam+1);
Jpy=cell(1,obj.nrOfParam+1);
%part without parameters
Jpx{1} = subs(Jx,p,zeros(obj.nrOfParam,1));
Jpy{1} = subs(Jy,p,zeros(obj.nrOfParam,1));
%part with parameters
I = eye(obj.nrOfParam); %identity matrix
for i=1:obj.nrOfParam
    Jpx{i+1} = subs(Jx,p,I(i,:)) - Jpx{1};
    Jpy{i+1} = subs(Jy,p,I(i,:)) - Jpy{1};
end

%normalize
pCenter = 0.5*(options.paramInt(:,2) + options.paramInt(:,1));
pDelta = 0.5*(options.paramInt(:,2) - options.paramInt(:,1));

for i=1:obj.nrOfParam
    %center
    Jpx{1} = Jpx{1} + pCenter(i)*Jpx{i+1};
    Jpy{1} = Jpy{1} + pCenter(i)*Jpy{i+1};
    %generators
    Jpx{i+1} = pDelta*Jpx{i+1};
    Jpy{i+1} = pDelta*Jpy{i+1};
end

obj.J.x=Jpx;
obj.J.u=Jpy;

%generate mFile that computes the lagrange remainder and the jacobian
createJacobianFile_param(obj);
createParametricDynamicFile(obj,options);

%------------- END OF CODE --------------