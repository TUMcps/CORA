function Obj = vehicleSys(varargin)
% vehicleSys - Object and Copy Constructor (linSys: linear system)
%
% Syntax:  
%    object constructor: Obj = class_name(varargin)
%    copy constructor: Obj = otherObj
%
% Inputs:
%    input1 - name
%    input2 - dimension
%    input3 - number of inputs
%    input4 - mfile of the state space equations
%    input5 - value of maximum derivation within the invariant
%
% Outputs:
%    Obj - Generated Object
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: 

% Author:       Matthias Althoff
% Written:      03-May-2011 
% Last update:  ---
% Last revision:---

%------------- BEGIN CODE --------------

% If no argument is passed
if nargin == 0
    disp('This class has no input values');
    Obj.dim = [];
    Obj.nrOfInputs = [];
    Obj.nrOfParam = [];
    Obj.mFile = [];
    Obj.expFactor = [];
    Obj.J = [];
    Obj.linError = [];
    
    %Generate parent object
    cDyn=contDynamics('',1,1,1);
    % Register the variable as an child object of contDyn
    Obj = class(Obj, 'vehicleSys', cDyn);
  
    
% If 5 arguments are passed
elseif nargin == 5
    %List elements of the class
    Obj.dim=varargin{2};
    Obj.nrOfInputs=varargin{3};
    Obj.nrOfParam=[];
    Obj.mFile=varargin{4};
    Obj.expFactor=varargin{5};
    Obj.J = [];
    Obj.linError = [];

    %Generate parent object
    cDyn=contDynamics(varargin{1},ones(varargin{2},1),1,1);

    % Register the variable as an child object of contDyn
    Obj = class(Obj, 'vehicleSys', cDyn);      
    
% If 6 arguments are passed
elseif nargin == 6
    %List elements of the class
    Obj.dim=varargin{2};
    Obj.nrOfInputs=varargin{3};
    Obj.nrOfParam=varargin{6};
    Obj.mFile=varargin{4};
    Obj.expFactor=varargin{5};
    Obj.J = [];
    Obj.linError = [];

    %Generate parent object
    cDyn=contDynamics(varargin{1},ones(varargin{2},1),1,1);

    % Register the variable as an child object of contDyn
    Obj = class(Obj, 'vehicleSys', cDyn);        
    
        
% Else if the parameter is an identical object, copy object    
elseif isa(varargin{1}, 'vehicleSys')
    Obj = varargin{1};
    
% Else if not enough or too many inputs are passed    
else
    disp('This class needs more/less input values');
    Obj=[];
    Obj = class(Obj, 'vehicleSys');
end

%------------- END OF CODE --------------