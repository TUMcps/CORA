function [obj,linSys,f0,Y] = linearize(obj,c,uTrans,yTrans,Y,p)
% linearize - linearizes the vehicle system; linearization error is not
% included yet
%
% Syntax:  
%    [obj,linSys,linOptions] = linearize(obj,options)
%
% Inputs:
%    obj - vehicle system object
%    options - options struct
%
% Outputs:
%    obj - vehicle system object
%    linSys - linear system object
%    linOptions - options for the linearized system
%
% Example: 
%    Text for example...
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: 

% Author:       Matthias Althoff
% Written:      03-May-2011
% Last update:  04-May-2011
% Last revision:---

%------------- BEGIN CODE --------------


%linearization point p.x of the state is the center of the last reachable 
p.x=c; %+f0prev*0.5*options.timeStep;

%substitute p into the system equation in order to obtain the constant
%input
f0=obj.mFile(0,p.x,uTrans,yTrans,p);

%substitute p into the Jacobian with respect to x and u to obtain the
%system matrix A
[A,B] = jacobian_vehicle(p.x,uTrans,yTrans);

%obtain uncertain input
Y=B*(Y+(-yTrans));

%set up linearized system
linSys = linearSys('linSys',A,1); %B=1 as input matrix encountered in uncertain inputs

%save constant input
obj.linError.f0=f0;

%save linearization point
obj.linError.p=p;


%------------- END OF CODE --------------