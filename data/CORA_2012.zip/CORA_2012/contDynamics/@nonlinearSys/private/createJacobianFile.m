function createJacobianFile(obj)
% createJacobianFile - generates an mFile that allows to compute the
% jacobian at a certain state and input
%
% Syntax:  
%    createJacobianFile(obj)
%
% Inputs:
%    obj - nonlinear system object
%
% Outputs:
%
% Example: 
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: ---

% Author:       Matthias Althoff
% Written:      30-June-2009
% Last update:  ---
% Last revision: ---

%------------- BEGIN CODE --------------

    
%load first order jacobian
J=obj.jacobians.firstOrder;

[x,u,dx,du] = symVariables(obj,'LRbrackets');

%cd('D:\LSR_18Feb10\Software\dissertation\contDynamics\stateSpaceModels') %<-- change directory here
%cd('U:\Software\dissertation\contDynamics\stateSpaceModels') %<-- change directory here
%cd('/home/althoff/Software/Reach3/contDynamics/stateSpaceModels') %<-- change directory here
%cd('/home/althoff/Software/itsTrans/saves'); %<-- change directory here
cd('/media/New Volume/software/2011/CORA/contDynamics/stateSpaceModels') %<-- change directory here


fid = fopen('jacobian.m','w');
fprintf(fid, '%s\n\n', 'function [A,B]=jacobian(x,u)');

% SYSTEM MATRIX
% write "A=["
fprintf(fid, '%s', 'A=[');

%write each row
for iRow=1:(length(J.x(:,1)))
    for iCol=1:(length(J.x(1,:))-1)
        str=[char(J.x(iRow,iCol)),','];
        str=bracketSubs(str);
        %write in file
        fprintf(fid, '%s', str);
    end
    if iRow<length(J.x(:,1))
        %write last element
        str=[char(J.x(iRow,iCol+1)),';...'];
        str=bracketSubs(str);
        %write in file
        fprintf(fid, '%s\n', str);
    else
        %write last element
        str=[char(J.x(iRow,iCol+1)),'];']; 
        str=bracketSubs(str);
        %write in file
        fprintf(fid, '%s\n\n', str);   
    end
end


% INPUT MATRIX
% write "B=["
fprintf(fid, '%s', 'B=[');

%write each row
for iRow=1:(length(J.u(:,1)))
    if length(J.u(1,:))>1
        for iCol=1:(length(J.u(1,:))-1)
            str=[char(J.u(iRow,iCol)),','];
            str=bracketSubs(str);
            %write in file
            fprintf(fid, '%s', str);
        end
    else iCol=0;
    end
    
    if iRow<length(J.u(:,1))
        %write last element
        str=[char(J.u(iRow,iCol+1)),';...'];
        str=bracketSubs(str);
        %write in file
        fprintf(fid, '%s\n', str);    
    else
        %write last element
        str=[char(J.u(iRow,iCol+1)),'];']; 
        str=bracketSubs(str);
        %write in file
        fprintf(fid, '%s', str);
    end
end

%close file
status = fclose(fid);

function [str]=bracketSubs(str)

%generate left and right brackets
str=strrep(str,'L','(');
str=strrep(str,'R',')');


%------------- END OF CODE --------------