function [obj] = jacobians(obj)
% jacobians - computes the jacobians of the nonlinear system in a symbolic
% way; the result is stored in a m-file and passed by a handle
%
% Syntax:  
%    [obj] = jacobians(obj)
%
% Inputs:
%    obj - nonlinear system object
%
% Outputs:
%    obj - nonlinear system object
%
% Example: 
%    Text for example...
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: 

% Author: Matthias Althoff
% Written: 29-October-2007 
% Last update: ---
% Last revision: ---

%------------- BEGIN CODE --------------

%create symbolic variables
[x,u]=symVariables(obj,'LRbrackets');

%insert symbolic variables into the system equations
t=0;
fLR=obj.mFile(t,x,u);

%compute jacobian with respect to the state
Jx=jacobian(fLR,x);
%obj.jacobians.firstOrder.x=simple(Jx);
obj.jacobians.firstOrder.x=Jx;

%compute jacobian with respect to the input
Ju=jacobian(fLR,u);
%obj.jacobians.firstOrder.u=simple(Ju);
obj.jacobians.firstOrder.u=Ju;

%compute second order jacobians using 'LR' variables
J=jacobian(fLR,[x;u]);
for k=1:length(J(:,1))
    %Calculate 2nd order Jacobians
    Jxu=jacobian(J(k,:),[x;u]);
    %obj.jacobians.secondOrder(k,:,:)=simple(Jxu);
    obj.jacobians.secondOrder(k,:,:)=Jxu;
end

%generate mFile that computes the lagrange remainder and the jacobian
createJacobianFile(obj);
createRemainderFile(obj);
createHessianTensorFile(obj);
%createHessianTensorFile_interval(obj);

%------------- END OF CODE --------------