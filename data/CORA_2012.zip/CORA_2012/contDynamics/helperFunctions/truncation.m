function [obj,Rfirst,options] = truncation(obj,Rinit,options)
% reach - computes the reachable continuous set for the first time step
%
% Syntax:  
%    [obj,Rfirst,options] = initReach(obj,Rinit,options)
%
% Inputs:
%    obj - linearSys object
%    Rinit - initial reachable set
%    options - options for the computation of the reachable set
%
% Outputs:
%    obj - linearSys object
%    Rfirst - first reachable set 
%    options - options for the computation of the reachable set
%
% Example: 
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: none

% Author: Matthias Althoff
% Written:      07-May-2007 
% Last update:  03-January-2008
%               04-May-2009
%               29-June-2009
% Last revision: ---

%------------- BEGIN CODE --------------


%load data from object structure
eAt=obj.taylor.eAt;
F=obj.taylor.F;
Rinput=obj.taylor.Rinput;
Rtrans=obj.taylor.Rtrans;
inputCorr=obj.taylor.inputCorr;

%first time step homogeneous solution
Rhom_tp=eAt*Rinit;


%save homogeneous and particulate solution
options.Rhom=Rhom;
options.Raux=Rinput;
options.Rpar=intervalhull(Rtrans)+intervalhull(options.Raux+(-1*Rtrans));

%total solution
Rtotal=Rhom+options.Rpar+Rtrans;
Rtotal_tp=Rhom_tp+options.Rpar+Rtrans;

%write results to reachable set struct Rfirst
Rfirst.tp=Rtotal_tp;
Rfirst.ti=Rtotal;


%------------- END OF CODE --------------