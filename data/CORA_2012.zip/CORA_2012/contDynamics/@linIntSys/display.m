function display(obj)
% display - Displays a linIntSys object
%
% Syntax:  
%    display(obj)
%
% Inputs:
%    obj - linIntSys object
%
% Outputs:
%    ---
%
% Example: 
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: none

% Author: Matthias Althoff
% Written: 16-May-2007
% Last update: ---
% Last revision: ---

%------------- BEGIN CODE --------------

disp('-----------------------------------');

%display parent object
display(obj.contDynamics);

%display type
disp('type: Linear time continuous interval system');

%display A-Matrix
disp('System matrix: ');
A=obj.A

%display B-Matrix
disp('Input matrix: ');
B=obj.B

%display sample A-matrix
disp('Sample system matrix: ');
Asample=obj.sample.A

disp('-----------------------------------');

%------------- END OF CODE --------------