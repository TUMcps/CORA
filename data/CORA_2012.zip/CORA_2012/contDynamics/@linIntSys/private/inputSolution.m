function [obj] = inputSolution(obj,options)
% inputSolution - computes the bloating due to the input 
%
% Syntax:  
%    [obj] = inputSolution(obj,options)
%
% Inputs:
%    obj - linear interval system object
%    options - options struct
%
% Outputs:
%    obj - linear interval system object
%
% Example: 
%    Text for example...
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: expm, tie

% Author:       Matthias Althoff
% Written:      13-February-2007 
% Last update:  18-January-2008
%               22-June-2009
%               22-July-2009
% Last revision: ---

%------------- BEGIN CODE --------------

%set of possible inputs
V=obj.B*options.U;

%compute vTrans if possible
try
    vTrans=obj.B*options.uTrans;
catch
    vTrans=[];
end

%load data from object/options structure
A=obj.A;
Apower=obj.taylor.powers;
E=obj.taylor.error;
Asquare=obj.taylor.sq;
taylorTerms=options.taylorTerms;
r=options.timeStep;
dim=dimension(obj);


%compute nonlinear part:

%initialize Nsum,Asum
Nsum=0*Apower{1};
Asum=0*Apower{1};
%compute higher order terms
for i=2:taylorTerms
    %compute factor
    factor=1/factorial(i+1);  
    
    %compute Nsum
    Nsum=Nsum+Apower{i}*factor*r^(i+1)*V;

    %compute Asum
    Asum=Asum+Apower{i}*factor*r^(i+1);
end

%compute nonlinear solution
Ninput=Nsum+E*r*V;

%compute linear solution
Vlin=r*V+A*V*(r^2/2);

%generate identity matrix
I=eye(dim);

%prepare nonlinear solution for constant input
Asum=Asum+E*r;
midAsum=mid(Asum);
deltaAsum=Asum-midAsum;

%compute linear part:
%modify first uncertain matrix:
A{1}=A{1}+2*(I*r+midAsum)/r^2;

%get linear map for constant input
VlinTrans=1/2*r^2*(A*zonotope(vTrans));

%compute final results
inputSolV=Vlin+Ninput;
inputSolVtrans=VlinTrans+deltaAsum*vTrans;

%delete zero generators in zonotope representation
inputSolV=deleteZeros(inputSolV);
inputSolVtrans=deleteZeros(inputSolVtrans);

%compute additional uncertainty if origin is not contained in input set
if options.originContained
    inputCorr=zeros(dim,1);
else
    %compute inputF
    [obj]=inputTie(obj,options);
    inputF=obj.taylor.inputF;
    inputCorr=inputF*zonotope(vTrans);
end

%write to object structure
obj.taylor.V=V;
obj.taylor.Rinput=inputSolV+inputSolVtrans;
obj.taylor.Rtrans=inputSolVtrans;
obj.taylor.inputCorr=inputCorr;

%------------- END OF CODE --------------