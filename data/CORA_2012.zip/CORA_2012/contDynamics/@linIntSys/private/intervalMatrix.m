function [Aint] = intervalMatrix(A)
% intervalMatrix - computes the interval matrix of the uncertain matrix,
% where the elements of the interval matrix are assumed to be independent
%
% Syntax:  
%    [Aint] = intervalMatrix(A)
%
% Inputs:
%    A - uncertain matrix defined by a set of matrices A_i
%
% Outputs:
%    Aint - over-approximating interval matrix
%
% Example: 
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: 

% Author: Matthias Althoff
% Written: 04-January-2009 
% Last update: ---
% Last revision: ---

%------------- BEGIN CODE --------------

%number of uncertain parameters
nrOfParam=length(A)-1;

%compute sum of absolute value matrices
Asum=0*A{1};
for i=1:nrOfParam
    Asum=Asum+abs(A{i+1});
end

%generate interval matrix
Aint=interval(A{1}-Asum,A{1}+Asum);


%------------- END OF CODE --------------