function [obj,Rfirst,options] = initReach(obj,Rinit,options)
% reach - computes the reachable continuous set for the first time step
%
% Syntax:  
%    [obj,Rfirst] = initReach(obj,Rinit,options)
%
% Inputs:
%    obj - linIntSys object
%    Rinit - initial reachable set
%    options - options for the computation of the reachable set
%
% Outputs:
%    obj - linIntSys object
%    Rfirst - first reachable set 
%
% Example: 
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: none

% Author:       Matthias Althoff
% Written:      07-May-2007 
% Last update:  18-January-2008
%               22-June-2009
%               29-June-2009
% Last revision: ---

%------------- BEGIN CODE --------------

%do precomputations for the same time step exist?
if isempty(obj.taylor) | (obj.taylor.timeStep~=options.timeStep)
    % compute interval matrix for nonlinear map
    obj = nonlinMap(obj,options);
    % compute time interval error (tie)
    obj = tie(obj,options);
    % compute reachable set due to input
    obj = inputSolution(obj,options);
    %change the time step
    obj.taylor.timeStep=options.timeStep;
end

%compute reachable set of first time interval

%load data from object structure
F=obj.taylor.F;
Rinput=obj.taylor.Rinput;
Rtrans=obj.taylor.Rtrans;
inputCorr=obj.taylor.inputCorr;


%first time step homogeneous solution
[obj,Rhom_tp]=expMap(obj,Rinit,options);
Rhom=enclose(Rinit,Rhom_tp+Rtrans)+F*Rinit+inputCorr+(-1*Rtrans);
%total solution
Rtotal=Rhom+Rinput;
Rtotal_tp=Rhom_tp+Rinput;

%write results to reachable set struct Rfirst
Rfirst.tp=Rtotal_tp;
Rfirst.ti=Rtotal;


%------------- END OF CODE --------------