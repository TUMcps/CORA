function A = uniformSampling(obj,segments)
% uniformSampling - uniformly samples the uncertain system matrix
%
% Syntax:  
%    [obj] = sample(obj)
%
% Inputs:
%    obj - linIntSys object
%    segments - number of segments for each uncertain parameter
%
% Outputs:
%    A - cell array of system matrices
%
% Example: 
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: none

% Author: Matthias Althoff
% Written: 13-Jan-2009 
% Last update: ---
% Last revision: ---

%------------- BEGIN CODE --------------

%number of uncertain parameters
nrOfParam=length(obj.A)-1;

%obtain parameter values of the uncertain interval
paramValues=linspace(-1,1,segments);

%obtain full factorial combinations of uncertain parameters
comb=fullfact(segments*ones(nrOfParam,1));

%generate sample matrices
for i=1:length(comb(:,1))
    %init A{i}
    A{i}=obj.A{1};
    for k=1:nrOfParam
        %create uncertain parameter vector
        paramVal=paramValues(comb(i,k));
        %add partial matrix
        A{i}=A{i}+paramVal*obj.A{k+1};
    end
end

    
%------------- END OF CODE --------------