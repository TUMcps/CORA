function [allErr] = allowedError(obj,linIntSys,options)
% allowedError - computes the allowed linearization error
%
% Syntax:  
%    [obj] = linError(obj,options)
%
% Inputs:
%    obj - nonlinear system object
%    linSys - linear system object
%    options - options struct
%
% Outputs:
%    obj - nonlinear system object
%
% Example: 
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: 

% Author:       Matthias Althoff
% Written:      29-October-2007 
% Last update:  22-January-2008
%               12-August-2009
%               03-February-2010
% Last revision:---

%------------- BEGIN CODE --------------

%retrieve data
deltaT=options.timeStep;
expFactor=obj.expFactor;

%get taylor struct of the linear system
taylor=get(linIntSys,'taylor');
eAtInt=mid(taylor.eAtInt); %choose mid matrix of eAtInt

%allErr=eAtInt*deltaT*expFactor;
allErr=inv(eAtInt)*deltaT*expFactor;
allErr=abs(allErr);

%------------- END OF CODE --------------