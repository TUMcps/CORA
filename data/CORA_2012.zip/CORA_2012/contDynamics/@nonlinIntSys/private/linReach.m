function [Rti,Rtp,perfInd,nr] = linReach(obj,options,Rinit,iter)
% linReach - computes the reachable set after linearazation and returns if
% the initial set has to be split in order to control the linearization
% error
%
% Syntax:  
%    [Rti,Rtp,split,options] = linReach(obj,options,Rinit)
%
% Inputs:
%    obj - nonlinear system object
%    options - options struct
%    Rinit - initial reachable set
%
% Outputs:
%    Rti - reachable set for time interval
%    Rti - reachable set for time point
%    split - boolean value returning if initial set has to be split
%    options - options struct to return f0
%
% Example: 
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: 

% Author:       Matthias Althoff
% Written:      17-January-2008
% Last update:  30-June-2009
% Last revision: ---

%------------- BEGIN CODE --------------

% linearize nonlinear system
[obj,linIntSys,linOptions] = linearize(obj,options,Rinit); 

%translate Rinit by linearization point
Rdelta=Rinit+(-obj.linError.p.x);

% compute reachable set of linearized system
%ti: time interval, tp: time point
[linIntSys,R] = initReach(linIntSys,Rdelta,linOptions); 
Rtp=R.tp;
Rti=R.ti;

%translate reachable sets by linearization point
Rti=Rti+obj.linError.p.x;
Rtp=Rtp+obj.linError.p.x;

%new technique: compute reachable set due to assumed linearization error
[RallError] = errorSolution(linSys,obj.expFactor,options); 

%compute maximum reachable set due to maximal allowed linearization error
Rmax=Rti+RallError;

% obtain linearization error
[error] = linError(obj,options,Rmax);

% compute reachable set due to the linearization error
[Rerror] = errorSolution(linIntSys,error,options);

%compute performance index of linearization error
[perfInd,problemDim]=max(error./obj.expFactor);

if (perfInd>1) & (iter==1)
    %find best split
    nr=select(obj,options,Rtp,obj.expFactor);
else
    nr=[];
end

%add intervalhull of actual error
Rti=Rti+Rerror;
Rtp=Rtp+Rerror;

%------------- END OF CODE --------------