function [error] = linError(obj,options,R)
% linError - computes the linearization error
%
% Syntax:  
%    [obj] = linError(obj,options)
%
% Inputs:
%    obj - nonlinear system object
%    options - options struct
%    R - actual reachable set
%
% Outputs:
%    obj - nonlinear system object
%
% Example: 
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: 

% Author: Matthias Althoff
% Written: 29-October-2007 
% Last update: 22-January-2008
% Last revision: ---

%------------- BEGIN CODE --------------

%compute intervalhull of reachable set
IH=intervalhull(R);

%compute intervals of total reachable set
totalInt=interval(IH);

%compute intervals of input
if strcmp('intervalhull',class(options.U))
    IHinput=options.U + options.uTrans;
else
    IHinput=intervalhull(options.U) + options.uTrans;
end
inputInt=interval(IHinput);

%intervals of parameters
paramInt=options.paramInt;

%translate intervals by linearization point
IH=IH+(-obj.linError.p.x);
IHinput=IHinput + (-obj.linError.p.u);

%obtain maximum absolute values within IH, IHinput
IHinf=abs(inf(IH));
IHsup=abs(sup(IH));
dx=max(IHinf,IHsup);

IHinputInf=abs(inf(IHinput));
IHinputSup=abs(sup(IHinput));
du=max(IHinputInf,IHinputSup);

%compute linearization error by passing the intervals to the Lagrange
%remainder mFile
error=lagrangeRemainder(totalInt,inputInt,dx,du,paramInt);
error=abs(error);

%------------- END OF CODE --------------