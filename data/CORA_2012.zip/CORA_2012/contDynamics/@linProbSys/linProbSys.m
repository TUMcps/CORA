function Obj = linProbSys(varargin)
% linProbSys - Object and Copy Constructor (linProbSys: linear probabilistic system)
%
% Syntax:  
%    object constructor: Obj = class_name(varargin)
%    copy constructor: Obj = otherObj
%
% Inputs:
%    input1 - name
%    input2 - A-matrix
%    input3 - B-matrix
%
% Outputs:
%    Obj - Generated Object
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: linearSys

% Author: Matthias Althoff
% Written: 06-October-2007 
% Last update: 26-February-2008
% Last revision: ---

%------------- BEGIN CODE --------------

% If no argument is passed
if nargin == 0
    disp('This class needs more input values');
    Obj=[];
    
% If 3 arguments are passed
elseif nargin == 4
    %List elements of the class
    Obj.A=varargin{2};  
    Obj.B=varargin{3};
    Obj.C=varargin{4};    
    Obj.taylor=[];
    
    %Generate parent object
    cDyn=contDynamics(varargin{1},ones(length(varargin{2}),1),1,1);

    % Register the variable as an child object of contSet
    Obj = class(Obj, 'linProbSys', cDyn);    
        
% Else if the parameter is an identical object, copy object    
elseif isa(varargin{1}, 'linProbSys')
    Obj = varargin{1};
    
% Else if not enough or too many inputs are passed    
else
    disp('This class needs more/less input values');
    Obj=[];
end

%------------- END OF CODE --------------