function dim = dimension(obj)
% dimension - returns the dimension of the mptPolytope
%
% Syntax:  
%    dim = dimension(obj)
%
% Inputs:
%    obj - mptPolytope object
%
% Outputs:
%   dim - dimension of the mptPolytope
%
% Example: 
%    ---
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: ---

% Author:       Matthias Althoff
% Written:      16-July-2015
% Last update:  ---
% Last revision:---

%------------- BEGIN CODE --------------

%return dimension
dim = length(obj.P.H(:,end));

%------------- END OF CODE --------------