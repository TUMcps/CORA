function [subscriptMatrix]=cellSegments(Obj,indexVector)
% Purpose:  accesses private i2s function
% Pre:      partition object, index vector
% Post:     cell segments
% Built:    27.03.08,MA


subscriptMatrix=i2s(Obj,indexVector);