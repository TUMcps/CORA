function [c]=centerSegment(field)
% Purpose:  find center for particulate solution
% Pre:      partition object
% Post:     center
% Modified: 13.11.07

%interval hull and middle of discretized state space----
intervals=get(field,'intervals');
stateSpace_IH=intervalhull(intervals);
middle=center(stateSpace_IH);
%-------------------------------------------------------

%find center of cell that contains state space middle---
index=findSegments(field,[middle,middle]);
IH=intervalhull(segmentIntervals(field,index));
c.val=center(IH);
c.ind=index;
%-------------------------------------------------------