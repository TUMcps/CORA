function Obj = partition(varargin)
% Purpose:  1. Object constructor
%           2. Copy constructor
% Pre:      1st Parameter - state space itervals
%           2nd Parameter - number of segments 
%           3rd Parameter - actual segment number 
%           4th Parameter - mode of actual cell
%           5th Parameter - segment length
%           Object as Parameter - Copy constructor
% Post:     Return a created object
% Tested:   14.09.06,MA


% If no argument is passed (default constructor)
if nargin == 0
    disp('Partition needs more input values');
    Obj=[];
    % Register the variable as an object
    Obj = class(Obj, 'partition');        
    
% If two arguments are passed 
elseif nargin == 2
    %=======================================================
    Obj.intervals=varargin{1};
    Obj.nrOfSegments=varargin{2};
    Obj.actualSegmentNr=0;    
    Obj.mode=[];  
    % Get segment length for each dimension 
    Obj.segmentLength=...
         (Obj.intervals(:,2)-Obj.intervals(:,1))./Obj.nrOfSegments;    
    %=======================================================
    % Register the variable as an object
    Obj = class(Obj, 'partition');   
    
% Else if the parameter is an identical object, copy object    
elseif isa(varargin{1}, 'partition')
    Obj = varargin{1};
    
% Otherwise use a specific constructor    
else
    disp('Partition needs more/less input values');
    Obj=[];
end