function val = get(obj, propName)
% get - Retrieve object data from obj
%
% Syntax:  
%    val = get(obj, propName)
%
% Properties:
%    intervals - intervals of interval hull object

% Author:       Matthias Althoff
% Written:      12-February-2012
% Last update: 	---
% Last revision:---

%------------- BEGIN CODE --------------

switch propName 
    case 'equations'
        val = obj.halfspace.equations;
    otherwise
        error([propName,' is not a valid asset property'])
end

%------------- END OF CODE --------------