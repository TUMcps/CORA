function [P] = plus(summand1,summand2)
% plus - overloaded '+' operator for the addition of a vector to a
% mptPolytope; Minkowski addition is also supported
%
% Syntax:  
%    [P] = plus(summand1,summand2)
%
% Inputs:
%    summand1 - mptPolytope object or numerical vector
%    summand2 - mptPolytope object or numerical vector
%
% Outputs:
%    P - mptPolytope object
%
% Example: 
%    ---
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: mtimes

% Author:       Matthias Althoff
% Written:      20-October-2010
% Last update:  ---
% Last revision:---

%------------- BEGIN CODE --------------

%Find a pplPolytope object
%Is summand1 a mptPolytope?
if strcmp('mptPolytope',class(summand1))
    %initialize resulting mptPolytope
    P=summand1;
    %initialize other summand
    summand=summand2;
%Is summand2 a mptPolytope?    
elseif strcmp('mptPolytope',class(summand2))
    %initialize resulting mptPolytope
    P=summand2;
    %initialize other summand
    summand=summand1;  
end

%Is summand a vector?
if isnumeric(summand)
    dim = length(summand);
    P.P = range(P.P, eye(dim), summand);
    
%is summand a polytope?
elseif strcmp('mptPolytope',class(summand))
    P.P = P.P + summand.P;
end

%------------- END OF CODE --------------