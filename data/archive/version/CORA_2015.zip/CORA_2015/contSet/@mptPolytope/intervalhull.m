function IH = intervalhull(obj)
% intervalhull - encloses a mptPolytope by an intervalhull
%
% Syntax:  
%    IH = intervalhull(obj)
%
% Inputs:
%    obj - mptPolytope object
%
% Outputs:
%   IH - interval hull
%
% Example: 
%    ---
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: ---

% Author:       Matthias Althoff
% Written:      01-February-2011
% Last update:  ---
% Last revision:---

%------------- BEGIN CODE --------------

%obtain bounding box in halfspace representation
B = bounding_box(obj.P);

%get C matrix, d vector
[C,d] = double(B);

%get indices of left limit
[row,col]=find(C==-1);
%construct left limit
leftLim = -d(row(col));

%get indices of right limit
[row,col]=find(C==1);
%construct left limit
rightLim = d(row(col));

%instantiate interval hull
try
    IH = intervalhull([leftLim,rightLim]);
catch
    disp('intervalhull generation failed');
end



%------------- END OF CODE --------------