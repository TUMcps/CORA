function obj = abs(obj)
% abs - returns the absolute value bound of an interval hull
%
% Syntax:  
%    obj = abs(obj) 
%
% Inputs:
%    intMat - interval matrix
%
% Outputs:
%    intMat - interval matrix
%
% Example: 
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: OTHER_FUNCTION_NAME1,  OTHER_FUNCTION_NAME2

% Author:       Matthias Althoff
% Written:      01-October-2010
% Last update:  ---
% Last revision:---

%------------- BEGIN CODE --------------

val=max(abs(obj.intervals(:,1)), abs(obj.intervals(:,2)));

obj.intervals(:,1)=-val;
obj.intervals(:,2)=val;

%------------- END OF CODE --------------