function [result] = in(obj1,obj2)
% in - determines if elements of a zonotope obj2 are in an interval hull
% obj1 in an overapproximate way
%
% Syntax:  
%    [result] = in(obj1,obj2)
%
% Inputs:
%    obj1 - intervalhull object
%    obj2 - zonotope object
%
% Outputs:
%    result - 1/0 if zonotope is in, or not
%
% Example: 
%    ---
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: ---

% Author:       Matthias Althoff
% Written:      07-May-2007 
% Last update:  04-January-2008
% Last revision:---

%------------- BEGIN CODE --------------

%conservative approximation:
%the zonotope is still in the intervalhull if the
%enclosing intervalhull of the zonotope is in the intervalhull

%1st case: obj2 is a single zonotope
if ~iscell(obj2)
    %make an intervalhull of obj2
    IH=intervalhull(obj2);

    %check if intervals intersect
    int=(sup(obj1)<inf(IH))|(sup(IH)<inf(obj1));
    result=~any(int);
%2nd case: obj2 is a cell array
else
    for i=1:length(obj2)
        %code to be entered...
    end
end
%------------- END OF CODE --------------