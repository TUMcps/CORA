function [c]=center(obj)
% center - Returns the geometric center of an interval hull 
%
% Syntax:  
%    [c]=center(obj)
%
% Inputs:
%    obj - interval hull object
%
% Outputs:
%    c - geometric center of interval hull
%
% Example: 
%    IH=intervalhull([1 2; -1 1]);
%    c=center(IH)
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: edgeLength

% Author: Matthias Althoff
% Written: 14-September-2006 
% Last update: 26-March-2007
%              03-February-2009
% Last revision: ---

%------------- BEGIN CODE --------------

%obtain intervals
intervals=obj.intervals;

%compute center
c=(intervals(:,1)+intervals(:,2))/2;

%------------- END OF CODE --------------