function [I]=interval(obj)
% interval - Converts an interval hull object to an interval object
%
% Syntax:  
%    [I]=interval(obj)
%
% Inputs:
%    obj - interval hull object
%
% Outputs:
%    I - interval object
%
% Example: 
%    IH=intervalhull([1 2; -1 1]);
%    I=interval(IH);
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: zonotope, polytope

% Author:       Matthias Althoff
% Written:      14-September-2006 
% Last update:  26-March-2007
%               15-December-2010
% Last revision:---

%------------- BEGIN CODE --------------

%load intervals 
intervals=obj.intervals;

%generate interval object
I=infsup(intervals(:,1),intervals(:,2));

%------------- END OF CODE --------------