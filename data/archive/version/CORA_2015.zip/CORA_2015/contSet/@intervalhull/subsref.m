function [element] = subsref(obj, S)
% subsref - Overloads the opertor that selects elements, e.g. IH(1,2),
% where the element of the first row and second column is referred to.
%
% Syntax:  
%    [element] = subsref(obj, S)
%
% Inputs:
%    obj - intervalhull object 
%    S - contains information of the type and content of element selections  
%
% Outputs:
%    element - element or elemets of the interval hull matrix
%
% Example: 
%    IH=intervalhull([1 2; -1 1]);
%    IH(2,2)
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: none

% Author: Matthias Althoff
% Written: 30-September-2006 
% Last update: 23-March-2007
% Last revision: ---

%------------- BEGIN CODE --------------

%obtain interval hull matrix from the interval hull object
IHmatrix=obj.intervals;
%check if parantheses are used to select elements
if strcmp(S.type,'()')
    if length(S.subs)==2
        %Select column of V
        if strcmp(S.subs{1},':')
            column=S.subs{2};
            element=IHmatrix(:,column);
        %Select row of V    
        elseif strcmp(S.subs{2},':')
            row=S.subs{1};
            element=IHmatrix(row,:);
        %Select single element of V    
        elseif isnumeric(S.subs{1})&isnumeric(S.subs{1})
            row=S.subs{1};
            column=S.subs{2};
            element=IHmatrix(row,column);
        end
    %no selection if elements not proper specified  
    else
        element=[];
    end
%no selection if parantheses are not used    
else
    element=[];
end

%------------- END OF CODE --------------