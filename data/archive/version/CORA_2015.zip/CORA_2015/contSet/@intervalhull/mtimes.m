function [IH] = mtimes(factor1,factor2)
% mtimes - Overloaded '*' operator for the multiplication of a matrix or an
% interval matrix with an interval hull
%
% Syntax:  
%    [IH] = mtimes(matrix,IH)
%
% Inputs:
%    matrix - numerical or interval matrix
%    IH - interval hull object 
%
% Outputs:
%    IH - Interval hull after multiplication of a matrix with an interval
%    hull
%
% Example: 
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: plus

% Author:       Matthias Althoff
% Written:      11-March-2008
% Last update:  14-July-2009
%               06-November-2009
% Last revision: ---

%------------- BEGIN CODE --------------

%Find a interval hull object
%Is factor1 an intervalhull?
if strcmp('intervalhull',class(factor1))
    %initialize resulting interval hull
    IH=factor1;
    %initialize other summand
    matrix=factor2;
%Is factor2 an intervalhull?    
elseif strcmp('intervalhull',class(factor2))
    %initialize resulting intervalhull
    IH=factor2;
    %initialize other summand
    matrix=factor1;  
end

%numeric matrix
if isscalar(matrix)
    IH.intervals=matrix*IH.intervals;
    
%interval matrix or numerical matrix
else
    %convert intervalhull to interval
    I=interval(IH);
    %multiply
    I=matrix*I;
    %convert result to interval hull
    IH.intervals=[inf(I),sup(I)];   
end


  


%------------- END OF CODE --------------