function [obj]=bloat(obj,factor)
% bloat - Bloats an interval hull by a certain factor
%
% Syntax:  
%    [obj]=bloat(obj,factor)
%
% Inputs:
%    obj - interval hull object
%    factor - bloating factor
%
% Outputs:
%    obj - bloated interval hull object
%
% Example: 
%    IH=intervalhull([1 2; -1 1]);
%    IH=bloat(IH,2);
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: plus

% Author: Matthias Althoff
% Written: 14-September-2006 
% Last update: 26-March-2007
% Last revision: ---

%------------- BEGIN CODE --------------

%get center and edge length
c=center(obj);
edgeLen=edgeLength(obj);

%bloated intervals
obj.intervals=[c-edgeLen*factor/2,c+edgeLen*factor/2];

%------------- END OF CODE --------------