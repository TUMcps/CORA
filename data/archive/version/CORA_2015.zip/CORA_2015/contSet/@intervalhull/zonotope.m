function [Z]=zonotope(obj)
% interval - Converts an interval hull object to a zonotope object
%
% Syntax:  
%    [Z]=zonotope(obj)
%
% Inputs:
%    obj - interval hull object
%
% Outputs:
%    Z - zonotope object
%
% Example: 
%    IH=intervalhull([1 2; -1 1]);
%    Z=zonotope(IH);
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: interval, polytope

% Author: Matthias Althoff
% Written: 14-September-2006 
% Last update: 26-March-2007
% Last revision: ---

%------------- BEGIN CODE --------------

%obtain intervals
intervals=obj.intervals;

%obtain center
c=center(obj);

%construct generator matrrix G
G=diag((intervals(:,2)-intervals(:,1))/2);

%instantiate zonotope
Z=zonotope([c,G]);

%------------- END OF CODE --------------