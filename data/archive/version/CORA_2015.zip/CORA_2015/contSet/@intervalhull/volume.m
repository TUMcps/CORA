function [V]=volume(obj)
% vertices - Computes volume of an interval hull 
%
% Syntax:  
%    [V]=volume(obj)
%
% Inputs:
%    obj - interval hull object
%
% Outputs:
%    V - volume
%
% Example: 
%    IH=intervalhull([1 2; -1 1]);
%    V=volume(IH);
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: ---

% Author: Matthias Althoff
% Written: 16-October-2007 
% Last update: ---
% Last revision: ---

%------------- BEGIN CODE --------------

if ~isempty(obj.intervals)
    V=prod(edgeLength(obj));
else
    V=0;
end

%------------- END OF CODE --------------