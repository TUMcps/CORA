function plot(varargin)
% plot - Plots 2-dimensional projection of an interval hull
%
% Syntax:  
%    plot(obj,dimensions)
%
% Inputs:
%    obj - interval hull object
%    dimensions - dimensions that should be projected (optional) 
%
% Outputs:
%    none
%
% Example: 
%    IH=intervalhull([1 2; -1 1]);
%    plot(IH)
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: none

% Author: Matthias Althoff
% Written: 30-September-2006 
% Last update: 22-March-2007
% Last revision: ---

%------------- BEGIN CODE --------------

%convert to zonotope
Z=zonotope(varargin{1});
    
%plot zonotope
if nargin==1
    plot(Z);
elseif nargin==2
    plot(Z,varargin{2});
else
    plot(Z,varargin{2},varargin{3});
end

%------------- END OF CODE --------------