function [obj]=or(obj,IH)
% or - Computes union of interval hulls 
%
% Syntax:  
%    [obj]=or(obj,IH)
%
% Inputs:
%    obj - interval hull object
%    IH - interval hull
%
% Outputs:
%   obj - interval hull object
%
% Example: 
%    IH=intervalhull([1 2; -1 1]);
%    IH2=intervalhull([1.5 2.5; -2 0]);
%    IH=IH|IH2
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: ---

% Author: Matthias Althoff
% Written: 04-January-2008
% Last update: ---
% Last revision: ---

%------------- BEGIN CODE --------------

if isempty(obj.intervals)
    obj = IH;
elseif isempty(get(IH,'intervals'))
    %do nothing
else
    obj.intervals(:,1)=min([obj.intervals(:,1),IH.intervals(:,1)],[],2);
    obj.intervals(:,2)=max([obj.intervals(:,2),IH.intervals(:,2)],[],2);
end

%------------- END OF CODE --------------