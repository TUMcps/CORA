function [P]=polytope(obj,options)
% polytope - Converts an interval hull object to a polytope object
%
% Syntax:  
%    [P]=polytope(obj)
%
% Inputs:
%    obj - interval hull object
%
% Outputs:
%    P - polytope object
%
% Example: 
%    IH=intervalhull([1 2; -1 1]);
%    P=polytope(IH);
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: zonotope, interval

% Author:       Matthias Althoff
% Written:      14-September-2006 
% Last update:  30-January-2008
%               19-October-2010
%               28-March-2012
% Last revision:---

%------------- BEGIN CODE --------------

%if halfspace representation has been computed
if ~isempty(obj.halfspace)
    %P=polytope(obj.halfspace.H,obj.halfspace.K);
    %P=pplPolytope(obj.halfspace.H,obj.halfspace.K);
    if strcmp(options.polytopeType,'mpt')
        P=mptPolytope(obj.halfspace.H,obj.halfspace.K);
    else
        P=pplPolytope(obj.halfspace.H,obj.halfspace.K);
    end
else
    %obtain zonotope
    Z=zonotope(obj);
    %instantiate polytope
    opt.polytopeType = '';
    P=exactPolytope(Z, opt);
end


%------------- END OF CODE --------------