function [coordinateMat]=relativeGridPoints(obj,rot,trans,intervals)
% relativeGridPoints - Computes grid points of two identical interval 
% hulls using gridPoints(); the second hull is translated and rotated and
% all combinations of relative positions of grid points are returned
%
% Syntax:  
%    [coordinateMat]=relativeGridPoints(obj,rot,trans,intervals)
%
% Inputs:
%    obj - interval hull object
%    rot - rotation matrix
%    trans - translation vector
%    intervals - number of intervals for each dimension
%
% Outputs:
%    coordinateMat - matrix where columns are the relative positions of
%    grid points
%
% Example: 
%    ---
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: ---

% Author: Matthias Althoff
% Written: 17-June-2009 
% Last update: ---
% Last revision: ---

%------------- BEGIN CODE --------------

%compute grid points
originalPoints=gridPoints(obj,intervals);

%compute translated and rotated points
nrOfPoints=length(originalPoints(1,:));
movedPoints=rot*originalPoints+trans*ones(1,nrOfPoints);

%compute all combinations of relative positions
comb=fullfact([nrOfPoints,nrOfPoints]);

for i=1:length(comb(:,1))
    coordinateMat(i,:)=movedPoints(:,comb(i,2))-originalPoints(:,comb(i,1));
end


%------------- END OF CODE --------------