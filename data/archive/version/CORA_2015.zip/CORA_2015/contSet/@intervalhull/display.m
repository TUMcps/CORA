function display(obj)
% display - Displays the matrix of left and right limit of the interval
% hull
%
% Syntax:  
%    display(obj)
%
% Inputs:
%    obj - interval hull object
%
% Outputs:
%    ---
%
% Example: 
%    IH=intervalhull([1 2; -1 1]);
%    display(IH);
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: none

% Author: Matthias Althoff
% Written: 14-September-2006 
% Last update: 26-March-2007
% Last revision: ---

%------------- BEGIN CODE --------------

disp('Intervals: ');
for i=1:length(obj.intervals(:,1))
    disp(['[',num2str(obj.intervals(i,1)),',',num2str(obj.intervals(i,2)),']']);
end

%------------- END OF CODE --------------