function [obj1]=enclose(obj1,obj2)
% enclose - Computes an interval hull that encloses two interval hulls
%
% Syntax:  
%    [obj1]=enclose(obj1,obj2)
%
% Inputs:
%    obj1 - interval hull object
%    obj2 - another interval hull object
%
% Outputs:
%    obj1 - enclosing interval hull 
%
% Example: 
%    IH1=intervalhull([1 2; -1 1]);
%    IH2=intervalhull([2 3; -2 0]);
%    IH3=enclose(IH1,IH2);
%    plot(IH1);
%    hold on
%    plot(IH2);
%    plot(IH3);
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: ---

% Author: Matthias Althoff
% Written: 14-September-2006 
% Last update: 26-March-2007
% Last revision: ---

%------------- BEGIN CODE --------------

obj1.intervals(:,1)=min([obj1.intervals(:,1),obj2.intervals(:,1)],[],2);
obj1.intervals(:,2)=max([obj1.intervals(:,2),obj2.intervals(:,2)],[],2);

%------------- END OF CODE --------------