function [r]=radius(obj)
% radius - Computes radius of an interval hull 
%
% Syntax:  
%    [r]=radius(obj)
%
% Inputs:
%    obj - interval hull object
%
% Outputs:
%    r - radius of enclosing hyperball
%
% Example: 
%    ---
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: ---

% Author: Matthias Althoff
% Written: 27-January-2009
% Last update: ---
% Last revision: ---

%------------- BEGIN CODE --------------

%compte edge length
edgeLen=edgeLength(obj);

%compute radius
r=sqrt(sum(edgeLen.^2));

%------------- END OF CODE --------------