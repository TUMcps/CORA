function [obj,Rfirst,options] = initReach_box(obj,Rinit,options)
% reach - computes the reachable continuous set for the first time step
%
% Syntax:  
%    [obj,Rfirst,options] = initReach(obj,Rinit,options)
%
% Inputs:
%    obj - linearSys object
%    Rinit - initial reachable set
%    options - options for the computation of the reachable set
%
% Outputs:
%    obj - linearSys object
%    Rfirst - first reachable set 
%    options - options for the computation of the reachable set
%
% Example: 
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: none

% Author: Matthias Althoff
% Written:      07-May-2007 
% Last update:  03-January-2008
%               04-May-2009
%               29-June-2009
% Last revision: ---

%------------- BEGIN CODE --------------

%do precomputations for the same time step exist?
if isempty(obj.taylor) | (obj.taylor.timeStep~=options.timeStep)
    % compute exponential matrix
    obj = exponential(obj,options);
    % compute time interval error (tie)
    obj = tie(obj,options);
    % compute reachable set due to input
    obj = inputSolution(obj,options);
    %obj = apprInputSolution(obj,options);
    %change the time step
    obj.taylor.timeStep=options.timeStep;
end

%compute reachable set of first time interval
%load data from object structure
eAt=obj.taylor.eAt;
F=obj.taylor.F;
Rinput=obj.taylor.Rinput;
Rtrans=obj.taylor.Rtrans;
inputCorr=obj.taylor.inputCorr;


%first time step homogeneous solution
Rhom_tp=eAt*Rinit;

%for polytope comparison:
RinitBox = interval(intervalhull(Rinit));
Fres = F*RinitBox;
Fset = intervalhull([inf(Fres),sup(Fres)]);

%change in computation for polytope examples
if isa(Rinit,'mptPolytope')

    Rhom=enclose(Rinit,Rhom_tp)+mptPolytope(Fset); %<-- changed for polytope comparison
else
    %original computation
    RinitBox = interval(intervalhull(Rinit));
    Rhom=enclose(Rinit,Rhom_tp+Rtrans)+zonotope(Fset)+inputCorr+(-1*Rtrans); %<-- changed for polytope comparison
    %Rhom=enclose(Rinit,Rhom_tp+Rtrans)+F*Rinit+inputCorr+(-1*Rtrans);
end


%save homogeneous and particulate solution
options.Rhom=Rhom;
options.Raux=Rinput;
options.Rpar=center(Rtrans)+intervalhull(options.Raux+(-1*Rtrans));

%total solution
if isa(Rinit,'mptPolytope')
    %convert zonotopes to polytopes
    Radd=mptPolytope(intervalhull(Rinput));
    Rtotal=Rhom+Radd;
    Rtotal_tp=Rhom_tp+Radd;
else
    %original computation
    Rtotal=Rhom+intervalhull(Rinput);
    Rtotal_tp=Rhom_tp+intervalhull(Rinput);
end

%write results to reachable set struct Rfirst
Rfirst.tp=Rtotal_tp;
Rfirst.ti=Rtotal;


%------------- END OF CODE --------------