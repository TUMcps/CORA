function [obj] = apprInputSolution(obj,options)
% apprInputSolution - computes the approximating bloating due to the input 
%
% Syntax:  
%    [obj] = apprInputSolution(obj,options)
%
% Inputs:
%    obj - linearSys object
%
% Outputs:
%    obj - linearSys object
%    options - options for the computation of the reachable set
%
% Example: 
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: ---

% Author:       Matthias Althoff
% Written:      14-July-2009
% Last update:  ---
% Last revision:---

%------------- BEGIN CODE --------------

%set of possible inputs
V=obj.B*options.U;

%compute vTrans if possible
try
    vTrans=obj.B*options.uTrans;
catch
    vTrans=[];
end

%COMMENT: f0=uTrans for nonlinear systems

A=obj.A;
r=options.timeStep;
F=obj.taylor.F;

simSteps=10;

%init input solution
inputSolV=zonotope(zeros(length(A),1));
inputSolV_IH=intervalhull(inputSolV);

for i=1:simSteps
    %compute tstart and tfinal
    tstart=(i-1)*options.timeStep/simSteps;
    tfinal=i*options.timeStep/simSteps;  
    
    %compute matrix exponential integral
    expInt=expIntegral(A,tstart,tfinal);
    
    %add partial solution to full solution
    inputSolV=inputSolV+expInt*V;
    inputSolV_IH=inputSolV_IH+intervalhull(expInt*V);
end
inputSolV_old=expIntegral(A,0,r)*V;

%Compute input solution for transition input
invA=inv(A);
expA=expm(A*r);
I=eye(length(A));
inputSolVtrans=invA*(expA-I)*vTrans;

%compute additional uncertainty if origin is not contained in input set
if options.originContained
    inputCorr=zeros(length(A),1);
else
    inputCorr=invA*F*vTrans;
end

%write to object structure
obj.taylor.invA=invA;
obj.taylor.V=V;
obj.taylor.Vges=V+vTrans;
obj.taylor.Rinput.V=inputSolV;
obj.taylor.Rinput.vTrans=inputSolVtrans;
obj.taylor.Rinput.Corr=inputCorr;

function expInt=expIntegral(A,r1,r2)

%identity matrix
I=eye(length(A));

%compute inverse and exponential of system matrix A
invA=inv(A);
expA1=expm(A*r1);
expA2=expm(A*r2);

%Compute exponential integral
expInt1=invA*(expA1-I);
expInt2=invA*(expA2-I);

%final solution
expInt=expInt2-expInt1;

%------------- END OF CODE --------------