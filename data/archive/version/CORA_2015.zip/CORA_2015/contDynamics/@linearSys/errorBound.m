function [Zerror] = errorBound(obj,R,f0,normRatio,evolRatio)
% linError - computes the linearization error
%
% Syntax:  
%    [obj] = linError(obj,options)
%
% Inputs:
%    obj - nonlinear system object
%    options - options struct
%    R - actual reachable set
%
% Outputs:
%    obj - nonlinear system object
%
% Example: 
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: 

% Author: Matthias Althoff
% Written: 03-January-2008 
% Last update: ---
% Last revision: ---

%------------- BEGIN CODE --------------

%determine maximum allowed enlargement of reachable set
%compute travelled vector of zonotope center
x0=center(R);
eAt=obj.taylor.eAt;
A=obj.A;

dim=length(f0);
I=eye(dim);
O=zeros(dim,1);

trans=(eAt-I)*x0+inv(A)*(eAt-I)*f0;

errorVector=norm(trans)*evolRatio*normRatio;
Zerror=zonotope([O,diag(errorVector)]);

%------------- END OF CODE --------------