function Obj = contDynamics(varargin)
% contDynamics - Object and Copy Constructor 
%
% Syntax:  
%    object constructor: Obj = class_name(varargin)
%    copy constructor: Obj = otherObj
%
% Inputs:
%    input1 - name of the continuous dynamics: char array
%    input2 - stateIDs: int array
%    input3 - inputIDs: int array
%    input4 - outputIDs: int array
%
% Outputs:
%    Obj - Generated Object
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: ---

% Author: Matthias Althoff
% Written: 02-May-2007 
% Last update: ---
% Last revision: ---

%------------- BEGIN CODE --------------

% If no argument is passed
if nargin == 0
    disp('This class needs more input values');
    Obj.name=[];
    Obj.stateIDs=[];
    Obj.inputIDs=[];
    Obj.outputIDs=[];
    Obj.dim=[];
    
    % Register the variable as an object
    Obj = class(Obj, 'contDynamics');
    
% If 4 arguments are passed
elseif nargin == 4
    %List elements of the class
    Obj.name=varargin{1};
    Obj.stateIDs=varargin{2};
    Obj.inputIDs=varargin{3};
    Obj.outputIDs=varargin{4};
    Obj.dim=length(Obj.stateIDs);

    % Register the variable as an object
    Obj = class(Obj, 'contDynamics');
        
% Else if the parameter is an identical object, copy object    
elseif isa(varargin{1}, 'contDynamics')
    Obj = varargin{1};
    
% Else if not enough or too many inputs are passed    
else
    disp('This class needs more/less input values');
    Obj=[];
end

%------------- END OF CODE --------------