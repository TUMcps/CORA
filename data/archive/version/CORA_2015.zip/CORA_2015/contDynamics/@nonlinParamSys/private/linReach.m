function [Rti,Rtp,perfInd,nr] = linReach(obj,options,Rinit,iter)
% linReach - computes the reachable set after linearazation and returns if
% the initial set has to be split in order to control the linearization
% error
%
% Syntax:  
%    [Rti,Rtp,split,options] = linReach(obj,options,Rinit)
%
% Inputs:
%    obj - nonlinear system object
%    options - options struct
%    Rinit - initial reachable set
%
% Outputs:
%    Rti - reachable set for time interval
%    Rti - reachable set for time point
%    split - boolean value returning if initial set has to be split
%    options - options struct to return f0
%
% Example: 
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: 

% Author:       Matthias Althoff
% Written:      17-January-2008
% Last update:  29-June-2009
%               23-July-2009
% Last revision: ---

%------------- BEGIN CODE --------------

% linearize nonlinear system
[obj,linSys,linOptions] = linearize(obj,options,Rinit); 

%translate Rinit by linearization point
Rdelta=Rinit+(-obj.linError.p.x);

% compute reachable set of linearized system
%ti: time interval, tp: time point
[linSys,R] = initReach_inputDependence(linSys,Rdelta,linOptions);
%[linSys2,R2] = initReach(linSys,Rdelta,linOptions);
Rtp=R.tp;
Rti=R.ti;

%new technique: compute reachable set due to assumed linearization error
Verror = zonotope([0*obj.allowedError,diag(obj.allowedError)]);
[RallError] = errorSolution(linSys,Verror,options); 

%compute maximum reachable set due to maximal allowed linearization error
Rmax=Rti+RallError;

% obtain linearization error
if options.advancedLinErrorComp
    [Verror,error] = linError_quadratic(obj,options,Rmax);
else
    [error] = linError(obj,options,Rmax);
    Verror=zonotope([0*error,diag(error)]);
end

% compute reachable set due to the linearization error
[Rerror] = errorSolution(linSys,Verror,options);


%translate reachable sets by linearization point
Rti=Rti+obj.linError.p.x;
Rtp=Rtp+obj.linError.p.x;

%compute performance index of linearization error
perfInd = max(error./obj.allowedError)

if (perfInd>1) && (iter==1)
    %find best split
    nr=select(obj,options,Rinit,obj.allowedError);
else
    nr=[];
end

%add intervalhull of actual error
Rti=Rti+Rerror;
Rtp=Rtp+Rerror;


%------------- END OF CODE --------------