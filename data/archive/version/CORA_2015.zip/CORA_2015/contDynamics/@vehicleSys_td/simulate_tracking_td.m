function [obj,t,x,index,sol] = simulate_tracking_td(obj,opt,tstart,tfinal,hist,options)
% simulate - simulates the system within a location
%
% Syntax:  
%    [obj,t,x,index] = simulate_tracking_td(obj,opt,tstart,tfinal,x0,options)
%
% Inputs:
%    obj - vehicleSys_td object
%    opt - simulation-related options
%    tstart - start time
%    tfinal - final time
%    x0 - initial state 
%    options - contains, e.g. the events when a guard is hit
%
% Outputs:
%    obj - linearSys object
%    t - time vector
%    x - state vector
%    index - returns the event which has been detected
%
% Example: 
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: none

% Author:       Matthias Althoff
% Written:      06-August-2012
% Last update:  ---
% Last revision:---

%------------- BEGIN CODE --------------

%simulate
sol = dde23(getfcn_tracking_td(obj,opt),opt.lag,hist,[tstart, tfinal],options);

t = sol.x';
x = sol.y';
index = [];


%------------- END OF CODE --------------