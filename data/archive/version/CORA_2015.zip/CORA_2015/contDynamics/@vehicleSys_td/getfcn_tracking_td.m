function [handle] = getfcn_tracking_td(obj,options)
% getfcn_tracking_td - returns the function handle of the continuous function specified
% by the vehicle dynamics object
%
% Syntax:  
%    [handle] = getfcn(obj,options)
%
% Inputs:
%    obj - linearSys object
%    options - options struct
%
% Outputs:
%    handle - function handle
%
% Example: 
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: none

% Author:       Matthias Althoff
% Written:      06-August-2012
% Last update:  ---
% Last revision:---

%------------- BEGIN CODE --------------

function dxdt = f(t,x,Z)
    dxdt = obj.mFile(t,x,Z,options.u,options.y,options.p);
end

handle = @f;
end


%------------- END OF CODE --------------