function createJacobianFile(obj)
% createJacobianFile - generates an mFile that allows to compute the
% jacobian at a certain state and input
%
% Syntax:  
%    createJacobianFile(obj)
%
% Inputs:
%    obj - nonlinear system object
%
% Outputs:
%
% Example: 
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: ---

% Author:       Matthias Althoff
% Written:      30-June-2009
% Last update:  ---
% Last revision: ---

%------------- BEGIN CODE --------------

    
%load first order jacobian
J=obj.jacobians.firstOrder;

[x,u,dx,du] = symVariables(obj,'LRbrackets');

cd('/media/New Volume/software/2011/CORA/contDynamics/stateSpaceModels') %<-- change directory here

fid = fopen('jacobian.m','w');
fprintf(fid, '%s\n\n', 'function [A,B]=jacobian(x,u,p)');

% SYSTEM MATRIX
% write "A=["
fprintf(fid, '%s', 'A=[');

%write each row
for iRow=1:(length(J.x(:,1)))
    for iCol=1:(length(J.x(1,:))-1)
        str=bracketSubs(char(J.x(iRow,iCol)));
        str=[str,','];
        %write in file
        fprintf(fid, '%s', str);
    end
    if iRow<length(J.x(:,1))
        %write last element
        str=bracketSubs(char(J.x(iRow,iCol+1)));
        str=[str,';...'];
        %write in file
        fprintf(fid, '%s\n', str);
    else
        %write last element
        str=bracketSubs(char(J.x(iRow,iCol+1)));
        str=[str,'];'];
        %write in file
        fprintf(fid, '%s\n\n', str);   
    end
end


% INPUT MATRIX
% write "B=["
fprintf(fid, '%s', 'B=[');

%write each row
for iRow=1:(length(J.u(:,1)))
    if length(J.u(1,:))>1
        for iCol=1:(length(J.u(1,:))-1)
            str=bracketSubs(char(J.u(iRow,iCol)));
            str=[str,','];
            %write in file
            fprintf(fid, '%s', str);
        end
    else iCol=0;
    end
    
    if iRow<length(J.u(:,1))
        %write last element
        str=bracketSubs(char(J.u(iRow,iCol+1)));
        str=[str,';...'];
        %write in file
        fprintf(fid, '%s\n', str);    
    else
        %write last element
        str=bracketSubs(char(J.u(iRow,iCol+1)));
        str=[str,'];'];
        %write in file
        fprintf(fid, '%s', str);
    end
end

%close file
status = fclose(fid);

function [str]=bracketSubs(str)

%generate left and right brackets
str=strrep(str,'L','(');
str=strrep(str,'R',')');

% add "interval()" to string
str=['infsup(',str,',',str,')'];


%------------- END OF CODE --------------