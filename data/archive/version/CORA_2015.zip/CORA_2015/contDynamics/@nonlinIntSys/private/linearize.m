function [obj,linearIntSys,linOptions] = linearize(obj,options,R)
% linearize - linearizes the nonlinear system with uncertain parameters;
% linearization error is not included yet
%
% Syntax:  
%    [obj,linearIntSys,linOptions] = linearize(obj,options,R)
%
% Inputs:
%    obj - nonlinear interval system object
%    options - options struct
%    R - actual reachable set
%
% Outputs:
%    obj - nonlinear interval system object
%    linearIntSys - linear interval system object
%    linOptions - options for the linearized system
%
% Example: 
%    Text for example...
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: 

% Author:       Matthias Althoff
% Written:      18-January-2008 
% Last update:  30-June-2009
% Last revision: ---

%------------- BEGIN CODE --------------


%linearization point p.u of the input is the center of the input u
p.u=center(options.U) + options.uTrans;

%linearization point p.x of the state is the center of the last reachable 
%set R translated by f0*delta_t
t=0; %time invariant system
f0prev=obj.mFile(t,center(R),p.u,mid(options.paramInt));
p.x=center(R)+f0prev*0.5*options.timeStep;


%substitute p into the system equation in order to obtain the constant
%input
t=0; %time invariant system
f0=obj.mFile(t,infsup(p.x,p.x),infsup(p.u,p.u),options.paramInt);

%substitute p into the Jacobian with respect to x and u to obtain the
%system matrix A and the input matrix B
[A,Btmp]=jacobian(p.x,p.u,options.paramInt);

[Btmpinf,Btmpsup]=infsup(Btmp);
if all(Btmpinf==Btmpsup)
    B=Btmpinf;
else
    B=Btmp;
end


%split f0 into a real valued vector and a zonotope
f0mid=mid(f0);
f0=f0-f0mid;
[f0inf,f0sup]=infsup(f0);
f0Delta=zonotope(intervalhull([f0inf,f0sup]));

%set up otions for linearized system
linOptions=options;

Ucenter=center(options.U);
linOptions.uTrans=f0mid; %B*Ucenter from linOptions.U not added as the system is linearized around center(U)
linOptions.U=B*(options.U+(-Ucenter))+f0Delta;
linOptions.originContained=0;

%set up linearized system
linearIntSys = linIntSys07('linIntSys07',A,1,0); %B=1 as input matrix encountered in uncertain inputs

%save constant input
obj.linError.f0=f0;

%save linearization point
obj.linError.p=p;


%------------- END OF CODE --------------