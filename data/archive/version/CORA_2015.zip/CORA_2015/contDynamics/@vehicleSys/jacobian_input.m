function jacobian_input_fullVehicle(obj,options)
% jacobian_vehicle - computes the jacobian of the vehicle system in a symbolic
% way; the result is stored in a m-file and passed by a handle
%
% Syntax:  
%    [obj] = jacobian_vehicle(obj)
%
% Inputs:
%    obj - vehicle system object
%
% Outputs:
%    obj - vehicle system object
%
% Example: 
%    Text for example...
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: 

% Author:       Matthias Althoff
% Written:      02-September-2011 
% Last update:  ---
% Last revision:---

%------------- BEGIN CODE --------------

%create symbolic variables
[x,u,y]=symVariables_param(obj,'LRbrackets');

%include parameter as additional input
syms yL6R
y(6) = yL6R;

%insert symbolic variables into the system equations
t=0;
fLR=obj.mFile(t,x,u,y,options.p,yL6R);

%compute jacobian with respect to the input
Jy=jacobian(fLR,y);

%combine jacobians
obj.J.u=Jy;

%generate mFile that computes the lagrange remainder and the jacobian
createJacobianFile_input(obj);

%------------- END OF CODE --------------