function createJacobianFile_param(obj)
% createJacobianFile - generates an mFile that allows to compute the
% jacobian at a certain state and input
%
% Syntax:  
%    createJacobianFile(obj)
%
% Inputs:
%    obj - nonlinear parametric system object
%
% Outputs:
%
% Example: 
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: ---

% Author:       Matthias Althoff
% Written:      27-May-2011
% Last update:  ---
% Last revision: ---

%------------- BEGIN CODE --------------

    
%load first order jacobians
Jp = obj.J;

%set directory
%cd('/media/New Volume/software/2011/CORA/contDynamics/stateSpaceModels') %<-- change directory here
cd('/media/Transcend/DATA/software/2012/CORA/contDynamics/stateSpaceModels') %<-- change directory here

fid = fopen('jacobian_veh_param.m','w');
fprintf(fid, '%s\n\n', 'function [A,B]=jacobian_veh_param(x,u,y)');

% SYSTEM MATRICES
for iMatrix = 1:length(Jp.x)
    % write "A{i}=["
    fprintf(fid, '%s', 'A{', num2str(iMatrix),'}=[');
    % write rest of matrix
    writeMatrix(Jp.x{iMatrix},fid);
end


% INPUT MATRICES
for iMatrix = 1:length(Jp.u)
    % write "B{i}=["
    fprintf(fid, '%s', 'B{', num2str(iMatrix),'}=[');
    % write rest of matrix
    writeMatrix(Jp.u{iMatrix},fid);
end


%close file
fclose(fid);


function writeMatrix(M,fid)

%write each row
for iRow=1:(length(M(:,1)))
    for iCol=1:(length(M(1,:))-1)
        str=bracketSubs(char(M(iRow,iCol)));
        str=[str,','];
        %write in file
        fprintf(fid, '%s', str);
    end
    if iRow<length(M(:,1))
        %write last element
        str=bracketSubs(char(M(iRow,iCol+1)));
        str=[str,';...'];
        %write in file
        fprintf(fid, '%s\n', str);
    else
        %write last element
        str=bracketSubs(char(M(iRow,iCol+1)));
        str=[str,'];'];
        %write in file
        fprintf(fid, '%s\n\n', str);   
    end
end


function [str]=bracketSubs(str)

%generate left and right brackets
str=strrep(str,'L','(');
str=strrep(str,'R',')');

% % add "interval()" to string
% str=['infsup(',str,',',str,')'];


%------------- END OF CODE --------------