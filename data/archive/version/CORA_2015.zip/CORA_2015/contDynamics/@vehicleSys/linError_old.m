function [error] = linError_old(obj,options,IH,IH_y)
% linError - computes the linearization error
%
% Syntax:  
%    [obj] = linError(obj,options)
%
% Inputs:
%    obj - nonlinear system object
%    options - options struct
%    R - actual reachable set
%
% Outputs:
%    obj - nonlinear system object
%
% Example: 
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: 

% Author:       Matthias Althoff
% Written:      29-October-2007 
% Last update:  22-January-2008
%               02-February-2010
%               04-May-2011
% Last revision: ---

%------------- BEGIN CODE --------------


% %compute intervals of total reachable set
% totalInt=interval(IH);

%obtain model factors
c = modelFactors(options.uTrans);
c_abs = abs(c);

%helper values
min_x = IH(:,1);
max_x = IH(:,2);

max_y = IH_y(:,2); % y-bounds are symmetric! (no min values required)

%extreme absolue values 
%x_1
max_abs_x1 = max(abs(min_x(1)),abs(max_x(1)));
%x_2
max_abs_x2 = max(abs(min_x(2)),abs(max_x(2))); 
%x_3
max_abs_x3 = max(abs(min_x(3)),abs(max_x(3))); 
%x_4
min_abs_x4 = min_x(4); %velocity is always positive
max_abs_x4 = max_x(4); %velocity is always positive
%x_5
max_abs_x5 = max(abs(min_x(5)),abs(max_x(5)));
%x_6
max_abs_x6 = max(abs(min_x(6)),abs(max_x(6))); 
%aux
aux_1 = 6*c_abs(1)*max_abs_x3/min_abs_x4^4;
%aux_2_old = 2/min_abs_x4^3*(c(2)*totalInt(1) + c(3)*totalInt(5) + c(4)*totalInt(6) + c(5)*totalInt(2));
aux_2 = 2/min_abs_x4^3*(c_abs(2)*max_abs_x1 + c_abs(3)*(max_abs_x5+max_y(2)) ...
    + c_abs(4)*(max_abs_x6+max_y(3)) + c_abs(5)*(max_abs_x2+max_y(1)));
max_abs_aux = aux_1 + aux_2;

%cos and sin max
min_angle = min_x(1) + min_x(2);
max_angle = max_x(1) + max_x(2);

%ASSUME that angles are between -pi and pi!!
%cosinus ranges
if max_angle<0
    cos_min = cos(min_angle);
    cos_max = cos(max_angle);
elseif min_angle>0
    cos_min = cos(max_angle);
    cos_max = cos(min_angle);
else
    cos_min = min(cos(min_angle), cos(max_angle));
    cos_max = 1;
end

%sinus ranges
if max_angle<-pi/2
    sin_min = sin(max_angle);
    sin_max = sin(min_angle);
elseif min_angle>pi/2
    sin_min = sin(max_angle);
    sin_max = sin(min_angle);
elseif min_angle>-pi/2 && max_angle<pi/2
    sin_min = sin(min_angle);
    sin_max = sin(max_angle);
elseif min_angle<-pi/2 && max_angle<pi/2
    sin_min = -1;
    sin_max = max(sin(min_angle),sin(max_angle));
elseif min_angle>-pi/2 && max_angle>pi/2
    sin_min = min(sin(min_angle),sin(max_angle));
    sin_max = 1;
end

% cos_int = cos(totalInt(1) + totalInt(2));
% sin_int = sin(totalInt(1) + totalInt(2));

%translate intervals by linearization point
IH=IH+(-obj.linError.p.x);

%obtain maximum absolute values within IH, IHinput
IHinf=abs(inf(IH));
IHsup=abs(sup(IH));
dx=max(IHinf,IHsup);

IHinf_y=abs(inf(IH_y));
IHsup_y=abs(sup(IH_y));
dy=max(IHinf_y,IHsup_y);

%error candidates for dim 5,6:
err5_min = - max_abs_x4*cos_max*(dx(1)+dx(2))^2 - sin_max*(2*dx(4)*(dx(1)+dx(2)));
err5_max = - max_abs_x4*cos_min*(dx(1)+dx(2))^2 - sin_min*(2*dx(4)*(dx(1)+dx(2)));

err6_min = - max_abs_x4*sin_max*(dx(1)+dx(2))^2 + cos_min*(2*dx(4)*(dx(1)+dx(2)));
err6_max = - max_abs_x4*sin_min*(dx(1)+dx(2))^2 + cos_max*(2*dx(4)*(dx(1)+dx(2)));

%compute linearization error by hand-derived Lagrange remainders
%first coordinate
error(1,1) = 1/(min_abs_x4^2)*2*(c_abs(2)*dx(1)*dx(4)...
    + c_abs(5)*dx(2)*dx(4) + c_abs(3)*dx(4)*dx(5) + c_abs(4)*dx(4)*dx(6)...
    + c_abs(5)*dx(4)*dy(3) + c_abs(3)*dx(4)*dy(1) + c_abs(4)*dx(4)*dy(2) + c_abs(7)*dx(4)*dy(4))...
    + 1/(min_abs_x4^3)*4*c_abs(1)*dx(3)*dx(4)...
    + max_abs_aux*dx(4)^2;
error(2,1) = 0;
error(3,1) = 1/(min_abs_x4^2)*2*c_abs(6)*dx(3)*dx(4);
error(4,1) = 0;
error(5,1) = max(abs(err5_min),abs(err5_max));
error(6,1) = max(abs(err6_min),abs(err6_max));

%divide by 2 since the second order Taylor term has factor 1/2!
error = 0.5*error;

%------------- END OF CODE --------------