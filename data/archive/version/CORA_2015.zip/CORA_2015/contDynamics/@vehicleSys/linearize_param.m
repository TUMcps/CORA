function [obj,linSys,zf,Y] = linearize_param(obj,c,uTrans,yTrans,Y,paramInt,r,maxOrder)
% linearize - linearizes the vehicle system; linearization error is not
% included yet
%
% Syntax:  
%    [obj,linSys,linOptions] = linearize(obj,options)
%
% Inputs:
%    obj - vehicle system object
%    options - options struct
%
% Outputs:
%    obj - vehicle system object
%    linSys - linear system object
%    linOptions - options for the linearized system
%
% Example: 
%    Text for example...
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: 

% Author:       Matthias Althoff
% Written:      03-May-2011
% Last update:  04-May-2011
% Last revision:---

%------------- BEGIN CODE --------------


%linearization point p.x of the state is the center of the last reachable 
p.x=c; %+f0prev*0.5*options.timeStep;

%substitute p into the system equation in order to obtain the constant
%input
f0cell=parametricDynamicFile(p.x,uTrans,yTrans);

%normalize cells
pCenter = 0.5*(paramInt(:,2) + paramInt(:,1));
pDelta = 0.5*(paramInt(:,2) - paramInt(:,1));
for i=2:length(f0cell)
    f0cell{1} = f0cell{1} + pCenter*f0cell{i};
    f0cell{i} = pDelta(i-1)*f0cell{i};
end

%create constant input zonotope
f0Mat(length(f0cell{1}(:,1)),length(f0cell)) = 0; %init
for i=1:length(f0cell)
    f0Mat(:,i) = f0cell{i};
end
zf = zonotope(f0Mat);

%substitute p into the Jacobian with respect to x and u to obtain the
%system matrix A
[A,B] = jacobian_veh_param(p.x,uTrans,yTrans);

%create matrix zonotopes
zA = matZonotope(A{1},A(2:end));
zB = matZonotope(B{1},B(2:end));

%obtain uncertain input
Y=zB*(Y+(-yTrans));
Y = deleteZeros(Y);

%set up linearized system
linSys = linParamSys(zA,1,r,maxOrder); %B=1 as input matrix encountered in uncertain inputs

%save linearization point
obj.linError.p=p;


%------------- END OF CODE --------------