function jacobian_input_fullVehicle(obj,options)
% jacobian_vehicle - computes the jacobian of the vehicle system in a symbolic
% way; the result is stored in a m-file and passed by a handle
%
% Syntax:  
%    [obj] = jacobian_vehicle(obj)
%
% Inputs:
%    obj - vehicle system object
%
% Outputs:
%    obj - vehicle system object
%
% Example: 
%    Text for example...
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: 

% Author:       Matthias Althoff
% Written:      26-August-2011 
% Last update:  30-August-2011
% Last revision:---

%------------- BEGIN CODE --------------

%create symbolic variables
[x,u,y,p]=symVariables_param(obj,'LRbrackets');

%insert symbolic variables into the system equations
t=0;
fLR=obj.mFile(t,x,u,y,options.p,p);

%get projected file
fproj(1,1) = -atan(fLR(8,1)./fLR(7,1)); % slip angle
fproj(2,1) = -fLR(1,1); % yaw angle
fproj(3,1) = -fLR(2,1); % yaw rate
fproj(4,1) = fLR(7,1); % simplify absolute position as velocity in x-direction
fproj(5,1) = fLR(27,1); % x-position
fproj(6,1) = -fLR(28,1); % y-position

%compute jacobian with respect to the input
Jy=jacobian(fproj,y);
%compute jacobian with respect to the parameter
Jp=jacobian(fproj,p);

%combine jacobians
Ju=[Jy,Jp];

%generate mFile that computes the lagrange remainder and the jacobian
createJacobianFile_input(Ju);

%------------- END OF CODE --------------