function [error] = linError(obj,w,IH,IH_y)
% linError - computes the linearization error
%
% Syntax:  
%    [obj] = linError(obj,options)
%
% Inputs:
%    obj - nonlinear system object
%    options - options struct
%    R - actual reachable set
%
% Outputs:
%    obj - nonlinear system object
%
% Example: 
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: 

% Author:       Matthias Althoff
% Written:      29-October-2007 
% Last update:  22-January-2008
%               02-February-2010
%               04-May-2011
%               31-August-2011
% Last revision: ---

%------------- BEGIN CODE --------------


% %compute intervals of total reachable set
% totalInt=interval(IH);

%obtain model factors
c = modelFactors(w);
c_abs = abs(c);

%helper values
min_x = IH(:,1);
max_x = IH(:,2);

max_y = IH_y(:,2); % y-bounds are symmetric! (no min values required)

%extreme absolue values 
%x_1
max_abs_x1 = max(abs(min_x(1)),abs(max_x(1))); 
%x_3
max_abs_x3 = max(abs(min_x(3)),abs(max_x(3))); 
%x_4
min_abs_x4 = min_x(4); %velocity is always positive
max_abs_x4 = max_x(4); %velocity is always positive

%auxiliary variables
aux_min_1 = w(1) - IH(5,1) - IH_y(1,1);
aux_max_1 = w(1) - IH(5,2) - IH_y(1,2);
tilde_IM_1 = max(abs(aux_min_1),abs(aux_max_1));

aux_min_2 = w(2) - IH(6,1) - IH_y(2,1);
aux_max_2 = w(2) - IH(6,2) - IH_y(2,2);
tilde_IM_2 = max(abs(aux_min_2),abs(aux_max_2));

aux_min_3 = w(3) - IH(2,1) - IH_y(3,1);
aux_max_3 = w(3) - IH(2,2) - IH_y(3,2);
tilde_IM_3 = max(abs(aux_min_3),abs(aux_max_3));

aux_min_4 = w(4) - IH(3,1) - IH_y(4,1);
aux_max_4 = w(4) - IH(3,2) - IH_y(4,2);
tilde_IM_4 = max(abs(aux_min_4),abs(aux_max_4));


%cos and sin max
min_angle = min_x(1) + min_x(2);
max_angle = max_x(1) + max_x(2);

%ASSUME that angles are between -pi and pi!!
%cosinus ranges
if max_angle<0
    cos_min = cos(min_angle);
    cos_max = cos(max_angle);
elseif min_angle>0
    cos_min = cos(max_angle);
    cos_max = cos(min_angle);
else
    cos_min = min(cos(min_angle), cos(max_angle));
    cos_max = 1;
end

%sinus ranges
if max_angle<-pi/2
    sin_min = sin(max_angle);
    sin_max = sin(min_angle);
elseif min_angle>pi/2
    sin_min = sin(max_angle);
    sin_max = sin(min_angle);
elseif min_angle>-pi/2 && max_angle<pi/2
    sin_min = sin(min_angle);
    sin_max = sin(max_angle);
elseif min_angle<-pi/2 && max_angle<pi/2
    sin_min = -1;
    sin_max = max(sin(min_angle),sin(max_angle));
elseif min_angle>-pi/2 && max_angle>pi/2
    sin_min = min(sin(min_angle),sin(max_angle));
    sin_max = 1;
end

%auxiliary variables for sin and cos
Sm = max(abs(sin_min),abs(sin_max));
Cm = max(abs(cos_min),abs(cos_max));

%translate intervals by linearization point
IH=IH+(-obj.linError.p.x);

%obtain maximum absolute values within IH, IHinput
IHinf=abs(inf(IH));
IHsup=abs(sup(IH));
dx=max(IHinf,IHsup);

IHinf_y=abs(inf(IH_y));
IHsup_y=abs(sup(IH_y));
dy=max(IHinf_y,IHsup_y);


%compute linearization error by hand-derived Lagrange remainders
%first coordinate
error(1,1) = 2/(min_abs_x4^2)*(c_abs(2)*dx(1) + c_abs(5)*(dx(2) + dy(3)) ...
    + c_abs(3)*(dx(5) + dy(1)) + c_abs(4)*(dx(6) + dy(2)))*dx(4) ...
    + 2/(min_abs_x4^3)*(c_abs(2)*max_abs_x1 + c_abs(3)*tilde_IM_1 ...
    + c_abs(4)*tilde_IM_2 + c_abs(5)*tilde_IM_3 + c_abs(6)*tilde_IM_4)*dx(4)^2 ...
    + 4/(min_abs_x4^3)*c_abs(1)*dx(3)*dx(4) ...
    + 6/(min_abs_x4^4)*c_abs(1)*max_abs_x3*dx(4)^2;

error(2,1) = 0;

error(3,1) = 2/(min_abs_x4^2)*c_abs(7)*dx(3)*dx(4) ...
    + 2/(min_abs_x4^3)*c_abs(7)*max_abs_x3*dx(4)^2;

error(4,1) = 0;

error(5,1) = max_abs_x4*Cm*(dx(1) + dx(2))^2 + 2*Sm*(dx(1) + dx(2))*dx(4);
error(6,1) = max_abs_x4*Sm*(dx(1) + dx(2))^2 + 2*Cm*(dx(1) + dx(2))*dx(4);

%divide by 2 since the second order Taylor term has factor 1/2!
error = 0.5*error;

%------------- END OF CODE --------------