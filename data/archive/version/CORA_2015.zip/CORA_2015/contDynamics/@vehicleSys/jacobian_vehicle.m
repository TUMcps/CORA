function [obj] = jacobian_vehicle(obj,options)
% jacobian_vehicle - computes the jacobian of the vehicle system in a symbolic
% way; the result is stored in a m-file and passed by a handle
%
% Syntax:  
%    [obj] = jacobian_vehicle(obj)
%
% Inputs:
%    obj - vehicle system object
%
% Outputs:
%    obj - vehicle system object
%
% Example: 
%    Text for example...
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: 

% Author:       Matthias Althoff
% Written:      03-May-2011 
% Last update:  30-August-2011
% Last revision:---

%------------- BEGIN CODE --------------

%create symbolic variables[A,B] = jacobian_vehicle(p.x,uTrans,yTrans);
[x,u,y]=symVariables(obj,'LRbrackets');

%insert symbolic variables into the system equations
t=0;
fLR=obj.mFile(t,x,u,y,options.p);

%compute jacobian with respect to the state
obj.J.x=jacobian(fLR,x);
%compute jacobian with respect to the input
obj.J.y=jacobian(fLR,y);

%generate mFile that computes the lagrange remainder and the jacobian
createJacobianFile(obj);

%------------- END OF CODE --------------