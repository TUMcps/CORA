function Obj = zeroDynSys(varargin)
% zeroDynSys - Object and Copy Constructor 
%
% Syntax:  
%    object constructor: Obj = class_name(varargin)
%    copy constructor: Obj = otherObj
%
% Inputs:
%    input1 - name
%    input2 - dim
%
% Outputs:
%    Obj - Generated Object
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: OTHER_CLASS_NAME1,  OTHER_CLASS_NAME2

% Author: Matthias Althoff
% Written: 02-November-2007 
% Last update: 20-March-2008
% Last revision: ---

%------------- BEGIN CODE --------------

% If no argument is passed
if nargin == 0
    disp('This class needs more input values');
    Obj=[];
    
% If 2 arguments are passed
elseif nargin == 2
    %List elements of the class
    Obj.dim=varargin{2};
    
    %Generate parent object
    cDyn=contDynamics(varargin{1},ones(varargin{2},1),1,1);

    % Register the variable as an child object of contSet
    Obj = class(Obj, 'zeroDynSys', cDyn);    
        
% Else if the parameter is an identical object, copy object    
elseif isa(varargin{1}, 'zeroDynSys')
    Obj = varargin{1};
    
% Else if not enough or too many inputs are passed    
else
    disp('This class needs more/less input values');
    Obj=[];
end

%------------- END OF CODE --------------