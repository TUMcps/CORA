function [error, errorInt] = linError_thirdOrder_old(obj, options, R)
% linError - computes the linearization error
%
% Syntax:  
%    [obj] = linError(obj,options)
%
% Inputs:
%    obj - nonlinear DAE system object
%    options - options struct
%    R - actual reachable set
%
% Outputs:
%    error - zonotope overapproximating the linearization error
%    errorInt - interval overapproximating the linearization error
%
% Example: 
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: 

% Author:       Matthias Althoff
% Written:      21-August-2012
% Last update:  ---
% Last revision:---

%------------- BEGIN CODE --------------

%compute intervalhull of reachable set
IH_x = intervalhull(R);
totalInt_x = interval(IH_x) + obj.linError.p.x;

%compute intervals of input
IH_u = intervalhull(options.U);
totalInt_u = interval(IH_u) + obj.linError.p.u;

%compute zonotope of state and input
Rred = reduce(R,'girard',options.errorOrder);
Z=cartesianProduct(Rred,options.U);

%obtain intervals and combined interval z
dx = interval(IH_x);
du = interval(IH_u);
dz = [dx; du];

%obtain absolute values
dz_abs = max(abs(inf(dz)), abs(sup(dz)));

%obtain hessian tensor and third order tensor
H = hessianTensor(obj.linError.p.x, obj.linError.p.u);

% if ~isempty(options.preT)
%     %find index
%     index = round(obj.linError.p.x(end)/options.preT{1}.stepSize_1);
%     
%     %check correctness
%     %if (IH_x + obj.linError.p.x) <= options.preT{index}.IH
%         T = options.preT{index}.T;
%     %end
% else
% tic
%     T = thirdOrderTensor_reduced2(totalInt_x, totalInt_u);
%     toc
tic
    T = thirdOrderTensor_reduced(totalInt_x, totalInt_u);
    toc
%     tic
%     T = thirdOrderTensor(totalInt_x, totalInt_u);
%     toc
%end


%second order error
error_secondOrder = 0.5*quadraticMultiplication(Z, H);

%interval evaluation
for i=1:length(T(:,1))
    error_sum = infsup(0,0);
    for j=1:length(T(1,:))
        error_tmp(i,j) = dz'*T{i,j}*dz;
        error_sum = error_sum + error_tmp(i,j) * dz(j);
    end
    error_thirdOrder_old(i,1) = 1/6*error_sum;
end

error_thirdOrder_old_zono = zonotope(intervalhull([inf(error_thirdOrder_old),sup(error_thirdOrder_old)]));

% %alternative
% %separate evaluation
% for i=1:length(T(:,1))
%     for j=1:length(T(1,:))
%         T_mid{i,j} = sparse(mid(T{i,j}));
%         T_rad{i,j} = sparse(rad(T{i,j}));
%     end
% end
% 
% Zred = reduce(zonotope(Z),'girard',options.errorOrder);
% error_mid = 1/6*cubicMultiplication_simple(Zred, T_mid);
% 
% %interval evaluation
% for i=1:length(T(:,1))
%     error_sum2 = 0;
%     for j=1:length(T(1,:))
%         error_tmp2(i,j) = dz_abs'*T_rad{i,j}*dz_abs;
%         error_sum2 = error_sum2 + error_tmp2(i,j) * dz_abs(j);
%     end
%     error_rad(i,1) = 1/6*error_sum2;
% end
% 
% 
% %combine results
% error_rad_zono = zonotope(intervalhull([-error_rad, error_rad]));
% error_thirdOrder = error_mid + error_rad_zono;
% 
% error_thirdOrder = reduce(error_thirdOrder,'girard',options.zonotopeOrder);

error_thirdOrder = reduce(error_thirdOrder_old_zono,'girard',options.zonotopeOrder);

%combine results
error = error_secondOrder + error_thirdOrder;

error = reduce(error,'girard',options.zonotopeOrder);

errorIHabs = abs(intervalhull(error));
errorInt = errorIHabs(:,2);

%------------- END OF CODE --------------