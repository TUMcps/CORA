function [Rti,Rtp,perfInd,nr,options] = linReach(obj,options,Rinit,iter)
% linReach - computes the reachable set after linearazation and returns if
% the initial set has to be split in order to control the linearization
% error
%
% Syntax:  
%    [Rti,Rtp,split,options] = linReach(obj,options,Rinit)
%
% Inputs:
%    obj - nonlinear system object
%    options - options struct
%    Rinit - initial reachable set
%
% Outputs:
%    Rti - reachable set for time interval
%    Rti - reachable set for time point
%    split - boolean value returning if initial set has to be split
%    options - options struct to return f0
%
% Example: 
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: 

% Author:       Matthias Althoff
% Written:      17-January-2008
% Last update:  29-June-2009
%               23-July-2009
%               10-July-2012
%               18-September-2012
% Last revision: ---

%------------- BEGIN CODE --------------


% linearize nonlinear system
[obj,linSys,options,linOptions] = linearize(obj,options,Rinit); 

%translate Rinit by linearization point
Rdelta=Rinit+(-obj.linError.p.x);

% compute reachable set of linearized system
%ti: time interval, tp: time point
linOptions.p = obj.linError.p.x;
[linSys,R] = initReach(linSys,Rdelta,linOptions);
[linSys,Rdiff] = deltaReach(linSys,Rdelta,linOptions);

% %correctness check
% plot(R.ti,[1 2],'b');
% plot(Rdelta + zonotope(Rdiff), [1 2],'r');
% plot(zonotope(Rdiff), [1 2],'g');


Rtp=R.tp;
Rti=R.ti;
% disp('---------------------------');
% intervalhull(Rti)

perfIndCurr=inf;
perfInd=0;
while (perfIndCurr>1) && (perfInd<=1) 
    
    %new technique: compute reachable set due to assumed linearization error
    %Verror = zonotope([0*obj.expFactor,diag(obj.expFactor)]);
    appliedError = 1.1*options.oldError;
    %appliedError = options.maxError;
    Verror = zonotope([0*appliedError,diag(appliedError)]);
    [RallError] = errorSolution(linSys,Verror,options); 

    % obtain linearization error
    if options.advancedLinErrorComp
        %[Verror,error] = linError_quadratic(obj,options,Rmax);
        if options.tensorOrder<=2
            %compute maximum reachable set due to maximal allowed linearization error
            %Rmax=Rti+RallError;
            try
                Rmax=Rtp+zonotope(Rdiff)+RallError;
            catch
                Rmax=Rtp+Rdiff+RallError; 
            end
            
            [VerrorDyn,error] = linError_mixed_noInt(obj,options,Rmax); 
            VerrorStat = [];
        else
            %compute maximum reachable set due to maximal allowed linearization error
            try
                Rmax=Rtp+zonotope(Rdiff)+RallError;
            catch
                Rmax=Rtp+Rdiff+RallError; 
            end
            
            [VerrorStat,VerrorDyn,error] = linError_thirdOrder(obj,options,Rmax,Rdiff);
        end
    else
        %compute maximum reachable set due to maximal allowed linearization error
        Rmax=Rti+RallError;         
        
        [error] = linError(obj,options,Rmax);
        VerrorDyn=zonotope([0*error,diag(error)]);
        VerrorStat = [];
    end

    %store old error
    options.oldError = error;

    %compute performance index of linearization error
    perfIndCurr = max(error./appliedError);
    
    if perfIndCurr > 1
        disp('investigate');
    end
    
    perfInd = max(error./options.maxError)
end
% compute reachable set due to the linearization error
if ~isempty(VerrorStat)
    [Rerror] = errorSolutionQuad(linSys,VerrorStat,VerrorDyn,options); %<-- this has to change!
else
    [Rerror] = errorSolution(linSys,Verror,options); %<-- this has to change!
end

%translate reachable sets by linearization point
Rti=Rti+obj.linError.p.x;
Rtp=Rtp+obj.linError.p.x;



% try
% if (options.t>3 && options.t<3.1) || (options.t>6.6 && options.t<6.7)
%     perfInd
%     options.t
% end
% catch
% end

if (perfInd>1) && (iter==1)
    %find best split
    dim = length(obj.linError.p.x);
    options.oldError = zeros(dim,1); % for comparison reasons
    nr=select(obj,options,Rinit,options.maxError);
%     nr=[];
%     options.tFinal=0;
else
    nr=[];
end

%add intervalhull of actual error
if strcmp('quadZonotope',class(Rerror))
    Rti=exactPlus(Rti,Rerror);
    Rtp=exactPlus(Rtp,Rerror);
else
    Rti=Rti+Rerror;
    Rtp=Rtp+Rerror;
end

%intervalhull(Rti+(-obj.linError.p.x))

%------------- END OF CODE --------------