function [error,errorInt] = linError_mixed_noInt(obj,options,R)
% linError_mixed_noInt - computes the linearization error without use of
% interval arithmatic
%
% Syntax:  
%    [error,errorInt] = linError_mixed_noInt(obj,options,R)
%
% Inputs:
%    obj - nonlinear system object
%    options - options struct
%    R - actual reachable set
%
% Outputs:
%    error - error represented by a zonotope
%    errorInt - multidimensional interval of error
%
% Example: 
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: 

% Author:       Matthias Althoff
% Written:      11-July-2012
% Last update:  ---
% Last revision:---

%------------- BEGIN CODE --------------


%compute intervalhull of reachable set
IH_x = intervalhull(R);
totalInt_x = interval(IH_x) + obj.linError.p.x;

%compute intervals of input
IH_u = intervalhull(options.U);
totalInt_u = interval(IH_u) + obj.linError.p.u;

%compute zonotope of state and input
Rred = reduce(R,options.reductionTechnique,options.errorOrder);
Z=cartesianProduct(Rred,options.U);

%obtain hessian tensor
H = hessianTensor(totalInt_x, totalInt_u);

%obtain intervals and combined interval z
dx = interval(IH_x);
du = interval(IH_u);
dz = [dx; du];

%obtain absolute values
dz_abs = max(abs(inf(dz)), abs(sup(dz)));

%separate evaluation
for i=1:length(H)
    H_mid{i} = sparse(mid(H{i}));
    H_rad{i} = sparse(rad(H{i}));
end

error_mid = 0.5*quadraticMultiplication(Z, H_mid);

%interval evaluation
for i=1:length(H)
    error_rad(i,1) = 0.5*dz_abs'*H_rad{i}*dz_abs;
end

%combine results
error_rad_zono = zonotope(intervalhull([-error_rad, error_rad]));
error = error_mid + error_rad_zono;

if isa(error, 'zonotope')
    error = reduce(error,options.reductionTechnique,options.zonotopeOrder);
else
    error = reduce(error,options.reductionTechnique,options.intermediateOrder);
end

errorIHabs = abs(intervalhull(error));
errorInt = errorIHabs(:,2);

% H2 = hessianTensor(mid(totalInt),mid(inputInt));
% error2=0.5*quadraticMultiplication(Z,H2);

function [Z1,Z2]=splitOneDim(c,G,dim)

%compute centers of splitted parallelpiped
c1=c-G(:,dim)/2;
c2=c+G(:,dim)/2;

%compute new set of generators
Gnew=G;
Gnew(:,dim)=Gnew(:,dim)/2;

%generate splitted parallelpipeds
Z1=zonotope([c1,Gnew]);
Z2=zonotope([c2,Gnew]);   

%------------- END OF CODE --------------