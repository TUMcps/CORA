function [nr] = select(obj,options,Rinit,allErr);
% select - selects the split strategy of the reachable set causing the
% least linearization error
%
% Syntax:  
%    [nr] = select(IHerrorActual,IHerrorAssume)
%
% Inputs:
%    IHerrorActual - cell array of actual linearizatuion errors
%    IHerrorAssume - assumed linearization error 
%
% Outputs:
%    nr - number of the selected split strategy
%
% Example: 
%    Text for example...
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: 

% Author:       Matthias Althoff
% Written:      04-January-2008 
% Last update:  29-January-2008
%               29-June-2009
% Last revision: ---

%------------- BEGIN CODE --------------

% retrieve dim
dim=length(obj.linError.f0);

% compute all possible splits of the maximum reachable set
Rxx=split(Rinit,options);

if ~isempty(Rxx)

    % check performance index for all split sets
    for i=1:length(Rxx)
        % select reachable sets
        Rtest=Rxx{i}{1};

        % obtain perf index
        [Rti,Rtp,perfInd(i)] = linReach(obj,options,Rtest,0);
    end

    % find best performance index
    [val,ind]=sort(perfInd);
    nr=ind(1);
    
else
    %set to be split is empty
    nr = 0;
end



%------------- END OF CODE --------------