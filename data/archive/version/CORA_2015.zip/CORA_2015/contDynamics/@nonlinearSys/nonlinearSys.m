function Obj = nonlinearSys(varargin)
% nonlinSys - Object and Copy Constructor (linSys: linear system)
%
% Syntax:  
%    object constructor: Obj = class_name(varargin)
%    copy constructor: Obj = otherObj
%
% Inputs:
%    input1 - name
%    input2 - dimension
%    input3 - number of inputs
%    input4 - mfile of the state space equations
%    input5 - value of maximum derivation within the invariant
%
% Outputs:
%    Obj - Generated Object
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: 

% Author: Matthias Althoff
% Written: 17-October-2007 
% Last update: 29-October-2007
% Last revision: ---

%------------- BEGIN CODE --------------

% If no argument is passed
if nargin == 0
    disp('This class needs more input values');
    Obj=[];
    
% If 4 arguments are passed
elseif nargin == 4
    %List elements of the class
    Obj.dim=varargin{2};
    Obj.nrOfInputs=varargin{3};
    Obj.mFile=varargin{4};
    Obj.jacobians=[];

    %Generate parent object
    cDyn=contDynamics(varargin{1},ones(varargin{2},1),1,1);

    % Register the variable as an child object of contDyn
    Obj = class(Obj, 'nonlinearSys', cDyn);      
    
    %symbolic computation of the jacobians of the nonlinear system 
    Obj = jacobians(Obj);
    
% If 5 arguments are passed
elseif nargin == 5
    %List elements of the class
    Obj.dim=varargin{2};
    Obj.nrOfInputs=varargin{3};
    Obj.mFile=varargin{4};
    Obj.jacobians=[];
    Obj.linError=[];
    
    options = varargin{5};

    %Generate parent object
    cDyn=contDynamics(varargin{1},ones(varargin{2},1),1,1);

    % Register the variable as an child object of contSet
    Obj = class(Obj, 'nonlinearSys', cDyn);    
    
    %symbolic computation of the jacobians of the nonlinear system 
    Obj = jacobians(Obj,options);
        
% Else if the parameter is an identical object, copy object    
elseif isa(varargin{1}, 'nonlinearSys')
    Obj = varargin{1};
    
% Else if not enough or too many inputs are passed    
else
    disp('This class needs more/less input values');
    Obj=[];
end

%------------- END OF CODE --------------