classdef linVarSys
% linVarSys class 
%
% Syntax:  
%    object constructor: Obj = linVarSys(varargin)
%    copy constructor: Obj = otherObj
%
% Inputs:
%    input1 - zonotope matrix
%
% Outputs:
%    Obj - Generated Object
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: ---

% Author:       Matthias Althoff
% Written:      05-August-2010
% Last update:  ---
% Last revision:---

%------------- BEGIN CODE --------------

properties (SetAccess = private, GetAccess = public)
    A = 1;
    B = 0;
    %stepSize = 0.01/max(abs(eig(A.center)));
    stepSize = 1;
    taylorTerms = 6;
    dim = 1;
    mappingMatrixSet = [];
    power = [];
    E = [];
    F = [];
    inputF = [];
    inputCorr = [];
    Rinput = [];
    Rtrans = [];
    sampleMatrix = [];
end
    
methods
    %class constructor
    function obj = linVarSys(A,B,stepSize,taylorTerms)

        %one input
        if nargin==1
            obj.dim = A.dim;
            obj.A = A;
        %two inputs
        elseif nargin==2
            obj.dim = A.dim;
            obj.A = A;
            obj.B = B;
        %three inputs
        elseif nargin==3
            obj.dim = A.dim;
            obj.A = A;
            obj.B = B;
            obj.stepSize = stepSize;
        %four inputs
        elseif nargin==4
            obj.dim = A.dim;
            obj.A = A;
            obj.B = B;
            obj.stepSize = stepSize;
            obj.taylorTerms = taylorTerms;
        end 
    end
         
    %methods in seperate files 
    [obj,Rfirst,options] = initReach(obj, Rinit, options)
    [Rnext,options] = reach(obj,R,options)
    [obj,t,x,index] = simulate(obj,opt,tstart,tfinal,x0,options)
    handle = getfcn(obj,options)
    
    %display functions
    plot(varargin)
    display(obj)
end
end

%------------- END OF CODE --------------