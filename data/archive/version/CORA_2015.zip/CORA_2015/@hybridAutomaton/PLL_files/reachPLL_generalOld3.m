function [R] = reachPLL_general(obj, options)
% reachPLL_general - computes the reachable set of the PLL 
%
% Syntax:  
%    [R] = reachPLL_lock(obj, options)
%
% Inputs:
%    options - options for reachability analysis of the system
%
% Outputs:
%    R - reachable set
%
% Example: 
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: none

% Author:       Matthias Althoff
% Written:      14-December-2010
% Last update:  22-December-2010
%               12-January-2010
% Last revision:---

%------------- BEGIN CODE --------------

A = options.sys.A{1};
c = options.sys.c{1};
U = options.U{1};
inv = options.Rinv;
R{1} = options.R0; 

dim = length(A);


%compute phase and voltage velocity boundaries
%set viInt and vpInt
viInt = infsup(-0.5,0.5);
vpInt = infsup(-0.5,0.5);
vSat = 0.35; %<-- change vSat here!
[vMinPhase,vMaxPhase]=phaseVelBound(A, c, viInt, vpInt);
[vMinVoltage,vMaxVoltage] = voltageVelBound(A,vpInt,U);

%compute cycle time
t_cycle = 1/27;
max_stepSize = 0.001;
proj = [1 0 0 0; 0 1 0 0];

%compute interval hull
IH = intervalhull(R{1});


% %init
% Vall = cell(1,length(options.Pinv));
% for iSet = 1:length(options.Pinv);
%     Vall{iSet} = [];
% end

iCycle=1;

while ~isempty(IH) && ~(IH<=options.Rgoal{1}) && ~(IH<=options.Rgoal{2})

    %PHASE 1---------------------------------------------------------------
    %compute time limits when charge pump is on
    [t_min,t_max] = timeBound_phase(R{iCycle},vMinPhase,vMaxPhase);
    t_on_voltage = timeBound_voltage_conservative(R{iCycle},vMaxVoltage,vSat);
    
    %determine delta T
    deltaT = t_max - t_min;
    
    %compute phase velocity interval
    vInt = infsup(vMinPhase,vMaxPhase);
    
    %if saturation is possible, compute with sub-intervals in time
    satInd = find(t_on_voltage < t_max);
    if ~isempty(satInd)
        %obtain time step sizes
        steps = ceil(t_min/max_stepSize);
        %obtain step sizes
        timeStep = t_min/steps;
        
        %voltage range
        vRange_1 = intervalhull(proj*R{1});

        %eAt, eAtInt
        eAtInt = inputExponential(A,timeStep,options);
        eAt = expm(A*timeStep);
        
        %initial computations
        Rinput_est = eAt*R{1} + eAtInt * U;
        %obtain new voltage range
        vRange_2 = intervalhull(proj*(Rinput_est));
        %combine voltage ranges
        vRange = vRange_1 | vRange_2;
        %make the new the old range 
        vRange_1 = vRange_2;
        %obtain input range
        Unew = inputRange(vRange,vSat,sup(viInt),U);
        
        %compute intermediate reachable set
        Rinter{1} = eAt*R{1} + eAtInt * Unew;
                
        %loop for reachable set until t_min
        for iStep = 1:(steps-1)
            %obtain set without saturation
            Rinput_est = eAt*Rinter{iStep} + eAtInt * U;
            %obtain new voltage range
            vRange_2 = intervalhull(proj*(Rinput_est));
            %combine voltage ranges
            vRange = vRange_1 | vRange_2;
            %make the new the old range 
            vRange_1 = vRange_2;
            %obtain input range
            Unew = inputRange(vRange,vSat,sup(viInt),U);
            
            %compute intermediate reachable set
            Rinter{iStep+1} = eAt*Rinter{iStep} + eAtInt * Unew;
            %intersect with invariant
            Rinter{iStep+1} = Rinter{iStep+1} & zonotope(inv);
            Rinter{iStep+1} = shrinkIH(Rinter{iStep+1});
        end
        Rinput = Rinter{end};
    else
        %compute input solution for t=[0,t_min] 
        eAtInt = inputExponential(A,t_min,options);
        Rinput = expm(A*(t_cycle-t_min)) * eAtInt * U;
    end
    
    %missing: input range for this procedure...
    
    %compute input matrix for t=[t_min, t_max] 
    matZinput = inputMatrix(A, deltaT, t_cycle-t_min, U, vInt, options);
    
    %complete solution
    R_new = (expm(A*t_cycle)+matZinput)*R{iCycle} + Rinput; %<-- has to be refined!!!
    
    
    %intersect with invariant
    R_new = R_new & zonotope(inv);
    %IH_intersect = intervalhull(R_intersect);
    
    if ~isempty(R_new)
        IH=intervalhull(R_new);
        R{iCycle+1} = reduce(R_new,'girard',60);
    else
        %initialize empty intervalhull
        IH = intervalhull();
    end
    
%     %if mod(iCycle,400)==0
%     if mod(iCycle,100)==0
%         
%         %simplify
%         R{iCycle+1} = simplifySet(R{iCycle+1}, linMap, A, 1);
%     end
    
    
%     if mod(iCycle,200)==0
%         dims=[1 2; 2 3; 1 4];
%         for iPlot=1:3
%             figure;
%             plot(R{iCycle+1},dims(iPlot,:));
%         end
%     end
    
    
    if mod(iCycle,100)==0
        disp('next 100 cycles')
        IH
    end

    iCycle = iCycle+1;
end



%compute phase velocity boundaries
function [vMin,vMax]=phaseVelBound(A,c,vpInt,viInt)

vInt = A(4,:)*[viInt; 0; vpInt; 0] + c(4) + 27;

vMin = inf(vInt);
vMax = sup(vInt);


%compute phase velocity boundaries
function [vMin,vMax]=voltageVelBound(A,vpInt,Ucertain)

%projection matric
P = [1 0 0 0; 0 1 0 0];

absVal = max(abs(inf(vpInt)),abs(sup(vpInt)));

%velocity for v_p1 not considering inputs
vInt_tmp = A(2,:)*[0; -absVal; +absVal; 0];

%velocity for v_i and v_p1 
vIH = intervalhull(P*Ucertain) + intervalhull([0,0; -vInt_tmp, vInt_tmp]);

vMin = vIH(:,1);
vMax = vIH(:,2);


%compute time intervals for charge pump on and off
function [t_min,t_max]=timeBound_phase(R,vMin,vMax)

%obtain range of Phi_v
Phi_IH = intervalhull([0 0 0 1]*R);
PhiMin = min(abs(Phi_IH(:,1)),abs(Phi_IH(:,2)));
PhiMax = max(abs(Phi_IH(:,1)),abs(Phi_IH(:,2)));

%t_on
if Phi_IH(:,1)*Phi_IH(:,2)>0
    t_min = PhiMin/vMax;
else
    t_min = 0;
end
t_max = PhiMax/vMin;


%compute time intervals for charge pump on and off
function [t_on]=timeBound_voltage_conservative(R,vMax,vSat)

%obtain range of v_i and v_p1
v_i_IH = intervalhull([1 0 0 0]*R);
v_p1_IH = intervalhull([0 1 0 0]*R);

v_i_max = v_i_IH(:,2);
v_p1_max = v_p1_IH(:,2);

%t_on
t_i_max = max((0.99*vSat-v_i_max)/vMax(1),0);
t_p1_max = max((vSat-v_p1_max)/vMax(2));
t_on = [t_i_max, t_p1_max];

function factor = inputRange_old(pllSys, tMax, IH, ind, relInd, options)

%generate corner cases for integral part
V = get(vertices(IH),'V');

for i=1:length(V(1,:))
    %generate initial set
    x0 = zeros(5,1);
    x0(4:5) = [-1 0];
    x0(ind) = V(:,i);
    
    %simulate system
    options.u = options.uLoc{2};
    [obj,t,x] = simulate(pllSys,options,0,tMax,x0,[]);
    
    %find input ranges
    x_min(i) = min(x(:,relInd));
    x_max(i) = max(x(:,relInd));
    
end

xMin = min(x_min);
xMax = max(x_max);

if xMax>0.35
    factor(1) = (1-(xMax-0.35)/(0.51-0.35));
else
    factor(1) = 1;
end

if xMin>0.35
    factor(2) = (1-(xMin-0.35)/(0.51-0.35));
else
    factor(2) = 1;
end




function eAtInt = inputExponential(A,r,options)

%compute Apowers
Apower = powers(A,options);
E = remainder(A,r,options);

dim = length(Apower{1});
Asum = r*eye(dim);
%compute higher order terms
for i=1:options.taylorTerms
    %compute factor
    factor = r^(i+1)/factorial(i+1);    
    %compute sums
    Asum = Asum + Apower{i}*factor;
end

%compute exponential due to constant input
eAtInt = Asum + E*r;


function Apower = powers(A,options)

%initialize 
Apower = cell(1,options.taylorTerms+1);
Apower{1} = A;  
    
%compute powers for each term and sum of these
for i=1:options.taylorTerms
    %compute powers
    Apower{i+1}=Apower{i}*A;
end   


function E = remainder(A,r,options)

%compute absolute value bound
M = abs(A*r);
dim = length(M);

%compute exponential matrix
eM = expm(M);

%compute first Taylor terms
Mpow = eye(dim);
eMpartial = eye(dim);
for i=1:options.taylorTerms
    Mpow = M*Mpow;
    eMpartial = eMpartial + Mpow/factorial(i);
end

W = eM-eMpartial;

%instantiate remainder
E = intervalMatrix(zeros(dim),W);


function R = simplifySet(R, linMap, A, exactnessFlag)

%do classical reduction
R = reduce(R,'girard',2);

%update options.W
W{1} = eye(length(A));
W{2} = linMap;
% Aenh(2:4,1:4) = A(2:4,1:4);
% Aenh(1,1) = 1;
% Aenh(4,4) = 0.01;
%W{3} = Aenh;
%W{4} = [1 0 0 -1; 0 1 -1 0; 0 1 0 -1; 1 -1 0 0];

%shrink
R = shrink3(R,W,exactnessFlag);

function [E] = expMatRemainder(A, t, options)

%compute auxiliary matrix
tmpMat = 1/factorial(4)*(t^4)*A^4;

%compute E_1 center, generators
E_center = 0.5*tmpMat;
E_gen{1} = 0.5*tmpMat;

for i=5:options.taylorTerms
    tmpMat = 0.5*(t^i)*A^i;
    
    %compute E center, generators
    E_center = E_center + 1/factorial(i)*tmpMat;
    E_gen{end+1} = 1/factorial(i)*tmpMat;
end

%instantiate matrix zonotopes
E_zono = matZonotope(E_center, E_gen);

%compute remainders
Erem = exponentialRemainder(intervalMatrix(0.5*A*t,0.5*A*t),options.taylorTerms);

%final result
E = intervalMatrix(E_zono) + Erem;


function matZinput = inputMatrix(A, Tmax, tFinal, U, vInt, options)

%initialize
dim = length(A);

t_intMat = intervalMatrix(0.5*Tmax,0.5*Tmax); %other time delay: 50e-3
gen_tmp{1} = 0.5*Tmax;
t_zonoMat = matZonotope(0.5*Tmax,gen_tmp); %other time delay: 50e-3

T(1) = infsup(1/2*Tmax,Tmax); %other time delay: 50e-3
T(2) = infsup(1/6*Tmax^2,1/2*Tmax^2); %other time delay: 50e-3
T(3) = infsup(1/8*Tmax^3,1/6*Tmax^3); %other time delay: 50e-3

T_2(1) = infsup(1/2,1); %other time delay: 50e-3
T_2(2) = infsup(1/6,1/2); %other time delay: 50e-3
T_2(3) = infsup(1/8,1/6); %other time delay: 50e-3

%convert to matrix zonotopes
for i=1:length(T)
    gen{1} = rad(T(i));
    t_zonMat{i} = matZonotope(mid(T(i)),gen);
    gen_2{1} = rad(T_2(i));
    t_zonMat_2{i} = matZonotope(mid(T_2(i)),gen_2);  
end

%compute matrix zonotopes
E = expMatRemainder(A, Tmax, options);

%compute factor
factor = (1/vInt);
matFactor_int = intervalMatrix(mid(factor),rad(factor));
matFactor_zono = matZonotope(matFactor_int);

%zonotope part of input matrix
inputMat_zono = matFactor_zono*(eye(dim) + t_zonMat{1}*A...
                + t_zonMat{2}*A^2 + t_zonMat{3}*A^3);        
inputMat_int = matFactor_int*E*(eye(dim) + 1/factorial(2)*t_intMat*A ...
                + 1/factorial(3)*t_intMat^2*A^2 + 1/factorial(4)*t_intMat^3*A^3 + E);
%----------------------------------------------------------------------

%INPUT-----------------------------------------------------------------


%compute fourth column
U = intervalhull(U);
U_inf = U(:,1);
U_sup = U(:,2);
U_intMat = intervalMatrix(0.5*(U_inf+U_sup), 0.5*(U_sup-U_inf));
fourthCol = (-1)*(intervalMatrix(inputMat_zono) + inputMat_int)*U_intMat;
fourthCol = expm(A*(tFinal-Tmax))*fourthCol; %correction
fourthCol_center = mid(fourthCol.int);
fourthCol_gen = rad(fourthCol.int);

Acenter = zeros(dim);
Adelta = zeros(dim);
Acenter(:,4) = fourthCol_center;
Adelta(:,4) = fourthCol_gen;
matZinput = intervalMatrix(Acenter,Adelta);


function U = inputRange(vRange,vSat,vMax,U)

%convert input
U_ih = intervalhull(U);

UnewMat = zeros(4,2);

%extract data
%voltages
vInt_min = vRange(1,1);
vInt_max = vRange(1,2);
vProp_min = vRange(2,1);
vProp_max = vRange(2,2);

%inputs
uInt_min = U_ih(1,1);
uInt_max = U_ih(1,2);
uProp_min = U_ih(2,1);
uProp_max = U_ih(2,2);

%integral path
if vInt_max > vSat
    uInt_min = (1-(vInt_max-vSat)/(vMax-vSat));
    uInt_min = max(uInt_min, 0);   
end
if vInt_min > vSat
    uInt_max = (1-(vInt_min-vSat)/(vMax-vSat));
    uInt_max = max(uInt_max, 0);   
end
UnewMat(1,:) = [uInt_min, uInt_max];

%proportional path
if vProp_max > vSat
    uProp_min = (1-(vProp_max-vSat)/(vMax-vSat))*uProp_min;
    uProp_min = max(uProp_min, 3.5);   %<-- change back!! 
end
if vProp_min > vSat
    uProp_max = (1-(vProp_min-vSat)/(vMax-vSat))*uProp_max;
    uProp_max = max(uProp_max, 0);  
end
UnewMat(2,:) = [uProp_min, uProp_max];

%create new input zonotope
U = zonotope(intervalhull(UnewMat));

%------------- END OF CODE --------------