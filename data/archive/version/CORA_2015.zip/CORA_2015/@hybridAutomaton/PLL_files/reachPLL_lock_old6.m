function [Rfinal] = reachPLL_lock(obj, options)
% reachPLL_lock - computes the reachable set of the PLL when close to
% locking
%
% Syntax:  
%    [R] = reachPLL_lock(obj, options)
%
% Inputs:
%    options - options for reachability analysis of the system
%
% Outputs:
%    R - reachable set
%
% Example: 
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: none

% Author:       Matthias Althoff
% Written:      03-December-2010
% Last update:  ---
% Last revision:---

%------------- BEGIN CODE --------------


%obtain variables
A = options.sys.A;
c = options.sys.c;
dim = length(A);
Ucertain = options.Ucertain;
Ucertain_i = options.Ucertain_i;
Ucertain_p = options.Ucertain_p;
Uuncertain = options.Uuncertain;
guard = options.guard;
R{1} = options.R0; 

Rstore=[];
options.overflow=0; %<-- to be changed


%instantiate linear system
linSys = linearSys('linearDynamics',A,eye(dim)); 

%compute phase and voltage velocity boundaries
%set viInt and vpInt
viInt = infsup(-1,1);
vpInt = infsup(-1,1);
[vMinPhase,vMaxPhase]=phaseVelBound(A, c, viInt, vpInt);


%compute cycle time
t_cycle = 1/27;

%compute interval hull
IH = intervalhull(R{1});


iCycle=1;

while ~(IH<=options.Rgoal)

    %PHASE 1---------------------------------------------------------------
    %compute T
    Phi_IH = abs(intervalhull([0 0 0 1]*R{iCycle}))
    Tmax = Phi_IH(:,2)/min(vMinPhase,vMaxPhase);
    T = infsup(0,Tmax); %other time delay: 50e-3
    
    %get center and delta of T
    t_center = mid(T);
    t_delta = rad(T);
    
    %compute matrix zonotopes
    [E_1, E_2] = expMatRemainder(A, t, options);
    
    
    Acenter = A*t_center;
    Adelta{1} = A*t_delta;
    
    matZ = matZonotope(Acenter, Adelta);
    
    %compute matrix exponential
    % r:1, intermediate order:3, taylorterms: 10
    [eZ,eI,zPow,iPow,E] = expmMixed(matZ,1,3,10);
    %----------------------------------------------------------------------
    
    %INPUT-----------------------------------------------------------------
    eI_2 = intervalMatrix(eZ) + eI;
    
    u = center(Ucertain) - options.sys.c;
    
    vInt = infsup(vMinPhase,vMaxPhase);
    
    %compute fourth column
    factor = (1/vInt);
    intervalMatFactor = intervalMatrix(mid(factor),rad(factor));
    fourthCol = intervalMatFactor*eI_2*(-u);
    fourthCol_center = mid(fourthCol.int);
    fourthCol_gen = rad(fourthCol.int);
    
    Acenter(:,4) = fourthCol_center;
    Adelta{1}(:,4) = fourthCol_gen;
    matZinput = matZonotope(Acenter,Adelta);
    
%     fourthCol = eI_2*intervalMatFactor*eI_2*(-u);
%     
%     Aleft = zeros(dim);
%     Aright = zeros(dim);
%     Aleft(:,4) = inf(fourthCol.int);
%     Aright(:,4) = sup(fourthCol.int);
%     matInput = intervalMatrix(Aleft,Aright);
%     
%     
%     %make correction multiplication
%     matInput = expm(A*(t_cycle-2*t_center))*matInput;
%     
%     matZinput = matZonotope(matInput);
    
    %complete solution-----------------------------------------------------
    Rinit_new = (expm(A*t_cycle)+matZinput)*R{iCycle};
    %----------------------------------------------------------------------
    
    %intersect with invariant
    R{iCycle+1} = Rinit_new & zonotope(options.Rinv);
    R{iCycle+1} = shrinkIH(R{iCycle+1});
    R{iCycle+1} = reduce(R{iCycle+1},'girard',20);
    
    if mod(iCycle,200)==0
        %obtain linear map
        t = iCycle*t_cycle;
        linMap = expm(options.sys.A*t) + 0.01*eye(dim);
        
        %simplify
        R{iCycle+1} = simplifySet(R{iCycle+1}, linMap, A);
    end
    
    
    %compute reachable set intersecting guard set 2
    if options.overflow==1
        
        %compute time bounds
        [t_on_phase,t_total]=timeBound_phase(R{iCycle},vMinPhase,vMaxPhase,0);
        t_on = sup(t_on_phase);
        
        %compute reachable set at time t_total_min
        M_other = expm(options.sys.A*inf(t_total));
        eAtInt_other = inputExponential(A,t_on,options);
        
        %compute R_init
        Rinput_other = eAtInt_other*Uuncertain;
        Rinit = M_other*R{iCycle} + Rinput_other;
        
        %set options
        options.timeStep = sup(t_total) - inf(t_total);
        options.uTrans = c;
        options.U = zonotope(0*c);
        
        %compute initial set
        [obj,Rfirst,options] = initReach(linSys,Rinit,options);
        
        %intersect with guard set
        Rjump = Rfirst.ti & guard;
        
        %obtain linear map
        t = iCycle*t_cycle;
        linMap = expm(options.sys.A*t) + 0.01*eye(dim);
        
        %simplify
        Rjump = simplifySet(Rjump, linMap, A);
        
        %plot results
        plot(Rinit, [3 4]);
        plot(Rfirst.ti, [3 4]);
        plot(guard, [3 4]);  
        
        %store result
        if isempty(Rstore)
            Rstore=Rjump;
            Pstore=exactPolytope(Rstore);
        else
            %check if set is enclosed in the stored set
            Pjump=exactPolytope(Rjump);
            if ~(Pstore.iscontained(Pjump))

                Rstore=enclose(Rstore, Rjump);
                %slightly increase Rstore
                Rstore=enlarge(Rstore,1.01*ones(dim));
                Pstore=exactPolytope(Rstore);
                lastIncrease=iCycle;
            end
        end
    end
    
    
%     if mod(iCycle,200)==0
%         dims=[1 2; 2 3; 1 4];
%         for iPlot=1:3
%             figure;
%             plot(R{iCycle+1},dims(iPlot,:));
%         end
%     end
    
    IH=intervalhull(R{iCycle+1});
    
    if mod(iCycle,50)==0
        save lockModeAll
    end

    iCycle = iCycle+1;
end
%store final set
Rfinal = R{iCycle};



%compute phase velocity boundaries
function [vMin,vMax]=phaseVelBound(A,c,vpInt,viInt)

vInt = A(4,:)*[viInt; 0; vpInt; 0] + c(4);

vMin = inf(vInt);
vMax = sup(vInt);


%compute phase velocity boundaries
function [vMin,vMax]=voltageVelBound(A,vpInt,Ucertain)

%projection matric
P = [1 0 0 0; 0 1 0 0];

absVal = max(abs(inf(vpInt)),abs(sup(vpInt)));

%velocity for v_p1 not considering inputs
vInt_tmp = A(2,:)*[0; -absVal; +absVal; 0];

%velocity for v_i and v_p1 
vIH = intervalhull(P*Ucertain) + intervalhull([0,0; -vInt_tmp, vInt_tmp]);

vMin = vIH(:,1);
vMax = vIH(:,2);


%compute time intervals for charge pump on and off
function [t_on,t_total]=timeBound_phase(R,vMin,vMax,phaseMargin)

%obtain range of Phi_v
Phi_IH = intervalhull([0 0 0 1]*R);
PhiMin = min(Phi_IH(:,1),phaseMargin);
PhiMax = min(Phi_IH(:,2),phaseMargin);

%t_on
t_on_min = -PhiMax/vMax;
t_on_max = -PhiMin/vMin;
t_on = infsup(t_on_min,t_on_max);


%t_total
t_total_min = (1-PhiMax)/vMax;
t_total_max = (1-PhiMin)/vMin;
t_total = infsup(t_total_min,t_total_max);


%compute time intervals for charge pump on and off
function [t_on]=timeBound_voltage(R,vMax,vSat)

%obtain range of v_i and v_p1
v_i_IH = intervalhull([1 0 0 0 0]*R);
v_p1_IH = intervalhull([0 1 0 0 0]*R);

v_i_min = v_i_IH(:,1);
v_p1_min = v_p1_IH(:,1);

%t_on
t_i_max = (vSat-v_i_min)/vMax(1);
t_p1_max = (vSat-v_p1_min)/vMax(2);
t_on = [t_i_max, t_p1_max];



function eAtInt = inputExponential(A,r,options)

%compute Apowers
Apower = powers(A,options);
E = remainder(A,r,options);

dim = length(Apower{1});
Asum = r*eye(dim);
%compute higher order terms
for i=1:options.taylorTerms
    %compute factor
    factor = r^(i+1)/factorial(i+1);    
    %compute sums
    Asum = Asum + Apower{i}*factor;
end

%compute exponential due to constant input
eAtInt = Asum + E*r;


function Apower = powers(A,options)

%initialize 
Apower = cell(1,options.taylorTerms+1);
Apower{1} = A;  
    
%compute powers for each term and sum of these
for i=1:options.taylorTerms
    %compute powers
    Apower{i+1}=Apower{i}*A;
end   


function E = remainder(A,r,options)

%compute absolute value bound
M = abs(A*r);
dim = length(M);

%compute exponential matrix
eM = expm(M);

%compute first Taylor terms
Mpow = eye(dim);
eMpartial = eye(dim);
for i=1:options.taylorTerms
    Mpow = M*Mpow;
    eMpartial = eMpartial + Mpow/factorial(i);
end

W = eM-eMpartial;

%instantiate remainder
E = intervalMatrix(zeros(dim),W);


function R = simplifySet(R, linMap, A)

%do classical reduction
R = reduce(R,'girard',2);

%update options.W
W{1} = eye(length(A));
W{2} = linMap;
Aenh(2:4,1:4) = A(2:4,1:4);
Aenh(1,1) = 1;
Aenh(4,4) = 0.01;
W{3} = Aenh;
W{4} = [1 0 0 -1; 0 1 -1 0; 0 1 0 -1; 1 -1 0 0];

%shrink
R = shrink3(R,W,0);

function [E_1, E_2] = expMatRemainder(A, t, options)

%compute auxiliary matrix
tmpMat = 0.5*(t^2)*A^2;

%compute E_1 center, generators
E_1_center = 1/factorial(2)*tmpMat;
E_1_gen{1} = 1/factorial(2)*tmpMat;

%compute E_2 center, generators
E_2_center = 1/factorial(3)*tmpMat;
E_2_gen{1} = 1/factorial(3)*tmpMat;

for i=3:options.taylorTerms
    tmpMat = 0.5*(t^i)*A^i;
    
    %compute E_1 center, generators
    E_1_center = E_1_center + 1/factorial(i)*tmpMat;
    E_1_gen{end+1} = 1/factorial(i)*tmpMat;

    %compute E_2 center, generators
    E_2_center = E_2_center + 1/factorial(i+1)*tmpMat;
    E_2_gen{end+1} = 1/factorial(i+1)*tmpMat;
end

%instantiate matrix zonotopes
E_1 = matZonotope(E_1_center, E_1_gen);
E_2 = matZonotope(E_2_center, E_2_gen);

%------------- END OF CODE --------------