function [TP,R,nextLoc,Rjump,Rcont] = reach(obj,tStart,R0,options)
% reach - computes the reachable set of the system within a location, 
% detects the guard set that is hit and computes the reset
%
% Syntax:  
%    [TP,R,nextLoc,Rjump,Rcont] = reach(obj,tStart,R0,options)
%
% Inputs:
%    obj - location object
%    tStart - start time
%    R0 - initial reachable set
%    options - options struct
%
% Outputs:
%    TP - time point struct; e.g. contains time vector of minimum times for reaching guard sets
%    R - cell array of reachable sets
%    nextLoc - next location
%    Rjump - reachable set after jump according to the reset map
%    Rcont - reachable set due to continuous evolution
%
% Example: 
%
% Other m-files required: initReach, reach, potOut, potInt, guardIntersect,
% reset
% Subfunctions: none
% MAT-files required: none
%
% See also: none

% Author:       Matthias Althoff
% Written:      07-May-2007 
% Last update:  17-August-2007
%               26-March-2008
%               21-April-2009
%               06-July-2009
%               24-July-2009
%               31-July-2009
%               11-August-2010
% Last revision: ---

%------------- BEGIN CODE --------------


%obtain enclosing zonotopes
if options.isHybrid==0
    %get results from reachability analysis
    [TP,R,nextLoc,Rjump,Rcont] = singleSetReach(obj,tStart,R0,options);
else
    
    parallelSets=length(R0);
    TPpartial=cell(1,parallelSets);
    R=cell(1,parallelSets);
    nextLocPartial=cell(1,parallelSets);
    RunorderedJump=cell(1,parallelSets);
    Rcont=cell(1,parallelSets);
    
    %parfor (iSet=1:parallelSets)
    for iSet=1:parallelSets
        %get results from reachability analysis
        [TPpartial{iSet},R{iSet},nextLocPartial{iSet},RunorderedJump{iSet},Rcont{iSet}] = singleSetReach(obj,tStart,R0{iSet},options);  
    end
    
    %update nextLoc
    for iSet=1:length(R0)
        %check for parallel sets
        if length(nextLocPartial{iSet})>1
            disp('more than one next location...');
        end          
        %intersect next locations
        if iSet==1
            nextLoc=nextLocPartial{iSet};
        else
            nextLoc=intersect(nextLoc,nextLocPartial{iSet});
        end
    end
    
    %collect TP data

    
    %init
    if ~isempty(nextLoc)
        %set up TPtmp
        TP.tMin(1:length(nextLoc))=tStart;
        TP.tMax(1:length(nextLoc))=inf;
        %set up Rjump
        Rjump{length(nextLoc)}=[];

        %collect TP data
        for iSet=1:length(TPpartial)
            %update TP
            for iGuard=1:length(nextLoc)       

                %update TP
                %tMin
                if TPpartial{iSet}.tMin(iGuard)>TP.tMin(iGuard)
                    TP.tMin(iGuard)=TPpartial{iSet}.tMin(iGuard);
                end
                %tMax
                if TPpartial{iSet}.tMax(iGuard)<TP.tMax(iGuard)
                    TP.tMax(iGuard)=TPpartial{iSet}.tMax(iGuard);
                end        
            end
        end

        %obtain final TP data
        TP.tStart=TPpartial{1}.tStart;

        TP
        
        %obtain min and max index
        minInd=(TP.tMin-TP.tStart)/options.timeStep;
        maxInd=(TP.tMax-TP.tStart)/options.timeStep;

        try
        %obtain Rjump within the time intervals of guard intersection
        for iSet=1:length(RunorderedJump)
            for iGuard=1:length(nextLoc)
                %get tMin and tMax
                tMin=TP.tMin(iGuard);
                tMax=TP.tMax(iGuard);

                %init time, counter
                t=TPpartial{iSet}.tMin(iGuard);
                counter=1;   

                %obtain guard index
                ind = find(nextLocPartial{iSet}==nextLoc(iGuard));

                %check if sets can be added
                if ~isempty(RunorderedJump{iSet})
                    for k=1:length(RunorderedJump{iSet}{ind})
                        %store only Rjumps within the time interval of guard
                        %intersection
                        if (t>=tMin*(1-1e-8)) && (t<=tMax*(1+1e-8))
                            RjumpTmp{iSet}{iGuard}{counter}=RunorderedJump{iSet}{ind}{k};
                            counter=counter+1;
                        end
                        %time update
                        t=t+options.timeStep;
                    end
                end
            end
        end

        %init counter
        counter=1;
        Rjump{1}=[];
        %next location index loop
        for iGuard=1:length(nextLoc)
            %time step loop
            iStep=1;
            try
                while iStep<=length(RjumpTmp{1}{iGuard})
                    %initialize R jump
                    Rjump{counter}{end+1}=RjumpTmp{1}{iGuard}{iStep};
                    for iSet=2:length(RjumpTmp)     
                        %intersect polytopes
                        Rjump{counter}{end}=Rjump{counter}{end} & RjumpTmp{iSet}{iGuard}{iStep};
                    end
                    %increase time step
                    iStep=iStep+1;
                    %if Rjump is empty, delete it
                    if isempty(Rjump{counter}{end})
                        Rjump{counter}(end)=[];
                    end
                end   
            catch
                disp('empty set ignored...')
                Rjump{counter}=[];
            end
            %check for emptiness
            if isempty(Rjump{counter})
                Rjump(counter)=[];
            else
                counter=counter+1;
            end
        end
        catch
            disp('problem...')
        end
        
        %compute enclosing zonotopes
        for iGuard=1:length(Rjump)
            tic
            
            %update W matrix
            A=get(obj.contDynamics,'A');
            options.W{2}=pinv(expm(A*TP.tMax(iGuard))+0.001*eye(length(A))); %<-- good when initial set is an axis-aligned set
            
            options.W{2}
            
            Rjump{iGuard} = enclosePolytopes(obj,Rjump{iGuard},[],options);
            disp('enclosure time');
            toc
        end
        
        %split reachable set
        %[TP,nextLoc,Rjump]=splitReach(TP,nextLoc,Rjump);

        
        
    % next location is empty    
    else
        %set up TPtmp
        TP.tMin=[];
        TP.tMax=[];
        %set up Rjump
        Rjump{1}=[];
    end
end



%------------- END OF CODE --------------