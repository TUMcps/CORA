function [Zbundle] = enclosePolytopes_box(obj,P,options)
% enclosePolytopes - encloses a set of polytopes using differnt
% overapproximating zonotopes.
%
% Syntax:  
%    [Zencl] = enclosePolytopes(obj,R0,options)
%
% Inputs:
%    obj - location object
%    P - initial reachable polytopes
%    options - options struct
%
% Outputs:
%    Zencl - cell array of enclosing zonotopes
%
% Example: 
%
% Other m-files required: not specified
% Subfunctions: none
% MAT-files required: none
%
% See also: none

% Author:       Matthias Althoff
% Written:      11-October-2008
% Last update:  31-July-2009
% Last revision:---

%------------- BEGIN CODE --------------


%obtain new vertices
timeSteps=length(P);
for iStep=1:timeSteps
    IHpartial=intervalhull(P{iStep});
    if iStep == 1
        IH = IHpartial;
    else
        IH = IH | IHpartial;
    end
end

Zmat = get(zonotope(IH),'Z');
Zbundle = quadZonotope(Zmat(:,1),Zmat(:,2:end),[],[],[]);

%------------- END OF CODE --------------