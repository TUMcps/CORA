function [Zbundle,Zrand,P,tcomp] = enclosePolytopes_CDC(obj,P,A,A_next,options)
% enclosePolytopes - encloses a set of polytopes using differnt
% overapproximating zonotopes.
%
% Syntax:  
%    [Zencl] = enclosePolytopes(obj,R0,options)
%
% Inputs:
%    obj - location object
%    P - initial reachable polytopes
%    options - options struct
%
% Outputs:
%    Zencl - cell array of enclosing zonotopes
%
% Example: 
%
% Other m-files required: not specified
% Subfunctions: none
% MAT-files required: none
%
% See also: none

% Author:       Matthias Althoff
% Written:      14-February-2011
% Last update:  ---
% Last revision:---

%------------- BEGIN CODE --------------



%obtain new vertices
V=[];
timeSteps=length(P);
for iStep=1:timeSteps
    Vpartial=vertices(P{iStep});
    V=[V,get(Vpartial,'V')];
end 
%check polytope enclosure
tic
%P = mptPolytope(V');
P = [];
tPoly = toc;

figure
plot(V(1,:),V(2,:),'k+');
V=vertices(V);



%obtain direction of the vector field
x0=center(intervalhull(V));
direction=A_next*x0; 
prevDirection=A*x0;

nrOfEncl=length(options.enclosureEnables);
for i=1:nrOfEncl
    %perform different enclosures
    tic
    switch options.enclosureEnables(i)
        case 1
            %new direction
            Ztmp = dirPolytopeBoth(V,direction,prevDirection);
        case 2
            %box enclosure
            Ztmp = zonotope(intervalhull(V));
        case 3
            %exponential matrix transformation
            Ztmp = options.G*zonotope(intervalhull(pinv(options.G)*V));
        case 4
            %principal component analysis
            Ztmp = zonotope(V);
        otherwise
            disp('No proper enclosure method selected.')
    end
    tcomp(i) = toc;
    %store result
    Zencl{i}=Ztmp;
end

%generate zonotope bundle
Zbundle=zonotopeBundle(Zencl(:));

for i=1:nrOfEncl
    plot(Zencl{i});
end
plot(Zbundle,[1 2],'r');

%compute best random enclosure
dim = length(x0);
tic
for iTry = 1:100
    for iDim = 1:dim
        G(:,iDim)=randomPointOnSphere(dim);
    end
    ZrandEncl{iTry} = G*zonotope(intervalhull(pinv(G)*V));
    vol(iTry) = volume(ZrandEncl{iTry});
end
tcomp(end+1)=toc;
%add time for polytope computation
tcomp(end+1)=tPoly;

%choose best enclosure
[val,ind] = sort(vol);
Zrand = ZrandEncl{ind};



% figure;
% hold on
% dims=[1 2];
% plot(Zbundle,dims);
% for iStep=1:length(P)
%     plot(P{iStep},dims,'g');
% end
% 
% figure;
% hold on
% dims=[2 3];
% plot(Zbundle,dims);
% for iStep=1:length(P)
%     plot(P{iStep},dims,'g');
% end
% 
% figure;
% hold on
% dims=[4 5];
% plot(Zbundle,dims);
% for iStep=1:length(P)
%     plot(P{iStep},dims,'g');
% end

% figure;
% hold on
% dims=[1 2];
% plot(Zbundle{1},dims);
% plot(Zbundle{2},dims);
% for iStep=1:length(P)
%     plot(P{iStep},dims,'g');
% end
% 
% figure;
% hold on
% dims=[2 3];
% plot(Zbundle{1},dims);
% plot(Zbundle{2},dims);
% for iStep=1:length(P)
%     plot(P{iStep},dims,'g');
% end
% 
% figure;
% hold on
% dims=[4 5];
% plot(Zbundle{1},dims);
% plot(Zbundle{2},dims);
% for iStep=1:length(P)
%     plot(P{iStep},dims,'g');
% end


%

%------------- END OF CODE --------------