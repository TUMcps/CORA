Place `./cora`, and all your `./scripts`, etc. here.
Call them from `main.m`.