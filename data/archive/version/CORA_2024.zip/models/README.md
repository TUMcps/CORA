# Models

This folder contains all model files of CORA.

While using CORA, some files might generated and stored here.
You can reset CORA by executing

    resetCORA

in the MATLAB console.


<hr style="height: 1px;">

<img src="../app/images/coraLogo_readme.svg"/>