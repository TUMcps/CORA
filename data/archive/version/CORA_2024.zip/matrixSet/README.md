# Matrix Sets

This folder contains all matrix sets implemented in CORA.

Check the respective subfolders and Section 3 in the <a target='_blank' href="https://tumcps.github.io/CORA/manual">CORA manual</a> or see

    ./cora/examples/matrixSet

for more information.


<hr style="height: 1px;">

<img src="../app/images/coraLogo_readme.svg"/>