# Specification

This folder contains all specification classes of CORA.

Please check the <a target='_blank' href="https://tumcps.github.io/CORA/manual">CORA manual</a> for more information.

<hr style="height: 1px;">

<img src="../app/images/coraLogo_readme.svg"/>