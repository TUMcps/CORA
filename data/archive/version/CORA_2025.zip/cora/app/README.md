# CORA App

This folder contains all files for the CORA App.
Execute

    coraApp

in the MATLAB console to start defining your dynamic graphically.
Check Section 8 in the <a target='_blank' href="https://tumcps.github.io/CORA/manual">CORA manual</a> for more information.


<hr style="height: 1px;">

<img src="../app/images/coraLogo_readme.svg"/>